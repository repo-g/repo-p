// A map between namespaces and base URLs for their online documentation
baseURLs = [
    [ 'GSSDP', 'https://gnome.pages.gitlab.gnome.org/gssdp/docs/' ],
]
