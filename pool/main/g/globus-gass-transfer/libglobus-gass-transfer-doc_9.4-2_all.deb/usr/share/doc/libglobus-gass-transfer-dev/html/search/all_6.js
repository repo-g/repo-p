var searchData=
[
  ['listen_125',['listen',['../structglobus__gass__transfer__listener__proto__s.html#adaeeaaa668decf8bdb8d2346d174229d',1,'globus_gass_transfer_listener_proto_s']]],
  ['listener_20attributes_126',['Listener attributes',['../group__globus__gass__transfer__listenerattr.html',1,'']]]
];
