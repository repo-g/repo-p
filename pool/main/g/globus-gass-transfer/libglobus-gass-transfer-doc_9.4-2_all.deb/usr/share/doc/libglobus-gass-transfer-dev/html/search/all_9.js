var searchData=
[
  ['recv_5fbuffer_132',['recv_buffer',['../structglobus__gass__transfer__request__proto__s.html#a1e1d0cf9d4f0b3ccd089d81d7f7b8cee',1,'globus_gass_transfer_request_proto_s']]],
  ['refer_133',['refer',['../structglobus__gass__transfer__request__proto__s.html#abf9b6b59141d1492a86eacff114fb61e',1,'globus_gass_transfer_request_proto_s']]],
  ['referrals_134',['Referrals',['../group__globus__gass__transfer__referral.html',1,'']]],
  ['request_20attributes_135',['Request Attributes',['../group__globus__gass__transfer__requestattr.html',1,'']]],
  ['request_20handles_136',['Request Handles',['../group__globus__gass__transfer__request.html',1,'']]]
];
