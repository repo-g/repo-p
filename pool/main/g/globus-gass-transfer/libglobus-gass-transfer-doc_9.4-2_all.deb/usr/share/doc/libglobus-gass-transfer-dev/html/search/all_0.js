var searchData=
[
  ['accept_0',['accept',['../structglobus__gass__transfer__listener__proto__s.html#a23ec651df88fa027aeb590bd643219a3',1,'globus_gass_transfer_listener_proto_s']]],
  ['activation_1',['Activation',['../group__globus__gass__transfer__activation.html',1,'']]],
  ['authorize_2',['authorize',['../structglobus__gass__transfer__request__proto__s.html#aaff5262ea5f2514eaf35e95ab5ffa75f',1,'globus_gass_transfer_request_proto_s']]]
];
