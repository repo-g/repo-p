var searchData=
[
  ['sending_20and_20receiving_20data_277',['Sending and Receiving Data',['../group__globus__gass__transfer__data.html',1,'']]]
];
