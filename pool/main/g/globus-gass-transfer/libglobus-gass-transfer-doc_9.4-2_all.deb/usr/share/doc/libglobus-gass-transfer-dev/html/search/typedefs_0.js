var searchData=
[
  ['globus_5fgass_5ftransfer_5fbytes_5fcallback_5ft_222',['globus_gass_transfer_bytes_callback_t',['../group__globus__gass__transfer__data.html#ga74252eaced1e2eb5d359979b794611ef',1,'globus_gass_transfer.h']]],
  ['globus_5fgass_5ftransfer_5fclose_5fcallback_5ft_223',['globus_gass_transfer_close_callback_t',['../group__globus__gass__transfer__server.html#ga2ebdc14f20fb4ec9ac1bf649add9251c',1,'globus_gass_transfer.h']]],
  ['globus_5fgass_5ftransfer_5flisten_5fcallback_5ft_224',['globus_gass_transfer_listen_callback_t',['../group__globus__gass__transfer__server.html#ga25ff69c9abdea7ba8e787650203ddd01',1,'globus_gass_transfer.h']]],
  ['globus_5fgass_5ftransfer_5flistener_5fproto_5ft_225',['globus_gass_transfer_listener_proto_t',['../group__globus__gass__transfer__protocol.html#ga893db9d9f79492c49f7ac8e147939b1a',1,'globus_gass_transfer_proto.h']]],
  ['globus_5fgass_5ftransfer_5fproto_5faccept_5ft_226',['globus_gass_transfer_proto_accept_t',['../group__globus__gass__transfer__protocol.html#gaf85adea94a82373f05aec52c970df1df',1,'globus_gass_transfer_proto.h']]],
  ['globus_5fgass_5ftransfer_5fproto_5fcreate_5flistener_5ft_227',['globus_gass_transfer_proto_create_listener_t',['../group__globus__gass__transfer__protocol.html#ga572165c65f881b9db99f965b2472d01a',1,'globus_gass_transfer_proto.h']]],
  ['globus_5fgass_5ftransfer_5fproto_5ffunc_5ft_228',['globus_gass_transfer_proto_func_t',['../group__globus__gass__transfer__protocol.html#gad014b4ed1dd1621041609836a3591987',1,'globus_gass_transfer_proto.h']]],
  ['globus_5fgass_5ftransfer_5fproto_5flistener_5ft_229',['globus_gass_transfer_proto_listener_t',['../group__globus__gass__transfer__protocol.html#ga4cad8a5a53d7318595e9b2b6e21845eb',1,'globus_gass_transfer_proto.h']]],
  ['globus_5fgass_5ftransfer_5fproto_5fnew_5fattr_5ft_230',['globus_gass_transfer_proto_new_attr_t',['../group__globus__gass__transfer__protocol.html#ga8cc01db74520835452e01cdeda63aad2',1,'globus_gass_transfer_proto.h']]],
  ['globus_5fgass_5ftransfer_5fproto_5fnew_5frequest_5ft_231',['globus_gass_transfer_proto_new_request_t',['../group__globus__gass__transfer__protocol.html#ga397d5325f6ee391ff8a8dd5c75cc17c4',1,'globus_gass_transfer_proto.h']]],
  ['globus_5fgass_5ftransfer_5fproto_5freceive_5ft_232',['globus_gass_transfer_proto_receive_t',['../group__globus__gass__transfer__protocol.html#gaa114622b15dfc0927d9131d3671c6266',1,'globus_gass_transfer_proto.h']]],
  ['globus_5fgass_5ftransfer_5fproto_5fsend_5ft_233',['globus_gass_transfer_proto_send_t',['../group__globus__gass__transfer__protocol.html#ga026c7042b691716449c5e9ea3ceaecca',1,'globus_gass_transfer_proto.h']]],
  ['globus_5fgass_5ftransfer_5frequest_5fproto_5ft_234',['globus_gass_transfer_request_proto_t',['../group__globus__gass__transfer__protocol.html#gaaa1078847d85de85d5b9e4d83cf4a575',1,'globus_gass_transfer_proto.h']]]
];
