var searchData=
[
  ['send_5fbuffer_137',['send_buffer',['../structglobus__gass__transfer__request__proto__s.html#adff86dfcde6cc409c093a713717b26b5',1,'globus_gass_transfer_request_proto_s']]],
  ['sending_20and_20receiving_20data_138',['Sending and Receiving Data',['../group__globus__gass__transfer__data.html',1,'']]]
];
