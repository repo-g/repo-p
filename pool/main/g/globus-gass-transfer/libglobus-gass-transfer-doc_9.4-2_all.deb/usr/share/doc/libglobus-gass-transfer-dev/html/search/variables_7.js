var searchData=
[
  ['send_5fbuffer_220',['send_buffer',['../structglobus__gass__transfer__request__proto__s.html#adff86dfcde6cc409c093a713717b26b5',1,'globus_gass_transfer_request_proto_s']]]
];
