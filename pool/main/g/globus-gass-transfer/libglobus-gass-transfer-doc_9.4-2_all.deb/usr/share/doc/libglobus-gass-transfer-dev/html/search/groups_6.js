var searchData=
[
  ['referrals_274',['Referrals',['../group__globus__gass__transfer__referral.html',1,'']]],
  ['request_20attributes_275',['Request Attributes',['../group__globus__gass__transfer__requestattr.html',1,'']]],
  ['request_20handles_276',['Request Handles',['../group__globus__gass__transfer__request.html',1,'']]]
];
