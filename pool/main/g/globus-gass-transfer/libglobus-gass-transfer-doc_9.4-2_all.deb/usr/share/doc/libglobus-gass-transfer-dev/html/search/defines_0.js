var searchData=
[
  ['globus_5fgass_5ftransfer_5flength_5funknown_265',['GLOBUS_GASS_TRANSFER_LENGTH_UNKNOWN',['../globus__gass__transfer_8h.html#acac7f83f18a396348e1676b38ffc12f5',1,'globus_gass_transfer.h']]],
  ['globus_5fgass_5ftransfer_5ftimestamp_5funknown_266',['GLOBUS_GASS_TRANSFER_TIMESTAMP_UNKNOWN',['../globus__gass__transfer_8h.html#a5c8f15500f4635b7fb0aaec1054e66e9',1,'globus_gass_transfer.h']]]
];
