var searchData=
[
  ['url_5fscheme_139',['url_scheme',['../structglobus__gass__transfer__proto__descriptor__t.html#a75e1a7af4cfbc63c983bfdad79a30d50',1,'globus_gass_transfer_proto_descriptor_t']]]
];
