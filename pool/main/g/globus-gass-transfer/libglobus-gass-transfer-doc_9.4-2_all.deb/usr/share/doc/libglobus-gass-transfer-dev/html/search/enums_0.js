var searchData=
[
  ['globus_5fgass_5ftransfer_5frequest_5fstatus_5ft_235',['globus_gass_transfer_request_status_t',['../group__globus__gass__transfer__request.html#gaaa671d5ef2fae5a7034e0624c3bbc1b5',1,'globus_gass_transfer.h']]],
  ['globus_5fgass_5ftransfer_5frequest_5ftype_5ft_236',['globus_gass_transfer_request_type_t',['../group__globus__gass__transfer__request.html#ga5602a52b98af47f77e032fcdd913957f',1,'globus_gass_transfer.h']]]
];
