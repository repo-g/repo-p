var searchData=
[
  ['recv_5fbuffer_218',['recv_buffer',['../structglobus__gass__transfer__request__proto__s.html#a1e1d0cf9d4f0b3ccd089d81d7f7b8cee',1,'globus_gass_transfer_request_proto_s']]],
  ['refer_219',['refer',['../structglobus__gass__transfer__request__proto__s.html#abf9b6b59141d1492a86eacff114fb61e',1,'globus_gass_transfer_request_proto_s']]]
];
