var searchData=
[
  ['new_5flistener_127',['new_listener',['../structglobus__gass__transfer__proto__descriptor__t.html#add7c52f06610c1364e83133eefb81876',1,'globus_gass_transfer_proto_descriptor_t']]],
  ['new_5flistenerattr_128',['new_listenerattr',['../structglobus__gass__transfer__proto__descriptor__t.html#a5f5d98eb70200a3c03b0d079eea80648',1,'globus_gass_transfer_proto_descriptor_t']]],
  ['new_5frequest_129',['new_request',['../structglobus__gass__transfer__proto__descriptor__t.html#a0d441064126e8173a2c06cb6213ebaa3',1,'globus_gass_transfer_proto_descriptor_t']]],
  ['new_5frequestattr_130',['new_requestattr',['../structglobus__gass__transfer__proto__descriptor__t.html#acd75372874ae7c590ebe8562777241ed',1,'globus_gass_transfer_proto_descriptor_t']]]
];
