var searchData=
[
  ['globus_5fgass_5ftransfer_5flistener_5fproto_5fs_140',['globus_gass_transfer_listener_proto_s',['../structglobus__gass__transfer__listener__proto__s.html',1,'']]],
  ['globus_5fgass_5ftransfer_5fproto_5fdescriptor_5ft_141',['globus_gass_transfer_proto_descriptor_t',['../structglobus__gass__transfer__proto__descriptor__t.html',1,'']]],
  ['globus_5fgass_5ftransfer_5frequest_5fproto_5fs_142',['globus_gass_transfer_request_proto_s',['../structglobus__gass__transfer__request__proto__s.html',1,'']]],
  ['globus_5fgass_5ftransfer_5frequest_5ft_143',['globus_gass_transfer_request_t',['../structglobus__gass__transfer__request__t.html',1,'']]]
];
