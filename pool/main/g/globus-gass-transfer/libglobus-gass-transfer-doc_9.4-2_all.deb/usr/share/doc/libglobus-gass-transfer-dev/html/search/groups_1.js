var searchData=
[
  ['client_2dinitiated_20operations_268',['Client-Initiated Operations',['../group__globus__gass__transfer__client.html',1,'']]]
];
