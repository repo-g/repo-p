var searchData=
[
  ['client_2dinitiated_20operations_3',['Client-Initiated Operations',['../group__globus__gass__transfer__client.html',1,'']]],
  ['close_5flistener_4',['close_listener',['../structglobus__gass__transfer__listener__proto__s.html#a508cb912a3292baa5b1862822b3d1515',1,'globus_gass_transfer_listener_proto_s']]]
];
