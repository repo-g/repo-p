var searchData=
[
  ['deny_5',['deny',['../structglobus__gass__transfer__request__proto__s.html#a210f758d4e1d8c3d7244f5f7c7ec7581',1,'globus_gass_transfer_request_proto_s']]],
  ['destroy_6',['destroy',['../structglobus__gass__transfer__request__proto__s.html#a9a36b7066acc30192039f1db65bf2d7f',1,'globus_gass_transfer_request_proto_s::destroy()'],['../structglobus__gass__transfer__listener__proto__s.html#a1187927c5a516df7dbbc768a5415fca0',1,'globus_gass_transfer_listener_proto_s::destroy()']]]
];
