var searchData=
[
  ['implementing_20request_20attributes_270',['Implementing Request Attributes',['../group__globus__gass__transfer__requestattr__implementation.html',1,'']]],
  ['implementing_20servers_271',['Implementing Servers',['../group__globus__gass__transfer__server.html',1,'']]]
];
