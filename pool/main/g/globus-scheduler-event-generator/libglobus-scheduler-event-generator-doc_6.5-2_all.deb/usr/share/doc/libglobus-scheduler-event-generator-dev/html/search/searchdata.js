var indexSectionsWithContent =
{
  0: "gs",
  1: "g",
  2: "g",
  3: "s",
  4: "s"
};

var indexSectionNames =
{
  0: "all",
  1: "enums",
  2: "enumvalues",
  3: "groups",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Enumerations",
  2: "Enumerator",
  3: "Modules",
  4: "Pages"
};

