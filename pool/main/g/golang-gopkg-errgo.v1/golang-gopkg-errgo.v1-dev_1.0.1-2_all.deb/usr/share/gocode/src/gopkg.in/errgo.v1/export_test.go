// Copyright 2014 Roger Peppe.
// See LICENCE file for details.

package errgo

var Match = match
