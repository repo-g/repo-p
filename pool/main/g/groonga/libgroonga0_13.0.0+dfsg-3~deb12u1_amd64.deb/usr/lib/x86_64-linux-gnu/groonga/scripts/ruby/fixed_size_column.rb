module Groonga
  class FixedSizeColumn
    include Indexable
  end
end
