module Groonga
  class VariableSizeColumn
    include Indexable
  end
end
