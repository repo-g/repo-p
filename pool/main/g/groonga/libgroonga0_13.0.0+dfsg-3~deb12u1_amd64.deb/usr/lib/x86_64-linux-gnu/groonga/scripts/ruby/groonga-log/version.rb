module GroongaLog
  VERSION = "0.1.1"
end
