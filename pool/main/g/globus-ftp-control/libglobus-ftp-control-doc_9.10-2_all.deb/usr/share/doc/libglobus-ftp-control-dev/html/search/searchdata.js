var indexSectionsWithContent =
{
  0: "g",
  1: "g",
  2: "g",
  3: "g",
  4: "g",
  5: "g",
  6: "g",
  7: "g",
  8: "g"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "typedefs",
  5: "enums",
  6: "enumvalues",
  7: "groups",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Typedefs",
  5: "Enumerations",
  6: "Enumerator",
  7: "Modules",
  8: "Pages"
};

