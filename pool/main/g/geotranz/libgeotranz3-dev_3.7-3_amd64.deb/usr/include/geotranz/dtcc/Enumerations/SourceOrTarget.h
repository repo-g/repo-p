// CLASSIFICATION: UNCLASSIFIED

#ifndef SourceOrTarget_H
#define SourceOrTarget_H


namespace MSP
{
  namespace CCS
  {
    class SourceOrTarget
    {
    public:

      enum Enum
      {
        source,
        target
      };
    };
  }
}
	
#endif 


// CLASSIFICATION: UNCLASSIFIED
