print ([[

This tools implements parts of the functionality of 'MagicMatch' which is
described in the following paper:

'M. Smith, V. Kunin, L. Goldovsky, A.J. Enright, and C.A. Ouzounis.
MagicMatch -- cross-referencing sequence identifiers across databases.
Bioinformatics, 21(16):3429-3430, 2005.'

It is mainly used for testing the underlying MD5 fingerprint machinery.]])
