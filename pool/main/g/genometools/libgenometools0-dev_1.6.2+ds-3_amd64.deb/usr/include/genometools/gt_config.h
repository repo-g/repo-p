#ifndef GT_CONFIG_H
#define GT_CONFIG_H
#define GT_CC "cc (Debian 12.2.0-9) 12.2.0"
#define GT_CFLAGS "-g -O2 -ffile-prefix-map=.=. -fstack-protector-strong -Wformat -Werror=format-security -g -Wall -Wunused-parameter -pipe -fPIC -Wpointer-arith -Wno-unknown-pragmas -O3"
#define GT_CPPFLAGS "-Wdate-time -D_FORTIFY_SOURCE=2 -D_LARGEFILE_SOURCE -D_FILE_OFFSET_BITS=64 -DHAVE_MEMMOVE -D_LARGEFILE64_SOURCE=1 -DHAVE_HIDDEN -DLUA_DL_DLOPEN -DLUA_USE_MKSTEMP -DGT_THREADS_ENABLED -DHAVE_SQLITE -I./src -I./obj   -I/usr/include/lua5.1  -I/usr/include/lua5.1  -I/usr/include/lua5.1  -I/usr/include/lua5.1  -I/usr/include/lua5.1  -Wdate-time -D_FORTIFY_SOURCE=2  -I/usr/include/pango-1.0 -I/usr/include/glib-2.0 -I/usr/lib/x86_64-linux-gnu/glib-2.0/include -I/usr/include/harfbuzz -I/usr/include/freetype2 -I/usr/include/libpng16 -I/usr/include/libmount -I/usr/include/blkid -I/usr/include/fribidi -I/usr/include/uuid -I/usr/include/cairo -I/usr/include/pixman-1  -I/usr/include/cairo -I/usr/include/glib-2.0 -I/usr/lib/x86_64-linux-gnu/glib-2.0/include -I/usr/include/pixman-1 -I/usr/include/freetype2 -I/usr/include/libpng16 -I/usr/include/uuid  -I/usr/include/pango-1.0 -I/usr/include/glib-2.0 -I/usr/lib/x86_64-linux-gnu/glib-2.0/include -I/usr/include/harfbuzz -I/usr/include/freetype2 -I/usr/include/libpng16 -I/usr/include/libmount -I/usr/include/blkid -I/usr/include/fribidi -I/usr/include/uuid -I/usr/include/cairo -I/usr/include/pixman-1  -I/usr/include/glib-2.0 -I/usr/lib/x86_64-linux-gnu/glib-2.0/include "
#define GT_VERSION "1.6.2"
#define GT_MAJOR_VERSION 1
#define GT_MINOR_VERSION 6
#define GT_MICRO_VERSION 2
#endif
