var searchData=
[
  ['changeexpiryjob_0',['ChangeExpiryJob',['../classQGpgME_1_1ChangeExpiryJob.html',1,'QGpgME']]],
  ['changeownertrustjob_1',['ChangeOwnerTrustJob',['../classQGpgME_1_1ChangeOwnerTrustJob.html',1,'QGpgME']]],
  ['changepasswdjob_2',['ChangePasswdJob',['../classQGpgME_1_1ChangePasswdJob.html',1,'QGpgME']]],
  ['context_3',['context',['../classQGpgME_1_1Job.html#a1638e64ae3b98674bb649f45f1966353',1,'QGpgME::Job']]]
];
