var searchData=
[
  ['refreshkeysjob_0',['refreshKeysJob',['../classQGpgME_1_1Protocol.html#ae711378b6049303c953b3b54b01729af',1,'QGpgME::Protocol']]],
  ['result_1',['result',['../classQGpgME_1_1GpgCardJob.html#a864aa8766836cbfbf9f688e9a98282e9',1,'QGpgME::GpgCardJob::result()'],['../classQGpgME_1_1KeyForMailboxJob.html#a13bde751df9f137ad81909f1a2636cd1',1,'QGpgME::KeyForMailboxJob::result()']]]
];
