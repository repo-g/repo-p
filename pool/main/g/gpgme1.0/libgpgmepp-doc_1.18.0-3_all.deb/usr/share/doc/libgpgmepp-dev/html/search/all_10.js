var searchData=
[
  ['verifydetachedjob_0',['VerifyDetachedJob',['../classQGpgME_1_1VerifyDetachedJob.html',1,'QGpgME']]],
  ['verifyopaquejob_1',['VerifyOpaqueJob',['../classQGpgME_1_1VerifyOpaqueJob.html',1,'QGpgME']]]
];
