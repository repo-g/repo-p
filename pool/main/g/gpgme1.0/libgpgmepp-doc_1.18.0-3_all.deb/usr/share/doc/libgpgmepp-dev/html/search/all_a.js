var searchData=
[
  ['multideletejob_0',['MultiDeleteJob',['../classQGpgME_1_1MultiDeleteJob.html',1,'QGpgME']]]
];
