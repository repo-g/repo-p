var searchData=
[
  ['tofupolicyjob_0',['tofuPolicyJob',['../classQGpgME_1_1Protocol.html#ad44192f93abedc0962a6e2781c3d813b',1,'QGpgME::Protocol']]]
];
