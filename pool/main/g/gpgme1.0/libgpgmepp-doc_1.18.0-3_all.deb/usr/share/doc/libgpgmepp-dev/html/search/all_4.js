var searchData=
[
  ['gpgcardjob_0',['GpgCardJob',['../classQGpgME_1_1GpgCardJob.html',1,'QGpgME']]]
];
