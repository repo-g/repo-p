var searchData=
[
  ['context_0',['context',['../classQGpgME_1_1Job.html#a1638e64ae3b98674bb649f45f1966353',1,'QGpgME::Job']]]
];
