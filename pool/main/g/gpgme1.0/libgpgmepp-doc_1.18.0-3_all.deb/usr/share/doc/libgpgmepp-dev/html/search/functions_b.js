var searchData=
[
  ['wkdlookupjob_0',['wkdLookupJob',['../classQGpgME_1_1Protocol.html#ab26d2725545b3174a56431cc064da395',1,'QGpgME::Protocol']]],
  ['wkspublishjob_1',['wksPublishJob',['../classQGpgME_1_1Protocol.html#a6a5d9b2c8f0032df63b712f743872cb1',1,'QGpgME::Protocol']]]
];
