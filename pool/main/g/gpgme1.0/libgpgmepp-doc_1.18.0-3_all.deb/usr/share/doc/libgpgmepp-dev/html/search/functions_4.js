var searchData=
[
  ['keyformailboxjob_0',['keyForMailboxJob',['../classQGpgME_1_1Protocol.html#aa8c7f09878e227d0e6194563b6e5c4bb',1,'QGpgME::Protocol']]]
];
