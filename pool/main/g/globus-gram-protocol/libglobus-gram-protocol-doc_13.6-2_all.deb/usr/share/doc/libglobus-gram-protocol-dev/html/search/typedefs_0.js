var searchData=
[
  ['globus_5fgram_5fprotocol_5fextension_5ft_105',['globus_gram_protocol_extension_t',['../group__globus__gram__protocol__io.html#ga3469e6c745f6e13ed624fd955a5017da',1,'globus_gram_protocol.h']]],
  ['globus_5fgram_5fprotocol_5fhandle_5ft_106',['globus_gram_protocol_handle_t',['../group__globus__gram__protocol__io.html#ga52f0d72e2a837c8ebf8982ae620b8c1f',1,'globus_gram_protocol.h']]]
];
