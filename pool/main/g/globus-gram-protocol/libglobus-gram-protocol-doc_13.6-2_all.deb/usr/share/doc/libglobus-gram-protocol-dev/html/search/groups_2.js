var searchData=
[
  ['gram_20error_20codes_131',['GRAM Error codes',['../group__globus__gram__protocol__error.html',1,'']]],
  ['gram_20job_20states_132',['GRAM Job States',['../group__globus__gram__protocol__job__state.html',1,'']]],
  ['gram_20protocol_133',['GRAM Protocol',['../group__globus__gram__protocol.html',1,'']]],
  ['gram_20signals_134',['GRAM Signals',['../group__globus__gram__protocol__job__signal.html',1,'']]]
];
