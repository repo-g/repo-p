var searchData=
[
  ['globus_5fgram_5fprotocol_5ferror_5ft_107',['globus_gram_protocol_error_t',['../group__globus__gram__protocol__error.html#ga863534740ac3b78cff476a36d197bfad',1,'globus_gram_protocol_constants.h']]],
  ['globus_5fgram_5fprotocol_5fjob_5fsignal_5ft_108',['globus_gram_protocol_job_signal_t',['../group__globus__gram__protocol__job__signal.html#ga7f97d16875a469bdbcc608919bbab2e1',1,'globus_gram_protocol_constants.h']]],
  ['globus_5fgram_5fprotocol_5fjob_5fstate_5ft_109',['globus_gram_protocol_job_state_t',['../group__globus__gram__protocol__job__state.html#ga7ee774d35df5e9243f18c998aef47936',1,'globus_gram_protocol_constants.h']]]
];
