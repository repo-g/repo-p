var searchData=
[
  ['globus_20gssapi_20error_20api_22',['Globus GSSAPI Error API',['../group__globus__gssapi__error__api.html',1,'']]]
];
