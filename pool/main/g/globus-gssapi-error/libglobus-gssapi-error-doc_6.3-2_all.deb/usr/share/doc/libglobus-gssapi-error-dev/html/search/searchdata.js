var indexSectionsWithContent =
{
  0: "eg",
  1: "g",
  2: "eg",
  3: "g"
};

var indexSectionNames =
{
  0: "all",
  1: "functions",
  2: "groups",
  3: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Functions",
  2: "Modules",
  3: "Pages"
};

