var searchData=
[
  ['error_20construction_0',['Error Construction',['../group__globus__gssapi__error__object.html',1,'']]],
  ['error_20data_20accessors_20and_20modifiers_1',['Error Data Accessors and Modifiers',['../group__globus__gssapi__error__accessor.html',1,'']]],
  ['error_20handling_20helpers_2',['Error Handling Helpers',['../group__globus__gssapi__error__utility.html',1,'']]]
];
