var sink__pydoc__template_8h =
[
    [ "D", "sink__pydoc__template_8h.html#a74021f021dcdfbb22891787b79c5529d", null ],
    [ "__doc_gr_limesdr_sink", "sink__pydoc__template_8h.html#a535a72b02f56d470c9c19c1f3fc17eee", null ],
    [ "__doc_gr_limesdr_sink_calibrate", "sink__pydoc__template_8h.html#a7ab34b0309f5048dc8b4819a94393828", null ],
    [ "__doc_gr_limesdr_sink_make", "sink__pydoc__template_8h.html#a15d910bf43835f4c72db9d9762bcdcaa", null ],
    [ "__doc_gr_limesdr_sink_set_antenna", "sink__pydoc__template_8h.html#a8a04d9e8990759123b83cc842972754d", null ],
    [ "__doc_gr_limesdr_sink_set_bandwidth", "sink__pydoc__template_8h.html#a5575f9628fd1f1bcabd035d4aced1387", null ],
    [ "__doc_gr_limesdr_sink_set_buffer_size", "sink__pydoc__template_8h.html#ae984f2823f90b70342de76e1b71ce310", null ],
    [ "__doc_gr_limesdr_sink_set_center_freq", "sink__pydoc__template_8h.html#aac82c6e9963d2b4ec448cf0468e1dc9a", null ],
    [ "__doc_gr_limesdr_sink_set_digital_filter", "sink__pydoc__template_8h.html#a6f80dd8f9dd4c6fbcf97fdeb2e38fcae", null ],
    [ "__doc_gr_limesdr_sink_set_gain", "sink__pydoc__template_8h.html#a39aec6431a82f37b1d0d843393a85b3c", null ],
    [ "__doc_gr_limesdr_sink_set_nco", "sink__pydoc__template_8h.html#a0e32ae946c8fd2fb25d8427104f40db9", null ],
    [ "__doc_gr_limesdr_sink_set_oversampling", "sink__pydoc__template_8h.html#aa6044256832e1019c356c4a70eb3a863", null ],
    [ "__doc_gr_limesdr_sink_set_sample_rate", "sink__pydoc__template_8h.html#afc93eecd49ff8da66eac9facb9616e33", null ],
    [ "__doc_gr_limesdr_sink_set_tcxo_dac", "sink__pydoc__template_8h.html#acdf4c83285b44c9d55c61812b82f6583", null ],
    [ "__doc_gr_limesdr_sink_sink_0", "sink__pydoc__template_8h.html#ad97a96ab8ea9e855faa57fe99fa53002", null ],
    [ "__doc_gr_limesdr_sink_sink_1", "sink__pydoc__template_8h.html#a859ed0de3117ff7d70fccd680ce9db95", null ]
];