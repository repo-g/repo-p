var annotated_dup =
[
    [ "gr", "namespacegr.html", [
      [ "limesdr", "namespacegr_1_1limesdr.html", [
        [ "rfe", "classgr_1_1limesdr_1_1rfe.html", "classgr_1_1limesdr_1_1rfe" ],
        [ "sink", "classgr_1_1limesdr_1_1sink.html", "classgr_1_1limesdr_1_1sink" ],
        [ "sink_impl", "classgr_1_1limesdr_1_1sink__impl.html", "classgr_1_1limesdr_1_1sink__impl" ],
        [ "source", "classgr_1_1limesdr_1_1source.html", "classgr_1_1limesdr_1_1source" ],
        [ "source_impl", "classgr_1_1limesdr_1_1source__impl.html", "classgr_1_1limesdr_1_1source__impl" ]
      ] ]
    ] ],
    [ "device_handler", "classdevice__handler.html", "classdevice__handler" ]
];