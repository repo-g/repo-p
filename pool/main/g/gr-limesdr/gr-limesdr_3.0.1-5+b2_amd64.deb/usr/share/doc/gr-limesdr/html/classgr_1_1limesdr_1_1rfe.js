var classgr_1_1limesdr_1_1rfe =
[
    [ "rfe", "classgr_1_1limesdr_1_1rfe.html#a61d36419bbb1b791e5779c87147ff663", null ],
    [ "~rfe", "classgr_1_1limesdr_1_1rfe.html#a966b5ccf8cacd7f8327f525e546cb8a7", null ],
    [ "change_mode", "classgr_1_1limesdr_1_1rfe.html#acd06fa9ba5a00f3b7dcae83c376524d5", null ],
    [ "set_attenuation", "classgr_1_1limesdr_1_1rfe.html#a0e5d26e95499293719a074e538a61cbb", null ],
    [ "set_fan", "classgr_1_1limesdr_1_1rfe.html#a5a818862739bcd32e47be1e3f7787ccf", null ],
    [ "set_notch", "classgr_1_1limesdr_1_1rfe.html#ab7b53ad02a6844a1c12ff055e1129875", null ]
];