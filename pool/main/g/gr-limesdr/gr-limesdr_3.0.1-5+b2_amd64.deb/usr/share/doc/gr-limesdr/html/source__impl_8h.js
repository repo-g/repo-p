var source__impl_8h =
[
    [ "gr::limesdr::source_impl", "classgr_1_1limesdr_1_1source__impl.html", "classgr_1_1limesdr_1_1source__impl" ],
    [ "TIME_TAG", "source__impl_8h.html#ad6ad3ffdbfa8f7a181221fb2b7b221a7", null ]
];