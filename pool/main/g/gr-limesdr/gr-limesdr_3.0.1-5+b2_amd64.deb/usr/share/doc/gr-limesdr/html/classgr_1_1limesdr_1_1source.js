var classgr_1_1limesdr_1_1source =
[
    [ "sptr", "classgr_1_1limesdr_1_1source.html#acd29e40524cea5fa2ec7c84464fc2054", null ],
    [ "calibrate", "classgr_1_1limesdr_1_1source.html#aa3b7226a6d39fb9118d4da0425e4029a", null ],
    [ "make", "classgr_1_1limesdr_1_1source.html#ad7b46fccc48afd9145f40f915fe1144a", null ],
    [ "set_antenna", "classgr_1_1limesdr_1_1source.html#af1907d82222150d77cd594a3b8249d2c", null ],
    [ "set_bandwidth", "classgr_1_1limesdr_1_1source.html#ab1ac1b35e6dc05d8da0d36b3a5cb9e31", null ],
    [ "set_buffer_size", "classgr_1_1limesdr_1_1source.html#a781e3bb153a6da5d43bbb454a59e730a", null ],
    [ "set_center_freq", "classgr_1_1limesdr_1_1source.html#adba834bd9e792f7436528cbdb77d7697", null ],
    [ "set_digital_filter", "classgr_1_1limesdr_1_1source.html#a6042356436bccb5a8b95bd93c026ad9f", null ],
    [ "set_gain", "classgr_1_1limesdr_1_1source.html#a22d09b2a21f0fc58f444ecbc5f7c9622", null ],
    [ "set_nco", "classgr_1_1limesdr_1_1source.html#a4fe10596978902a51d29a2a6b43e95dc", null ],
    [ "set_oversampling", "classgr_1_1limesdr_1_1source.html#af9b247b22ddabe66e01927ca8e66ae3a", null ],
    [ "set_sample_rate", "classgr_1_1limesdr_1_1source.html#af4faa5e9d62d527db40bd9171d229825", null ],
    [ "set_tcxo_dac", "classgr_1_1limesdr_1_1source.html#a842b2eaed035a66d0840163c67828049", null ]
];