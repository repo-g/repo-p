var sink__impl_8h =
[
    [ "gr::limesdr::sink_impl", "classgr_1_1limesdr_1_1sink__impl.html", "classgr_1_1limesdr_1_1sink__impl" ],
    [ "TIME_TAG", "sink__impl_8h.html#ad6ad3ffdbfa8f7a181221fb2b7b221a7", null ]
];