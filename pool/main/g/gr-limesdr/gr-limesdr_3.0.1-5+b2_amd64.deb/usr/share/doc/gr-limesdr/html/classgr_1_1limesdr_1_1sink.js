var classgr_1_1limesdr_1_1sink =
[
    [ "sptr", "classgr_1_1limesdr_1_1sink.html#aa3fc352b1b9d08070a155b91461ccc4f", null ],
    [ "calibrate", "classgr_1_1limesdr_1_1sink.html#ae000c93789ce88da2757820650c8db95", null ],
    [ "make", "classgr_1_1limesdr_1_1sink.html#a784625da90c66ef502d1eb178e28f524", null ],
    [ "set_antenna", "classgr_1_1limesdr_1_1sink.html#a686b7b49530c3d3a9bd4311727070dbf", null ],
    [ "set_bandwidth", "classgr_1_1limesdr_1_1sink.html#a8a882cde87ee8656abab6fcb50744cdd", null ],
    [ "set_buffer_size", "classgr_1_1limesdr_1_1sink.html#af4289ac3ecc155ddf47e5486ba5be385", null ],
    [ "set_center_freq", "classgr_1_1limesdr_1_1sink.html#a62a98a2aff746ae41aec5735d36be7de", null ],
    [ "set_digital_filter", "classgr_1_1limesdr_1_1sink.html#a1c778956a814eab15eb294b5bb1a1796", null ],
    [ "set_gain", "classgr_1_1limesdr_1_1sink.html#ab4c7d15468e2064dbab6a1b9d001b047", null ],
    [ "set_nco", "classgr_1_1limesdr_1_1sink.html#ac0b7aaa0cdc77b79521fdfec1580a3f5", null ],
    [ "set_oversampling", "classgr_1_1limesdr_1_1sink.html#af66efdccc38c744d716068f62ebcde43", null ],
    [ "set_sample_rate", "classgr_1_1limesdr_1_1sink.html#a5ec207a345ac78891923368c8e284e8c", null ],
    [ "set_tcxo_dac", "classgr_1_1limesdr_1_1sink.html#a39ac01cf73b12c7cc10b361cdeacefa5", null ]
];