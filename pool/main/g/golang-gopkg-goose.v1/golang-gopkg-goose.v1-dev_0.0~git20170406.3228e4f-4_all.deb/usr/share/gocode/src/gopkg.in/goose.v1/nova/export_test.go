package nova

func UseNumericIds(val bool) {
	useNumericIds = val
}
