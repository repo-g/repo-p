// Copyright 2017 Global Phasing Ltd.

// Version number.

#ifndef GEMMI_VERSION_HPP_
#define GEMMI_VERSION_HPP_

#define GEMMI_VERSION "0.5.7"

#endif
