package blobstore

import (
	"hash"
)

type hashFunc func() hash.Hash

// vim: foldmethod=marker
