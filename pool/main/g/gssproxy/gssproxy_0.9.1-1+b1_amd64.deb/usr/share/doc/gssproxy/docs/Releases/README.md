This directory is historical.
Releases are document on the Github
[Releases](https://github.com/gssapi/gssproxy/releases) page.
