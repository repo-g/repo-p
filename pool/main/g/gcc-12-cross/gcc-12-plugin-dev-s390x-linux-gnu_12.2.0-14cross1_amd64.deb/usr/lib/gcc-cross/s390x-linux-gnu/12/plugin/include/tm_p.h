#ifndef GCC_TM_P_H
#define GCC_TM_P_H
#ifdef IN_GCC
# include "config/linux-protos.h"
# include "config/s390/s390-protos.h"
# include "tm-preds.h"
#endif
#endif /* GCC_TM_P_H */
