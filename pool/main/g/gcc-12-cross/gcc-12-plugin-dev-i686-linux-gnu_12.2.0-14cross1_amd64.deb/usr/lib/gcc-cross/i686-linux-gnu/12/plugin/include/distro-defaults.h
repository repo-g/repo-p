/* distro specific configuration injected by the distro build.  */

#ifndef ACCEL_COMPILER
#define DIST_DEFAULT_ASYNC_UNWIND 1
#endif
