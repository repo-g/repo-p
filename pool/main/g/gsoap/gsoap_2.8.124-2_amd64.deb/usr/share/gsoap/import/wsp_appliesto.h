//gsoap wsp   schema import:	http://schemas.xmlsoap.org/ws/2004/09/policy
//gsoap wsp   schema elementForm:	qualified
//gsoap wsp   schema attributeForm:	unqualified

typedef struct _wsp__AppliesTo_
{
  wsa5__EndpointReferenceType *wsa5__EndpointReference;
} _wsp__AppliesTo_;
