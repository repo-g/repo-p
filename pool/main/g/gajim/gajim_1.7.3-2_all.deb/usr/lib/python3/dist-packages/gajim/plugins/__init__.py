

from .gajimplugin import GajimPlugin

__all__ = ['GajimPlugin']
