var indexSectionsWithContent =
{
  0: "adg",
  1: "g",
  2: "g",
  3: "g",
  4: "adg"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "enums",
  3: "enumvalues",
  4: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Enumerations",
  3: "Enumerator",
  4: "Modules"
};

