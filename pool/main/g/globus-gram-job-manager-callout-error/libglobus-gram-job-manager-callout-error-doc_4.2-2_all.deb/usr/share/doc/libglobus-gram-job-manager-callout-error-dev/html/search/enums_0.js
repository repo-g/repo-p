var searchData=
[
  ['globus_5fgram_5fjobmanager_5fcallout_5ferror_5ft_13',['globus_gram_jobmanager_callout_error_t',['../group__globus__gram__jobmanager__callout__error__datatypes.html#ga9773daa4c847a877c14df7c6a2a45468',1,'globus_gram_jobmanager_callout_error.h']]]
];
