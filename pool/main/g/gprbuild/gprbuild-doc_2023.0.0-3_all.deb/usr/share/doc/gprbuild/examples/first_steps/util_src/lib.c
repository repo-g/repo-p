#include <stdio.h>
#include "lib.h"

void do_something (void) {
    printf ("Doing something in C \n");
}
