var classgr_1_1gsm_1_1msg__to__tag =
[
    [ "sptr", "classgr_1_1gsm_1_1msg__to__tag.html#a8c1454076270ba0ba0dd4b7c34d0f331", null ],
    [ "make", "classgr_1_1gsm_1_1msg__to__tag.html#a36de09912d03782091f67506255ec1e0", null ]
];