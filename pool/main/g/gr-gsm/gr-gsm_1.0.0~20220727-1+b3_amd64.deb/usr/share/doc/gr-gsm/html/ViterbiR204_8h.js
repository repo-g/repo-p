var ViterbiR204_8h =
[
    [ "ViterbiR2O4", "classViterbiR2O4.html", "classViterbiR2O4" ],
    [ "ViterbiR2O4::candStruct", "structViterbiR2O4_1_1candStruct.html", "structViterbiR2O4_1_1candStruct" ]
];