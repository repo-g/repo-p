var classgr_1_1gsm_1_1trx__burst__if__impl =
[
    [ "trx_burst_if_impl", "classgr_1_1gsm_1_1trx__burst__if__impl.html#ad7a631475691fbceb26e8ee744f757a3", null ],
    [ "~trx_burst_if_impl", "classgr_1_1gsm_1_1trx__burst__if__impl.html#ad58471e699f0da0af33fdf2db787ed2d", null ],
    [ "handle_dl_burst", "classgr_1_1gsm_1_1trx__burst__if__impl.html#aa7e03d34e6836dcf6429d986760f0d32", null ],
    [ "handle_ul_burst", "classgr_1_1gsm_1_1trx__burst__if__impl.html#ad8c64ac2cdb8ecf5001b38f1b14dadf3", null ]
];