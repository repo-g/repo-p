var classchannel__configuration =
[
    [ "channel_configuration", "classchannel__configuration.html#a19d5fa94b4c5173100b09b90e78ad39a", null ],
    [ "get_burst_type", "classchannel__configuration.html#a1223a8ff481e67fe18a2617483b8601b", null ],
    [ "set_burst_types", "classchannel__configuration.html#a1d2d4a20d258eaf25d98842f35ab6bd2", null ],
    [ "set_multiframe_type", "classchannel__configuration.html#ad9426ea9848ac69ab28b678dbbd7affc", null ],
    [ "set_single_burst_type", "classchannel__configuration.html#a447cc480b48d842f3b6c7b28631898c9", null ]
];