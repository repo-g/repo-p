var classgr_1_1gsm_1_1tch__h__chans__demapper =
[
    [ "sptr", "classgr_1_1gsm_1_1tch__h__chans__demapper.html#aee2971fe363b3497be5a81cd454012cd", null ],
    [ "make", "classgr_1_1gsm_1_1tch__h__chans__demapper.html#aee843225891fe3bf9bdfefde5b6f08d7", null ]
];