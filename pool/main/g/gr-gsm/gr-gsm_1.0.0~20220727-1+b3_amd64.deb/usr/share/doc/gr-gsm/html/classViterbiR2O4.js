var classViterbiR2O4 =
[
    [ "candStruct", "structViterbiR2O4_1_1candStruct.html", "structViterbiR2O4_1_1candStruct" ],
    [ "vCand", "classViterbiR2O4.html#ad670b3911841f1512c92bd176d1e9579", null ],
    [ "ViterbiR2O4", "classViterbiR2O4.html#ad5cc54247af785f5c7c5b281bbc90778", null ],
    [ "cMask", "classViterbiR2O4.html#af03648683c67799c129409a674423a92", null ],
    [ "decode", "classViterbiR2O4.html#a3287df605b7b285f01b4cffd7465270f", null ],
    [ "deferral", "classViterbiR2O4.html#a589960526d6ee62d64d5e0ab293c99cf", null ],
    [ "encode", "classViterbiR2O4.html#aa13f33775022578344e87269477d49d3", null ],
    [ "getBEC", "classViterbiR2O4.html#a1ed9cf20dcbd9da02b908e13a20e49bd", null ],
    [ "initializeStates", "classViterbiR2O4.html#aa0f2aeea92f1d0f37448084a57f78b14", null ],
    [ "iRate", "classViterbiR2O4.html#a7ddc706c555bd3da327abb5c95d034cb", null ],
    [ "stateTable", "classViterbiR2O4.html#a18c5dba9db91dffc249f270e4bbac400", null ],
    [ "vitClear", "classViterbiR2O4.html#a50d8498423e53dc0cc3ab470e63fca8b", null ],
    [ "vstep", "classViterbiR2O4.html#a689e9bde67ec39ee4d6f7be5648652c1", null ]
];