var burst__fnr__filter_8h =
[
    [ "gr::gsm::burst_fnr_filter", "classgr_1_1gsm_1_1burst__fnr__filter.html", "classgr_1_1gsm_1_1burst__fnr__filter" ],
    [ "filter_mode", "burst__fnr__filter_8h.html#aa441f4f8504bf09f4a74744878c9d08b", [
      [ "FILTER_LESS_OR_EQUAL", "burst__fnr__filter_8h.html#aa441f4f8504bf09f4a74744878c9d08ba39f0c9a1b8555f080d099ce93ef8dd2f", null ],
      [ "FILTER_GREATER_OR_EQUAL", "burst__fnr__filter_8h.html#aa441f4f8504bf09f4a74744878c9d08bab7a5cc6bb1600101e98d56276407d563", null ]
    ] ]
];