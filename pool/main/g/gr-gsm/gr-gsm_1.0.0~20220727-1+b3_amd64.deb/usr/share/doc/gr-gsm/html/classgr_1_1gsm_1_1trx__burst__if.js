var classgr_1_1gsm_1_1trx__burst__if =
[
    [ "sptr", "classgr_1_1gsm_1_1trx__burst__if.html#a6a77fdb08ecaf5c5c421b4045a41e5fb", null ],
    [ "make", "classgr_1_1gsm_1_1trx__burst__if.html#a7762f8deb55ac84fe5b360b86e9486db", null ]
];