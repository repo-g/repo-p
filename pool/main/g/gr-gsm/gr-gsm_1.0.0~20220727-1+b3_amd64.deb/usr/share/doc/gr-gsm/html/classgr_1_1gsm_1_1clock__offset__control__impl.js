var classgr_1_1gsm_1_1clock__offset__control__impl =
[
    [ "clock_offset_control_impl", "classgr_1_1gsm_1_1clock__offset__control__impl.html#a5704738f69f625ba13143c718202d6e8", null ],
    [ "~clock_offset_control_impl", "classgr_1_1gsm_1_1clock__offset__control__impl.html#af05ecb95affb2f3d1cff6ebe86392375", null ],
    [ "set_fc", "classgr_1_1gsm_1_1clock__offset__control__impl.html#a401d95b30ebf95e5051fbe39fc65ec32", null ],
    [ "set_osr", "classgr_1_1gsm_1_1clock__offset__control__impl.html#a4250d1f4531665fa95bd7e8e2887da3d", null ],
    [ "set_samp_rate", "classgr_1_1gsm_1_1clock__offset__control__impl.html#ad30af933effa0f0348c58fb6c3ce85b1", null ]
];