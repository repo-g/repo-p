var classgr_1_1gsm_1_1clock__offset__control =
[
    [ "sptr", "classgr_1_1gsm_1_1clock__offset__control.html#a3aff8e9be5cb6b0dfad41d6c01aec7b6", null ],
    [ "make", "classgr_1_1gsm_1_1clock__offset__control.html#aca479545a40472fc8bff442d473e95e5", null ],
    [ "set_fc", "classgr_1_1gsm_1_1clock__offset__control.html#ac4513490b11cb029feaeb241001f84bf", null ],
    [ "set_osr", "classgr_1_1gsm_1_1clock__offset__control.html#a2213bd322cec99dab3332327e96c440a", null ],
    [ "set_samp_rate", "classgr_1_1gsm_1_1clock__offset__control.html#a11e41fae20cb5a274cd0831634e26d0b", null ]
];