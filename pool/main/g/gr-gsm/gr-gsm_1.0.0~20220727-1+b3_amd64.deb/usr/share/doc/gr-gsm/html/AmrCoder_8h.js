var AmrCoder_8h =
[
    [ "ViterbiTCH_AFS12_2", "classViterbiTCH__AFS12__2.html", "classViterbiTCH__AFS12__2" ],
    [ "ViterbiTCH_AFS12_2::candStruct", "structViterbiTCH__AFS12__2_1_1candStruct.html", "structViterbiTCH__AFS12__2_1_1candStruct" ],
    [ "ViterbiTCH_AFS10_2", "classViterbiTCH__AFS10__2.html", "classViterbiTCH__AFS10__2" ],
    [ "ViterbiTCH_AFS10_2::candStruct", "structViterbiTCH__AFS10__2_1_1candStruct.html", "structViterbiTCH__AFS10__2_1_1candStruct" ],
    [ "ViterbiTCH_AFS7_95", "classViterbiTCH__AFS7__95.html", "classViterbiTCH__AFS7__95" ],
    [ "ViterbiTCH_AFS7_95::candStruct", "structViterbiTCH__AFS7__95_1_1candStruct.html", "structViterbiTCH__AFS7__95_1_1candStruct" ],
    [ "ViterbiTCH_AFS7_4", "classViterbiTCH__AFS7__4.html", "classViterbiTCH__AFS7__4" ],
    [ "ViterbiTCH_AFS7_4::candStruct", "structViterbiTCH__AFS7__4_1_1candStruct.html", "structViterbiTCH__AFS7__4_1_1candStruct" ],
    [ "ViterbiTCH_AFS6_7", "classViterbiTCH__AFS6__7.html", "classViterbiTCH__AFS6__7" ],
    [ "ViterbiTCH_AFS6_7::candStruct", "structViterbiTCH__AFS6__7_1_1candStruct.html", "structViterbiTCH__AFS6__7_1_1candStruct" ],
    [ "ViterbiTCH_AFS5_9", "classViterbiTCH__AFS5__9.html", "classViterbiTCH__AFS5__9" ],
    [ "ViterbiTCH_AFS5_9::candStruct", "structViterbiTCH__AFS5__9_1_1candStruct.html", "structViterbiTCH__AFS5__9_1_1candStruct" ],
    [ "ViterbiTCH_AFS5_15", "classViterbiTCH__AFS5__15.html", "classViterbiTCH__AFS5__15" ],
    [ "ViterbiTCH_AFS5_15::candStruct", "structViterbiTCH__AFS5__15_1_1candStruct.html", "structViterbiTCH__AFS5__15_1_1candStruct" ],
    [ "ViterbiTCH_AFS4_75", "classViterbiTCH__AFS4__75.html", "classViterbiTCH__AFS4__75" ],
    [ "ViterbiTCH_AFS4_75::candStruct", "structViterbiTCH__AFS4__75_1_1candStruct.html", "structViterbiTCH__AFS4__75_1_1candStruct" ]
];