var clock__offset__control_8h =
[
    [ "gr::gsm::clock_offset_control", "classgr_1_1gsm_1_1clock__offset__control.html", "classgr_1_1gsm_1_1clock__offset__control" ]
];