var classgr_1_1gsm_1_1tch__h__decoder =
[
    [ "sptr", "classgr_1_1gsm_1_1tch__h__decoder.html#af0ce0c4fb50910b7d2fb1173a43dcc5c", null ],
    [ "make", "classgr_1_1gsm_1_1tch__h__decoder.html#aeda61bc7c4c966cf6e9a20f6031900c1", null ]
];