var classgr_1_1gsm_1_1universal__ctrl__chans__demapper =
[
    [ "sptr", "classgr_1_1gsm_1_1universal__ctrl__chans__demapper.html#a6bb41ec2749a69cf87499fc224a21317", null ],
    [ "make", "classgr_1_1gsm_1_1universal__ctrl__chans__demapper.html#aca214dc04990529aa012166fade69feb", null ]
];