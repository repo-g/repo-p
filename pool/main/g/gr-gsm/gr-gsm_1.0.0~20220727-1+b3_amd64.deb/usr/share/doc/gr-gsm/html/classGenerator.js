var classGenerator =
[
    [ "Generator", "classGenerator.html#afb6553ab338466e309e146a7a6c2da81", null ],
    [ "clear", "classGenerator.html#a785520f8fdfb2f7394ed414d21ae847a", null ],
    [ "encoderShift", "classGenerator.html#a927df3986f8d2868201623ee471e5861", null ],
    [ "size", "classGenerator.html#a5e636dfcd5069de5a7a6fe257584b99c", null ],
    [ "state", "classGenerator.html#a0652246112c0d16a54f588ad0eb8a475", null ],
    [ "syndromeShift", "classGenerator.html#a37a68fd0bfe9b5f89a6351a5ac6de637", null ]
];