var classgr_1_1gsm_1_1txtime__setter__impl =
[
    [ "txtime_setter_impl", "classgr_1_1gsm_1_1txtime__setter__impl.html#aa98065cd10e3d2cecf82f3ae56584002", null ],
    [ "~txtime_setter_impl", "classgr_1_1gsm_1_1txtime__setter__impl.html#a7a575e4a54cc068142c522616bf1ef47", null ],
    [ "set_delay_correction", "classgr_1_1gsm_1_1txtime__setter__impl.html#a7fedb01e0eabb94612d1f27e0526533f", null ],
    [ "set_fn_time_reference", "classgr_1_1gsm_1_1txtime__setter__impl.html#a3a8f901cd9192e1882f5a63bfc9f411d", null ],
    [ "set_time_hint", "classgr_1_1gsm_1_1txtime__setter__impl.html#a19838d26df2c61ce4133d396536dd179", null ],
    [ "set_timing_advance", "classgr_1_1gsm_1_1txtime__setter__impl.html#a5eac141fc6a786c88d8956b78a665811", null ]
];