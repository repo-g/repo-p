var classgr_1_1gsm_1_1tch__f__chans__demapper =
[
    [ "sptr", "classgr_1_1gsm_1_1tch__f__chans__demapper.html#a4637984092ffcea71e4d836d9d572304", null ],
    [ "make", "classgr_1_1gsm_1_1tch__f__chans__demapper.html#a7c8a361524ecb163309b9ae67134624f", null ]
];