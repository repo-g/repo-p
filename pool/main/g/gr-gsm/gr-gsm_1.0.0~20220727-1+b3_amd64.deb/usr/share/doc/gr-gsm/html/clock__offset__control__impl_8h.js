var clock__offset__control__impl_8h =
[
    [ "gr::gsm::clock_offset_control_impl", "classgr_1_1gsm_1_1clock__offset__control__impl.html", "classgr_1_1gsm_1_1clock__offset__control__impl" ]
];