var classgr_1_1gsm_1_1time__sample__ref =
[
    [ "time_sample_ref", "classgr_1_1gsm_1_1time__sample__ref.html#ae67047d8b6a9b48153f1a89b6d569344", null ],
    [ "~time_sample_ref", "classgr_1_1gsm_1_1time__sample__ref.html#a62d132031e3c1397d6d2fbb04acb18be", null ],
    [ "offset_to_time", "classgr_1_1gsm_1_1time__sample__ref.html#acab952f190316e37d93aa20d126397c8", null ],
    [ "time_to_offset", "classgr_1_1gsm_1_1time__sample__ref.html#a7f62ab42f8ca18c199efa1674112906b", null ],
    [ "update", "classgr_1_1gsm_1_1time__sample__ref.html#a44197cc07e799d4291236e7ea529d960", null ]
];