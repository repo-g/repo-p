var dir_0a936157b67ae669bab82e288cc95218 =
[
    [ "tch_f_chans_demapper.h", "tch__f__chans__demapper_8h.html", "tch__f__chans__demapper_8h" ],
    [ "tch_h_chans_demapper.h", "tch__h__chans__demapper_8h.html", "tch__h__chans__demapper_8h" ],
    [ "universal_ctrl_chans_demapper.h", "universal__ctrl__chans__demapper_8h.html", "universal__ctrl__chans__demapper_8h" ]
];