var classgr_1_1gsm_1_1immediate__assignment =
[
    [ "immediate_assignment", "classgr_1_1gsm_1_1immediate__assignment.html#a5cecf3766947a2de3e859cc2e2f6b468", null ],
    [ "~immediate_assignment", "classgr_1_1gsm_1_1immediate__assignment.html#aabfce0912d8af0466a438a6c9b317ba7", null ],
    [ "arfcn", "classgr_1_1gsm_1_1immediate__assignment.html#a5800035ba49c49894dce8e076ffd38ce", null ],
    [ "arfcn_id", "classgr_1_1gsm_1_1immediate__assignment.html#a5f7702600b9d549cfea2d63f0e777627", null ],
    [ "channel_type", "classgr_1_1gsm_1_1immediate__assignment.html#ada97a0c9bbc7af07d10ffdfdd363f59a", null ],
    [ "frame_nr", "classgr_1_1gsm_1_1immediate__assignment.html#a0e5f0fddf8f7fe85e6fed0d8d4ddadce", null ],
    [ "hopping", "classgr_1_1gsm_1_1immediate__assignment.html#ae9ea8e8e91df79bf04620467e4d07800", null ],
    [ "hsn", "classgr_1_1gsm_1_1immediate__assignment.html#afea0a640f7476eb0e88d29e0917ea4a6", null ],
    [ "maio", "classgr_1_1gsm_1_1immediate__assignment.html#ae41b44c441577c423468a31f6f5793a8", null ],
    [ "mobile_allocation", "classgr_1_1gsm_1_1immediate__assignment.html#ad9cf00f6925cc80bc46fe78c3affa39a", null ],
    [ "subchannel", "classgr_1_1gsm_1_1immediate__assignment.html#ae2db573ecbbe131d2e3c0bf17b954468", null ],
    [ "timeslot", "classgr_1_1gsm_1_1immediate__assignment.html#a8752d73bb0d8db2a8b4568c731ca6d72", null ],
    [ "timing_advance", "classgr_1_1gsm_1_1immediate__assignment.html#a50515422cb846eff0cc359bd6991a487", null ],
    [ "tseq", "classgr_1_1gsm_1_1immediate__assignment.html#a622aabb448515034bfdf3122b930ac72", null ]
];