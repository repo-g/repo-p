var classmultiframe__configuration =
[
    [ "multiframe_configuration", "classmultiframe__configuration.html#a086e8ca45c43f3a11789f5edbf7dfb90", null ],
    [ "~multiframe_configuration", "classmultiframe__configuration.html#a4c664ed97471bd370142e65386a782dc", null ],
    [ "get_burst_type", "classmultiframe__configuration.html#a1009485aee009d63db5b35871b94c0fd", null ],
    [ "get_type", "classmultiframe__configuration.html#aea4a182e0de81416cef0e2b37de52567", null ],
    [ "set_burst_type", "classmultiframe__configuration.html#acbe96f4f36cff7a629dbb2bd940fc6fe", null ],
    [ "set_type", "classmultiframe__configuration.html#a367381099331b196b6fc905aec02bc12", null ]
];