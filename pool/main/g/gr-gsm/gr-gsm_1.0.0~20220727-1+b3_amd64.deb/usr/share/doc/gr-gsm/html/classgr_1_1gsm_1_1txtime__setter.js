var classgr_1_1gsm_1_1txtime__setter =
[
    [ "sptr", "classgr_1_1gsm_1_1txtime__setter.html#a478c4c6053a717240a08dc827e3f1138", null ],
    [ "make", "classgr_1_1gsm_1_1txtime__setter.html#a653bdd9f1c65e5fce378b88a1f0f4707", null ],
    [ "set_delay_correction", "classgr_1_1gsm_1_1txtime__setter.html#a0fb99b621b474574f6a0bf06355939bd", null ],
    [ "set_fn_time_reference", "classgr_1_1gsm_1_1txtime__setter.html#a17b9ccbe85919670d565d5d29e63b2eb", null ],
    [ "set_time_hint", "classgr_1_1gsm_1_1txtime__setter.html#aded5f2d44daa88fb43bac87bc4c1f630", null ],
    [ "set_timing_advance", "classgr_1_1gsm_1_1txtime__setter.html#ae774da885713f02188be8222b0d8abc9", null ]
];