function setItemCount() {
    window.location.href = (document.getElementById('page-items').value);
}