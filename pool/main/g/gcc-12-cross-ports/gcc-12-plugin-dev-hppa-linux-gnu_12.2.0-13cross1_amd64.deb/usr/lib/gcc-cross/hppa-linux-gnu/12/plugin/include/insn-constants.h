/* Generated automatically by the program `genconstants'
   from the machine description file `md'.  */

#ifndef GCC_INSN_CONSTANTS_H
#define GCC_INSN_CONSTANTS_H

#define MAX_17BIT_OFFSET 262100
#define MAX_12BIT_OFFSET 8184

enum unspec {
  UNSPEC_CFFC = 0,
  UNSPEC_GOTO = 1,
  UNSPEC_DLTIND14R = 2,
  UNSPEC_TP = 3,
  UNSPEC_TLSGD = 4,
  UNSPEC_TLSLDM = 5,
  UNSPEC_TLSLDO = 6,
  UNSPEC_TLSLDBASE = 7,
  UNSPEC_TLSIE = 8,
  UNSPEC_TLSLE = 9,
  UNSPEC_TLSGD_PIC = 10,
  UNSPEC_TLSLDM_PIC = 11,
  UNSPEC_TLSIE_PIC = 12,
  UNSPEC_MEMORY_BARRIER = 13
};
#define NUM_UNSPEC_VALUES 14
extern const char *const unspec_strings[];

enum unspecv {
  UNSPECV_BLOCKAGE = 0,
  UNSPECV_DCACHE = 1,
  UNSPECV_ICACHE = 2,
  UNSPECV_OPC = 3,
  UNSPECV_OEC = 4,
  UNSPECV_LONGJMP = 5
};
#define NUM_UNSPECV_VALUES 6
extern const char *const unspecv_strings[];

#endif /* GCC_INSN_CONSTANTS_H */
