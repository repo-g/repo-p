/* Generated automatically by the program `genflags'
   from the machine description file `md'.  */

#ifndef GCC_INSN_FLAGS_H
#define GCC_INSN_FLAGS_H

#define HAVE_scc 1
#define HAVE_iorscc 1
#define HAVE_negscc 1
#define HAVE_incscc 1
#define HAVE_decscc 1
#define HAVE_sminsi3 1
#define HAVE_uminsi3 1
#define HAVE_smaxsi3 1
#define HAVE_umaxsi3 1
#define HAVE_absqi2 1
#define HAVE_abshi2 1
#define HAVE_abssi2 1
#define HAVE_bswaphi2 1
#define HAVE_bswapsi2 1
#define HAVE_pre_ldw 1
#define HAVE_post_stw 1
#define HAVE_addhi3 1
#define HAVE_cpymemsi_prereload 1
#define HAVE_cpymemsi_postreload (!TARGET_64BIT && reload_completed)
#define HAVE_clrmemsi_prereload 1
#define HAVE_clrmemsi_postreload (!TARGET_64BIT && reload_completed)
#define HAVE_extendhisi2 1
#define HAVE_extendqihi2 1
#define HAVE_extendqisi2 1
#define HAVE_extendsfdf2 (! TARGET_SOFT_FLOAT)
#define HAVE_truncdfsf2 (! TARGET_SOFT_FLOAT)
#define HAVE_floatsisf2 (! TARGET_SOFT_FLOAT)
#define HAVE_floatsidf2 (! TARGET_SOFT_FLOAT)
#define HAVE_floatdisf2 (TARGET_PA_11 && ! TARGET_SOFT_FLOAT)
#define HAVE_floatdidf2 (TARGET_PA_11 && ! TARGET_SOFT_FLOAT)
#define HAVE_fix_truncsfsi2 (! TARGET_SOFT_FLOAT)
#define HAVE_fix_truncdfsi2 (! TARGET_SOFT_FLOAT)
#define HAVE_fix_truncsfdi2 (TARGET_PA_11 && ! TARGET_SOFT_FLOAT)
#define HAVE_fix_truncdfdi2 (TARGET_PA_11 && ! TARGET_SOFT_FLOAT)
#define HAVE_floatunssidf2_pa20 (! TARGET_SOFT_FLOAT && TARGET_PA_20)
#define HAVE_floatunssisf2_pa20 (! TARGET_SOFT_FLOAT && TARGET_PA_20)
#define HAVE_floatunsdisf2 (! TARGET_SOFT_FLOAT && TARGET_PA_20)
#define HAVE_floatunsdidf2 (! TARGET_SOFT_FLOAT && TARGET_PA_20)
#define HAVE_fixuns_truncsfsi2 (! TARGET_SOFT_FLOAT && TARGET_PA_20)
#define HAVE_fixuns_truncdfsi2 (! TARGET_SOFT_FLOAT && TARGET_PA_20)
#define HAVE_fixuns_truncsfdi2 (! TARGET_SOFT_FLOAT && TARGET_PA_20)
#define HAVE_fixuns_truncdfdi2 (! TARGET_SOFT_FLOAT && TARGET_PA_20)
#define HAVE_addsi3 1
#define HAVE_addvsi3 1
#define HAVE_subvsi3 1
#define HAVE_trap 1
#define HAVE_umulsidi3 (TARGET_PA_11 && ! TARGET_SOFT_FLOAT && ! TARGET_SOFT_MULT)
#define HAVE_andsi3 1
#define HAVE_xorsi3 1
#define HAVE_negsi2 1
#define HAVE_negvsi2 1
#define HAVE_one_cmplsi2 1
#define HAVE_adddf3 (! TARGET_SOFT_FLOAT)
#define HAVE_addsf3 (! TARGET_SOFT_FLOAT)
#define HAVE_subdf3 (! TARGET_SOFT_FLOAT)
#define HAVE_subsf3 (! TARGET_SOFT_FLOAT)
#define HAVE_muldf3 (! TARGET_SOFT_FLOAT)
#define HAVE_mulsf3 (! TARGET_SOFT_FLOAT)
#define HAVE_divdf3 (! TARGET_SOFT_FLOAT)
#define HAVE_divsf3 (! TARGET_SOFT_FLOAT)
#define HAVE_negdf2_slow (!TARGET_SOFT_FLOAT && !TARGET_PA_20)
#define HAVE_negdf2_fast (!TARGET_SOFT_FLOAT)
#define HAVE_negsf2_slow (!TARGET_SOFT_FLOAT && !TARGET_PA_20)
#define HAVE_negsf2_fast (!TARGET_SOFT_FLOAT)
#define HAVE_absdf2 (! TARGET_SOFT_FLOAT)
#define HAVE_abssf2 (! TARGET_SOFT_FLOAT)
#define HAVE_sqrtdf2 (! TARGET_SOFT_FLOAT)
#define HAVE_sqrtsf2 (! TARGET_SOFT_FLOAT)
#define HAVE_fmadf4 (TARGET_PA_20 && ! TARGET_SOFT_FLOAT)
#define HAVE_fmasf4 (TARGET_PA_20 && ! TARGET_SOFT_FLOAT)
#define HAVE_fnmadf4 (TARGET_PA_20 && ! TARGET_SOFT_FLOAT)
#define HAVE_fnmasf4 (TARGET_PA_20 && ! TARGET_SOFT_FLOAT)
#define HAVE_zvdep32 1
#define HAVE_zvdep_imm32 1
#define HAVE_vdepi_ior (exact_log2 (INTVAL (operands[1]) + 1) > 0)
#define HAVE_vdepi_and (INTVAL (operands[1]) == -2)
#define HAVE_vextrs32 1
#define HAVE_lshrsi3 1
#define HAVE_rotrsi3 1
#define HAVE_return (pa_can_use_return_insn ())
#define HAVE_return_internal 1
#define HAVE_return_external_pic (!TARGET_NO_SPACE_REGS \
   && !TARGET_PA_20 \
   && flag_pic && crtl->calls_eh_return)
#define HAVE_load_offset_label_address 1
#define HAVE_lcla1 (!TARGET_PA_20)
#define HAVE_lcla2 (TARGET_PA_20)
#define HAVE_blockage 1
#define HAVE_jump 1
#define HAVE_indirect_jump 1
#define HAVE_indirect_goto (GET_MODE (operands[0]) == word_mode)
#define HAVE_casesi32 (!flag_pic)
#define HAVE_casesi32p (flag_pic)
#define HAVE_casesi64p 1
#define HAVE_call_symref (!TARGET_PORTABLE_RUNTIME && !TARGET_64BIT)
#define HAVE_call_symref_pic (!TARGET_PORTABLE_RUNTIME && !TARGET_64BIT)
#define HAVE_call_reg 1
#define HAVE_call_reg_pic 1
#define HAVE_call_val_symref (!TARGET_PORTABLE_RUNTIME && !TARGET_64BIT)
#define HAVE_call_val_symref_pic (!TARGET_PORTABLE_RUNTIME && !TARGET_64BIT)
#define HAVE_call_val_reg 1
#define HAVE_call_val_reg_pic 1
#define HAVE_call_mcount_nonpic (!TARGET_PORTABLE_RUNTIME && !TARGET_64BIT)
#define HAVE_call_mcount_pic (!TARGET_PORTABLE_RUNTIME && !TARGET_64BIT)
#define HAVE_sibcall_internal_symref (!TARGET_PORTABLE_RUNTIME && !TARGET_64BIT)
#define HAVE_sibcall_value_internal_symref (!TARGET_PORTABLE_RUNTIME && !TARGET_64BIT)
#define HAVE_nop 1
#define HAVE_extzv_32 (UINTVAL (operands[2]) > 0 \
   && UINTVAL (operands[2]) + UINTVAL (operands[3]) <= 32)
#define HAVE_extv_32 (UINTVAL (operands[2]) > 0 \
   && UINTVAL (operands[2]) + UINTVAL (operands[3]) <= 32)
#define HAVE_insv_32 (UINTVAL (operands[1]) > 0 \
   && UINTVAL (operands[1]) + UINTVAL (operands[2]) <= 32)
#define HAVE_decrement_and_branch_until_zero 1
#define HAVE_dcacheflushsi (Pmode == SImode)
#define HAVE_dcacheflushdi (Pmode == DImode)
#define HAVE_icacheflushsi (Pmode == SImode)
#define HAVE_icacheflushdi (Pmode == DImode)
#define HAVE_outline_prologue_call 1
#define HAVE_outline_epilogue_call 1
#define HAVE_prefetch_20 (TARGET_PA_20)
#define HAVE_tgd_load 1
#define HAVE_tgd_load_pic 1
#define HAVE_tld_load 1
#define HAVE_tld_load_pic 1
#define HAVE_tld_offset_load 1
#define HAVE_tp_load 1
#define HAVE_tie_load 1
#define HAVE_tie_load_pic 1
#define HAVE_tle_load 1
#define HAVE_atomic_loaddi_1 (!TARGET_64BIT && !TARGET_SOFT_FLOAT)
#define HAVE_atomic_storedi_1 (!TARGET_64BIT && !TARGET_SOFT_FLOAT)
#define HAVE_movccfp (! TARGET_SOFT_FLOAT)
#define HAVE_cstoresi4 1
#define HAVE_movsicc 1
#define HAVE_cbranchsi4 1
#define HAVE_cbranchsf4 (! TARGET_SOFT_FLOAT)
#define HAVE_cbranchdf4 (! TARGET_SOFT_FLOAT)
#define HAVE_movsi 1
#define HAVE_reload_insi_r1 1
#define HAVE_reload_insi 1
#define HAVE_reload_outsi 1
#define HAVE_pre_load 1
#define HAVE_post_store 1
#define HAVE_movhi 1
#define HAVE_reload_inhi 1
#define HAVE_reload_outhi 1
#define HAVE_movqi 1
#define HAVE_reload_inqi 1
#define HAVE_reload_outqi 1
#define HAVE_cpymemsi (!TARGET_64BIT && optimize > 0)
#define HAVE_setmemsi (!TARGET_64BIT && optimize > 0)
#define HAVE_movdf 1
#define HAVE_reload_indf_r1 1
#define HAVE_reload_indf 1
#define HAVE_reload_outdf 1
#define HAVE_movdi 1
#define HAVE_reload_indi_r1 1
#define HAVE_reload_indi 1
#define HAVE_reload_outdi 1
#define HAVE_movsf 1
#define HAVE_reload_insf_r1 1
#define HAVE_reload_insf 1
#define HAVE_reload_outsf 1
#define HAVE_zero_extendqihi2 1
#define HAVE_zero_extendqisi2 1
#define HAVE_zero_extendhisi2 1
#define HAVE_floatunssisf2 (TARGET_PA_11 && ! TARGET_SOFT_FLOAT)
#define HAVE_floatunssidf2 (TARGET_PA_11 && ! TARGET_SOFT_FLOAT)
#define HAVE_adddi3 1
#define HAVE_addvdi3 1
#define HAVE_subdi3 1
#define HAVE_subvdi3 1
#define HAVE_subsi3 1
#define HAVE_mulsi3 1
#define HAVE_muldi3 (! optimize_size \
   && TARGET_PA_11 \
   && ! TARGET_SOFT_FLOAT \
   && ! TARGET_SOFT_MULT)
#define HAVE_divsi3 1
#define HAVE_udivsi3 1
#define HAVE_modsi3 1
#define HAVE_umodsi3 1
#define HAVE_iorsi3 1
#define HAVE_negdi2 1
#define HAVE_negvdi2 1
#define HAVE_one_cmpldi2 1
#define HAVE_negdf2 (!TARGET_SOFT_FLOAT)
#define HAVE_negsf2 (!TARGET_SOFT_FLOAT)
#define HAVE_ashlsi3 1
#define HAVE_ashldi3 1
#define HAVE_ashrsi3 1
#define HAVE_rotlsi3 1
#define HAVE_shd_internal 1
#define HAVE_prologue 1
#define HAVE_sibcall_epilogue 1
#define HAVE_epilogue 1
#define HAVE_nonlocal_goto 1
#define HAVE_casesi 1
#define HAVE_call 1
#define HAVE_call_value 1
#define HAVE_call_mcount (!TARGET_PORTABLE_RUNTIME)
#define HAVE_untyped_call 1
#define HAVE_sibcall (!TARGET_PORTABLE_RUNTIME)
#define HAVE_sibcall_value (!TARGET_PORTABLE_RUNTIME)
#define HAVE_interspace_jump 1
#define HAVE_builtin_longjmp 1
#define HAVE_extzvsi 1
#define HAVE_extvsi 1
#define HAVE_insvsi 1
#define HAVE_canonicalize_funcptr_for_compare (!TARGET_PORTABLE_RUNTIME && !TARGET_64BIT)
#define HAVE_exception_receiver (flag_pic)
#define HAVE_builtin_setjmp_receiver (flag_pic)
#define HAVE_allocate_stack 1
#define HAVE_prefetch (TARGET_PA_20)
#define HAVE_atomic_storeqi 1
#define HAVE_atomic_storehi 1
#define HAVE_atomic_storesi 1
#define HAVE_atomic_loaddi 1
#define HAVE_atomic_storedi 1
#define HAVE_memory_barrier 1
extern rtx        gen_scc                                 (rtx, rtx, rtx, rtx);
extern rtx        gen_iorscc                              (rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_negscc                              (rtx, rtx, rtx, rtx);
extern rtx        gen_incscc                              (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_decscc                              (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_sminsi3                             (rtx, rtx, rtx);
static inline rtx gen_smindi3                             (rtx, rtx, rtx);
static inline rtx
gen_smindi3(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c))
{
  return 0;
}
extern rtx        gen_uminsi3                             (rtx, rtx, rtx);
static inline rtx gen_umindi3                             (rtx, rtx, rtx);
static inline rtx
gen_umindi3(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c))
{
  return 0;
}
extern rtx        gen_smaxsi3                             (rtx, rtx, rtx);
static inline rtx gen_smaxdi3                             (rtx, rtx, rtx);
static inline rtx
gen_smaxdi3(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c))
{
  return 0;
}
extern rtx        gen_umaxsi3                             (rtx, rtx, rtx);
static inline rtx gen_umaxdi3                             (rtx, rtx, rtx);
static inline rtx
gen_umaxdi3(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c))
{
  return 0;
}
extern rtx        gen_absqi2                              (rtx, rtx);
extern rtx        gen_abshi2                              (rtx, rtx);
extern rtx        gen_abssi2                              (rtx, rtx);
static inline rtx gen_absdi2                              (rtx, rtx);
static inline rtx
gen_absdi2(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b))
{
  return 0;
}
extern rtx        gen_bswaphi2                            (rtx, rtx);
extern rtx        gen_bswapsi2                            (rtx, rtx);
static inline rtx gen_bswapdi2                            (rtx, rtx);
static inline rtx
gen_bswapdi2(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b))
{
  return 0;
}
extern rtx        gen_pre_ldw                             (rtx, rtx, rtx);
static inline rtx gen_pre_ldd                             (rtx, rtx, rtx);
static inline rtx
gen_pre_ldd(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c))
{
  return 0;
}
extern rtx        gen_post_stw                            (rtx, rtx, rtx);
static inline rtx gen_post_std                            (rtx, rtx, rtx);
static inline rtx
gen_post_std(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c))
{
  return 0;
}
extern rtx        gen_addhi3                              (rtx, rtx, rtx);
extern rtx        gen_cpymemsi_prereload                  (rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_cpymemsi_postreload                 (rtx, rtx, rtx, rtx, rtx, rtx, rtx);
static inline rtx gen_cpymemdi_prereload                  (rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx);
static inline rtx
gen_cpymemdi_prereload(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c), rtx ARG_UNUSED (d), rtx ARG_UNUSED (e), rtx ARG_UNUSED (f), rtx ARG_UNUSED (g), rtx ARG_UNUSED (h), rtx ARG_UNUSED (i))
{
  return 0;
}
static inline rtx gen_cpymemdi_postreload                 (rtx, rtx, rtx, rtx, rtx, rtx, rtx);
static inline rtx
gen_cpymemdi_postreload(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c), rtx ARG_UNUSED (d), rtx ARG_UNUSED (e), rtx ARG_UNUSED (f), rtx ARG_UNUSED (g))
{
  return 0;
}
extern rtx        gen_clrmemsi_prereload                  (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_clrmemsi_postreload                 (rtx, rtx, rtx, rtx);
static inline rtx gen_clrmemdi_prereload                  (rtx, rtx, rtx, rtx, rtx);
static inline rtx
gen_clrmemdi_prereload(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c), rtx ARG_UNUSED (d), rtx ARG_UNUSED (e))
{
  return 0;
}
static inline rtx gen_clrmemdi_postreload                 (rtx, rtx, rtx, rtx);
static inline rtx
gen_clrmemdi_postreload(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c), rtx ARG_UNUSED (d))
{
  return 0;
}
extern rtx        gen_extendhisi2                         (rtx, rtx);
extern rtx        gen_extendqihi2                         (rtx, rtx);
extern rtx        gen_extendqisi2                         (rtx, rtx);
static inline rtx gen_extendqidi2                         (rtx, rtx);
static inline rtx
gen_extendqidi2(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b))
{
  return 0;
}
static inline rtx gen_extendhidi2                         (rtx, rtx);
static inline rtx
gen_extendhidi2(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b))
{
  return 0;
}
static inline rtx gen_extendsidi2                         (rtx, rtx);
static inline rtx
gen_extendsidi2(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b))
{
  return 0;
}
extern rtx        gen_extendsfdf2                         (rtx, rtx);
extern rtx        gen_truncdfsf2                          (rtx, rtx);
extern rtx        gen_floatsisf2                          (rtx, rtx);
extern rtx        gen_floatsidf2                          (rtx, rtx);
extern rtx        gen_floatdisf2                          (rtx, rtx);
extern rtx        gen_floatdidf2                          (rtx, rtx);
extern rtx        gen_fix_truncsfsi2                      (rtx, rtx);
extern rtx        gen_fix_truncdfsi2                      (rtx, rtx);
extern rtx        gen_fix_truncsfdi2                      (rtx, rtx);
extern rtx        gen_fix_truncdfdi2                      (rtx, rtx);
extern rtx        gen_floatunssidf2_pa20                  (rtx, rtx);
extern rtx        gen_floatunssisf2_pa20                  (rtx, rtx);
extern rtx        gen_floatunsdisf2                       (rtx, rtx);
extern rtx        gen_floatunsdidf2                       (rtx, rtx);
extern rtx        gen_fixuns_truncsfsi2                   (rtx, rtx);
extern rtx        gen_fixuns_truncdfsi2                   (rtx, rtx);
extern rtx        gen_fixuns_truncsfdi2                   (rtx, rtx);
extern rtx        gen_fixuns_truncdfdi2                   (rtx, rtx);
extern rtx        gen_addsi3                              (rtx, rtx, rtx);
extern rtx        gen_addvsi3                             (rtx, rtx, rtx);
extern rtx        gen_subvsi3                             (rtx, rtx, rtx);
static inline rtx gen_addti3                              (rtx, rtx, rtx);
static inline rtx
gen_addti3(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c))
{
  return 0;
}
static inline rtx gen_addvti3                             (rtx, rtx, rtx);
static inline rtx
gen_addvti3(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c))
{
  return 0;
}
static inline rtx gen_subti3                              (rtx, rtx, rtx);
static inline rtx
gen_subti3(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c))
{
  return 0;
}
static inline rtx gen_subvti3                             (rtx, rtx, rtx);
static inline rtx
gen_subvti3(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c))
{
  return 0;
}
extern rtx        gen_trap                                (void);
extern rtx        gen_umulsidi3                           (rtx, rtx, rtx);
extern rtx        gen_andsi3                              (rtx, rtx, rtx);
extern rtx        gen_xorsi3                              (rtx, rtx, rtx);
static inline rtx gen_negti2                              (rtx, rtx);
static inline rtx
gen_negti2(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b))
{
  return 0;
}
static inline rtx gen_negvti2                             (rtx, rtx);
static inline rtx
gen_negvti2(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b))
{
  return 0;
}
extern rtx        gen_negsi2                              (rtx, rtx);
extern rtx        gen_negvsi2                             (rtx, rtx);
extern rtx        gen_one_cmplsi2                         (rtx, rtx);
extern rtx        gen_adddf3                              (rtx, rtx, rtx);
extern rtx        gen_addsf3                              (rtx, rtx, rtx);
extern rtx        gen_subdf3                              (rtx, rtx, rtx);
extern rtx        gen_subsf3                              (rtx, rtx, rtx);
extern rtx        gen_muldf3                              (rtx, rtx, rtx);
extern rtx        gen_mulsf3                              (rtx, rtx, rtx);
extern rtx        gen_divdf3                              (rtx, rtx, rtx);
extern rtx        gen_divsf3                              (rtx, rtx, rtx);
extern rtx        gen_negdf2_slow                         (rtx, rtx);
extern rtx        gen_negdf2_fast                         (rtx, rtx);
extern rtx        gen_negsf2_slow                         (rtx, rtx);
extern rtx        gen_negsf2_fast                         (rtx, rtx);
extern rtx        gen_absdf2                              (rtx, rtx);
extern rtx        gen_abssf2                              (rtx, rtx);
extern rtx        gen_sqrtdf2                             (rtx, rtx);
extern rtx        gen_sqrtsf2                             (rtx, rtx);
extern rtx        gen_fmadf4                              (rtx, rtx, rtx, rtx);
extern rtx        gen_fmasf4                              (rtx, rtx, rtx, rtx);
extern rtx        gen_fnmadf4                             (rtx, rtx, rtx, rtx);
extern rtx        gen_fnmasf4                             (rtx, rtx, rtx, rtx);
extern rtx        gen_zvdep32                             (rtx, rtx, rtx);
extern rtx        gen_zvdep_imm32                         (rtx, rtx, rtx);
extern rtx        gen_vdepi_ior                           (rtx, rtx, rtx, rtx);
extern rtx        gen_vdepi_and                           (rtx, rtx, rtx, rtx);
static inline rtx gen_zvdep64                             (rtx, rtx, rtx);
static inline rtx
gen_zvdep64(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c))
{
  return 0;
}
static inline rtx gen_zvdep_imm64                         (rtx, rtx, rtx);
static inline rtx
gen_zvdep_imm64(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c))
{
  return 0;
}
extern rtx        gen_vextrs32                            (rtx, rtx, rtx);
static inline rtx gen_vextrs64                            (rtx, rtx, rtx);
static inline rtx
gen_vextrs64(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c))
{
  return 0;
}
extern rtx        gen_lshrsi3                             (rtx, rtx, rtx);
static inline rtx gen_lshrdi3                             (rtx, rtx, rtx);
static inline rtx
gen_lshrdi3(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c))
{
  return 0;
}
extern rtx        gen_rotrsi3                             (rtx, rtx, rtx);
static inline rtx gen_rotrdi3                             (rtx, rtx, rtx);
static inline rtx
gen_rotrdi3(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c))
{
  return 0;
}
extern rtx        gen_return                              (void);
extern rtx        gen_return_internal                     (void);
extern rtx        gen_return_external_pic                 (void);
extern rtx        gen_load_offset_label_address           (rtx, rtx, rtx, rtx);
extern rtx        gen_lcla1                               (rtx, rtx);
extern rtx        gen_lcla2                               (rtx, rtx);
extern rtx        gen_blockage                            (void);
extern rtx        gen_jump                                (rtx);
extern rtx        gen_indirect_jump                       (rtx);
extern rtx        gen_indirect_goto                       (rtx);
extern rtx        gen_casesi32                            (rtx, rtx);
extern rtx        gen_casesi32p                           (rtx, rtx);
extern rtx        gen_casesi64p                           (rtx, rtx);
extern rtx        gen_call_symref                         (rtx, rtx);
extern rtx        gen_call_symref_pic                     (rtx, rtx, rtx);
static inline rtx gen_call_symref_64bit                   (rtx, rtx, rtx);
static inline rtx
gen_call_symref_64bit(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c))
{
  return 0;
}
extern rtx        gen_call_reg                            (rtx);
extern rtx        gen_call_reg_pic                        (rtx, rtx);
static inline rtx gen_call_reg_64bit                      (rtx, rtx, rtx);
static inline rtx
gen_call_reg_64bit(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c))
{
  return 0;
}
extern rtx        gen_call_val_symref                     (rtx, rtx, rtx);
static inline rtx gen_call_val_powf                       (rtx, rtx, rtx);
static inline rtx
gen_call_val_powf(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c))
{
  return 0;
}
extern rtx        gen_call_val_symref_pic                 (rtx, rtx, rtx, rtx);
static inline rtx gen_call_val_powf_pic                   (rtx, rtx, rtx, rtx);
static inline rtx
gen_call_val_powf_pic(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c), rtx ARG_UNUSED (d))
{
  return 0;
}
static inline rtx gen_call_val_symref_64bit               (rtx, rtx, rtx, rtx);
static inline rtx
gen_call_val_symref_64bit(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c), rtx ARG_UNUSED (d))
{
  return 0;
}
static inline rtx gen_call_val_powf_64bit                 (rtx, rtx, rtx, rtx);
static inline rtx
gen_call_val_powf_64bit(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c), rtx ARG_UNUSED (d))
{
  return 0;
}
extern rtx        gen_call_val_reg                        (rtx, rtx);
extern rtx        gen_call_val_reg_pic                    (rtx, rtx, rtx);
static inline rtx gen_call_val_reg_64bit                  (rtx, rtx, rtx, rtx);
static inline rtx
gen_call_val_reg_64bit(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c), rtx ARG_UNUSED (d))
{
  return 0;
}
extern rtx        gen_call_mcount_nonpic                  (rtx, rtx, rtx);
extern rtx        gen_call_mcount_pic                     (rtx, rtx, rtx, rtx);
static inline rtx gen_call_mcount_64bit                   (rtx, rtx, rtx, rtx);
static inline rtx
gen_call_mcount_64bit(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c), rtx ARG_UNUSED (d))
{
  return 0;
}
extern rtx        gen_sibcall_internal_symref             (rtx, rtx);
static inline rtx gen_sibcall_internal_symref_64bit       (rtx, rtx);
static inline rtx
gen_sibcall_internal_symref_64bit(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b))
{
  return 0;
}
extern rtx        gen_sibcall_value_internal_symref       (rtx, rtx, rtx);
static inline rtx gen_sibcall_value_internal_symref_64bit (rtx, rtx, rtx);
static inline rtx
gen_sibcall_value_internal_symref_64bit(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c))
{
  return 0;
}
extern rtx        gen_nop                                 (void);
extern rtx        gen_extzv_32                            (rtx, rtx, rtx, rtx);
static inline rtx gen_extzv_64                            (rtx, rtx, rtx, rtx);
static inline rtx
gen_extzv_64(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c), rtx ARG_UNUSED (d))
{
  return 0;
}
extern rtx        gen_extv_32                             (rtx, rtx, rtx, rtx);
static inline rtx gen_extv_64                             (rtx, rtx, rtx, rtx);
static inline rtx
gen_extv_64(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c), rtx ARG_UNUSED (d))
{
  return 0;
}
extern rtx        gen_insv_32                             (rtx, rtx, rtx, rtx);
static inline rtx gen_insv_64                             (rtx, rtx, rtx, rtx);
static inline rtx
gen_insv_64(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c), rtx ARG_UNUSED (d))
{
  return 0;
}
extern rtx        gen_decrement_and_branch_until_zero     (rtx, rtx, rtx, rtx);
extern rtx        gen_dcacheflushsi                       (rtx, rtx, rtx);
extern rtx        gen_dcacheflushdi                       (rtx, rtx, rtx);
extern rtx        gen_icacheflushsi                       (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_icacheflushdi                       (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_outline_prologue_call               (void);
extern rtx        gen_outline_epilogue_call               (void);
extern rtx        gen_prefetch_20                         (rtx, rtx, rtx);
extern rtx        gen_tgd_load                            (rtx, rtx);
extern rtx        gen_tgd_load_pic                        (rtx, rtx);
extern rtx        gen_tld_load                            (rtx, rtx);
extern rtx        gen_tld_load_pic                        (rtx, rtx);
extern rtx        gen_tld_offset_load                     (rtx, rtx, rtx);
extern rtx        gen_tp_load                             (rtx);
extern rtx        gen_tie_load                            (rtx, rtx);
extern rtx        gen_tie_load_pic                        (rtx, rtx);
extern rtx        gen_tle_load                            (rtx, rtx, rtx);
extern rtx        gen_atomic_loaddi_1                     (rtx, rtx);
extern rtx        gen_atomic_storedi_1                    (rtx, rtx);
extern rtx        gen_movccfp                             (rtx);
extern rtx        gen_cstoresi4                           (rtx, rtx, rtx, rtx);
extern rtx        gen_movsicc                             (rtx, rtx, rtx, rtx);
static inline rtx gen_movdicc                             (rtx, rtx, rtx, rtx);
static inline rtx
gen_movdicc(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c), rtx ARG_UNUSED (d))
{
  return 0;
}
static inline rtx gen_cbranchdi4                          (rtx, rtx, rtx, rtx);
static inline rtx
gen_cbranchdi4(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c), rtx ARG_UNUSED (d))
{
  return 0;
}
extern rtx        gen_cbranchsi4                          (rtx, rtx, rtx, rtx);
extern rtx        gen_cbranchsf4                          (rtx, rtx, rtx, rtx);
extern rtx        gen_cbranchdf4                          (rtx, rtx, rtx, rtx);
extern rtx        gen_movsi                               (rtx, rtx);
extern rtx        gen_reload_insi_r1                      (rtx, rtx, rtx);
extern rtx        gen_reload_insi                         (rtx, rtx, rtx);
extern rtx        gen_reload_outsi                        (rtx, rtx, rtx);
extern rtx        gen_pre_load                            (rtx, rtx, rtx);
extern rtx        gen_post_store                          (rtx, rtx, rtx);
extern rtx        gen_movhi                               (rtx, rtx);
extern rtx        gen_reload_inhi                         (rtx, rtx, rtx);
extern rtx        gen_reload_outhi                        (rtx, rtx, rtx);
extern rtx        gen_movqi                               (rtx, rtx);
extern rtx        gen_reload_inqi                         (rtx, rtx, rtx);
extern rtx        gen_reload_outqi                        (rtx, rtx, rtx);
extern rtx        gen_cpymemsi                            (rtx, rtx, rtx, rtx);
static inline rtx gen_cpymemdi                            (rtx, rtx, rtx, rtx);
static inline rtx
gen_cpymemdi(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c), rtx ARG_UNUSED (d))
{
  return 0;
}
extern rtx        gen_setmemsi                            (rtx, rtx, rtx, rtx);
static inline rtx gen_setmemdi                            (rtx, rtx, rtx, rtx);
static inline rtx
gen_setmemdi(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c), rtx ARG_UNUSED (d))
{
  return 0;
}
extern rtx        gen_movdf                               (rtx, rtx);
extern rtx        gen_reload_indf_r1                      (rtx, rtx, rtx);
extern rtx        gen_reload_indf                         (rtx, rtx, rtx);
extern rtx        gen_reload_outdf                        (rtx, rtx, rtx);
extern rtx        gen_movdi                               (rtx, rtx);
extern rtx        gen_reload_indi_r1                      (rtx, rtx, rtx);
extern rtx        gen_reload_indi                         (rtx, rtx, rtx);
extern rtx        gen_reload_outdi                        (rtx, rtx, rtx);
extern rtx        gen_movsf                               (rtx, rtx);
extern rtx        gen_reload_insf_r1                      (rtx, rtx, rtx);
extern rtx        gen_reload_insf                         (rtx, rtx, rtx);
extern rtx        gen_reload_outsf                        (rtx, rtx, rtx);
extern rtx        gen_zero_extendqihi2                    (rtx, rtx);
extern rtx        gen_zero_extendqisi2                    (rtx, rtx);
extern rtx        gen_zero_extendhisi2                    (rtx, rtx);
static inline rtx gen_zero_extendqidi2                    (rtx, rtx);
static inline rtx
gen_zero_extendqidi2(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b))
{
  return 0;
}
static inline rtx gen_zero_extendhidi2                    (rtx, rtx);
static inline rtx
gen_zero_extendhidi2(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b))
{
  return 0;
}
static inline rtx gen_zero_extendsidi2                    (rtx, rtx);
static inline rtx
gen_zero_extendsidi2(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b))
{
  return 0;
}
extern rtx        gen_floatunssisf2                       (rtx, rtx);
extern rtx        gen_floatunssidf2                       (rtx, rtx);
extern rtx        gen_adddi3                              (rtx, rtx, rtx);
extern rtx        gen_addvdi3                             (rtx, rtx, rtx);
extern rtx        gen_subdi3                              (rtx, rtx, rtx);
extern rtx        gen_subvdi3                             (rtx, rtx, rtx);
extern rtx        gen_subsi3                              (rtx, rtx, rtx);
extern rtx        gen_mulsi3                              (rtx, rtx, rtx);
extern rtx        gen_muldi3                              (rtx, rtx, rtx);
extern rtx        gen_divsi3                              (rtx, rtx, rtx);
extern rtx        gen_udivsi3                             (rtx, rtx, rtx);
extern rtx        gen_modsi3                              (rtx, rtx, rtx);
extern rtx        gen_umodsi3                             (rtx, rtx, rtx);
static inline rtx gen_anddi3                              (rtx, rtx, rtx);
static inline rtx
gen_anddi3(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c))
{
  return 0;
}
static inline rtx gen_iordi3                              (rtx, rtx, rtx);
static inline rtx
gen_iordi3(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c))
{
  return 0;
}
extern rtx        gen_iorsi3                              (rtx, rtx, rtx);
static inline rtx gen_xordi3                              (rtx, rtx, rtx);
static inline rtx
gen_xordi3(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c))
{
  return 0;
}
extern rtx        gen_negdi2                              (rtx, rtx);
extern rtx        gen_negvdi2                             (rtx, rtx);
extern rtx        gen_one_cmpldi2                         (rtx, rtx);
extern rtx        gen_negdf2                              (rtx, rtx);
extern rtx        gen_negsf2                              (rtx, rtx);
extern rtx        gen_ashlsi3                             (rtx, rtx, rtx);
extern rtx        gen_ashldi3                             (rtx, rtx, rtx);
static inline rtx gen_ashlti3                             (rtx, rtx, rtx);
static inline rtx
gen_ashlti3(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c))
{
  return 0;
}
extern rtx        gen_ashrsi3                             (rtx, rtx, rtx);
static inline rtx gen_ashrdi3                             (rtx, rtx, rtx);
static inline rtx
gen_ashrdi3(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c))
{
  return 0;
}
extern rtx        gen_rotlsi3                             (rtx, rtx, rtx);
static inline rtx gen_rotldi3                             (rtx, rtx, rtx);
static inline rtx
gen_rotldi3(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c))
{
  return 0;
}
extern rtx        gen_shd_internal                        (rtx, rtx, rtx, rtx, rtx);
static inline rtx gen_shrpd_internal                      (rtx, rtx, rtx, rtx, rtx);
static inline rtx
gen_shrpd_internal(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c), rtx ARG_UNUSED (d), rtx ARG_UNUSED (e))
{
  return 0;
}
extern rtx        gen_prologue                            (void);
extern rtx        gen_sibcall_epilogue                    (void);
extern rtx        gen_epilogue                            (void);
extern rtx        gen_nonlocal_goto                       (rtx, rtx, rtx, rtx);
extern rtx        gen_casesi                              (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_call                                (rtx, rtx);
extern rtx        gen_call_value                          (rtx, rtx, rtx);
extern rtx        gen_call_mcount                         (rtx, rtx, rtx);
extern rtx        gen_untyped_call                        (rtx, rtx, rtx);
extern rtx        gen_sibcall                             (rtx, rtx);
extern rtx        gen_sibcall_value                       (rtx, rtx, rtx);
extern rtx        gen_interspace_jump                     (rtx);
extern rtx        gen_builtin_longjmp                     (rtx);
extern rtx        gen_extzvsi                             (rtx, rtx, rtx, rtx);
static inline rtx gen_extzvdi                             (rtx, rtx, rtx, rtx);
static inline rtx
gen_extzvdi(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c), rtx ARG_UNUSED (d))
{
  return 0;
}
extern rtx        gen_extvsi                              (rtx, rtx, rtx, rtx);
static inline rtx gen_extvdi                              (rtx, rtx, rtx, rtx);
static inline rtx
gen_extvdi(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c), rtx ARG_UNUSED (d))
{
  return 0;
}
extern rtx        gen_insvsi                              (rtx, rtx, rtx, rtx);
static inline rtx gen_insvdi                              (rtx, rtx, rtx, rtx);
static inline rtx
gen_insvdi(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c), rtx ARG_UNUSED (d))
{
  return 0;
}
extern rtx        gen_canonicalize_funcptr_for_compare    (rtx, rtx);
extern rtx        gen_exception_receiver                  (void);
extern rtx        gen_builtin_setjmp_receiver             (rtx);
extern rtx        gen_allocate_stack                      (rtx, rtx);
extern rtx        gen_prefetch                            (rtx, rtx, rtx);
extern rtx        gen_atomic_storeqi                      (rtx, rtx, rtx);
extern rtx        gen_atomic_storehi                      (rtx, rtx, rtx);
extern rtx        gen_atomic_storesi                      (rtx, rtx, rtx);
extern rtx        gen_atomic_loaddi                       (rtx, rtx, rtx);
extern rtx        gen_atomic_storedi                      (rtx, rtx, rtx);
extern rtx        gen_memory_barrier                      (void);

#endif /* GCC_INSN_FLAGS_H */
