/* Generated automatically by the program `genflags'
   from the machine description file `md'.  */

#ifndef GCC_INSN_FLAGS_H
#define GCC_INSN_FLAGS_H

#define HAVE_addsi3 1
#define HAVE_addvsi3 1
#define HAVE_addvdi3 1
#define HAVE_negsi2 1
#define HAVE_negdi2 1
#define HAVE_negvsi2 1
#define HAVE_negvdi2 1
#define HAVE_subsi3 1
#define HAVE_subdi3 1
#define HAVE_subvsi3 1
#define HAVE_subvdi3 1
#define HAVE_mulsi3 1
#define HAVE_muldi3 1
#define HAVE_mulvsi3 1
#define HAVE_mulvdi3 1
#define HAVE_anddi3 1
#define HAVE_zero_extendqihi2 1
#define HAVE_zero_extendqisi2 1
#define HAVE_zero_extendqidi2 1
#define HAVE_zero_extendhisi2 1
#define HAVE_zero_extendhidi2 1
#define HAVE_zero_extendsidi2 1
#define HAVE_andnotsi3 1
#define HAVE_andnotdi3 1
#define HAVE_iordi3 1
#define HAVE_one_cmpldi2 1
#define HAVE_xordi3 1
#define HAVE_clzdi2 (TARGET_CIX)
#define HAVE_ctzdi2 (TARGET_CIX)
#define HAVE_popcountdi2 (TARGET_CIX)
#define HAVE_ashldi3 1
#define HAVE_ashlsi3 1
#define HAVE_lshrdi3 1
#define HAVE_ashrdi3 1
#define HAVE_extendqihi2 (TARGET_BWX)
#define HAVE_extendqisi2 (TARGET_BWX)
#define HAVE_extendhisi2 (TARGET_BWX)
#define HAVE_extxl 1
#define HAVE_extqh 1
#define HAVE_extwh 1
#define HAVE_extlh 1
#define HAVE_insbl_const 1
#define HAVE_inswl_const 1
#define HAVE_insll_const 1
#define HAVE_insbl 1
#define HAVE_inswl 1
#define HAVE_insll 1
#define HAVE_insql 1
#define HAVE_insxh 1
#define HAVE_mskxl 1
#define HAVE_mskxh 1
#define HAVE_abssf2 (TARGET_FP)
#define HAVE_absdf2 (TARGET_FP)
#define HAVE_negsf2 (TARGET_FP)
#define HAVE_negdf2 (TARGET_FP)
#define HAVE_copysignsf3 (TARGET_FP)
#define HAVE_copysigndf3 (TARGET_FP)
#define HAVE_addsf3 (TARGET_FP)
#define HAVE_adddf3 (TARGET_FP)
#define HAVE_subsf3 (TARGET_FP)
#define HAVE_subdf3 (TARGET_FP)
#define HAVE_mulsf3 (TARGET_FP)
#define HAVE_muldf3 (TARGET_FP)
#define HAVE_divsf3 (TARGET_FP)
#define HAVE_divdf3 (TARGET_FP)
#define HAVE_sqrtsf2 (TARGET_FP && TARGET_FIX)
#define HAVE_sqrtdf2 (TARGET_FP && TARGET_FIX)
#define HAVE_floatdisf2 (TARGET_FP)
#define HAVE_floatdidf2 (TARGET_FP)
#define HAVE_truncdfsf2 (TARGET_FP)
#define HAVE_smaxqi3 (TARGET_MAX)
#define HAVE_sminqi3 (TARGET_MAX)
#define HAVE_umaxqi3 (TARGET_MAX)
#define HAVE_uminqi3 (TARGET_MAX)
#define HAVE_smaxhi3 (TARGET_MAX)
#define HAVE_sminhi3 (TARGET_MAX)
#define HAVE_umaxhi3 (TARGET_MAX)
#define HAVE_uminhi3 (TARGET_MAX)
#define HAVE_blockage 1
#define HAVE_jump 1
#define HAVE_indirect_jump 1
#define HAVE_imb 1
#define HAVE_trap 1
#define HAVE_get_thread_pointerdi 1
#define HAVE_movdi_er_high_g (TARGET_EXPLICIT_RELOCS)
#define HAVE_movdi_er_tlsgd 1
#define HAVE_movdi_er_tlsldm 1
#define HAVE_force_movdi 1
#define HAVE_reload_inqi_aligned (!TARGET_BWX && (reload_in_progress || reload_completed))
#define HAVE_reload_inhi_aligned (!TARGET_BWX && (reload_in_progress || reload_completed))
#define HAVE_reload_outqi_aligned (!TARGET_BWX && (reload_in_progress || reload_completed))
#define HAVE_reload_outhi_aligned (!TARGET_BWX && (reload_in_progress || reload_completed))
#define HAVE_smaxv8qi3 (TARGET_MAX)
#define HAVE_sminv8qi3 (TARGET_MAX)
#define HAVE_umaxv8qi3 (TARGET_MAX)
#define HAVE_uminv8qi3 (TARGET_MAX)
#define HAVE_smaxv4hi3 (TARGET_MAX)
#define HAVE_sminv4hi3 (TARGET_MAX)
#define HAVE_umaxv4hi3 (TARGET_MAX)
#define HAVE_uminv4hi3 (TARGET_MAX)
#define HAVE_one_cmplv8qi2 1
#define HAVE_one_cmplv4hi2 1
#define HAVE_one_cmplv2si2 1
#define HAVE_andv8qi3 1
#define HAVE_andv4hi3 1
#define HAVE_andv2si3 1
#define HAVE_iorv8qi3 1
#define HAVE_iorv4hi3 1
#define HAVE_iorv2si3 1
#define HAVE_xorv8qi3 1
#define HAVE_xorv4hi3 1
#define HAVE_xorv2si3 1
#define HAVE_prologue_stack_probe_loop 1
#define HAVE_prologue_mcount 1
#define HAVE_init_fp 1
#define HAVE_builtin_longjmp_internal 1
#define HAVE_prefetch 1
#define HAVE_trapb 1
#define HAVE_nop 1
#define HAVE_fnop (TARGET_FP)
#define HAVE_unop 1
#define HAVE_realign 1
#define HAVE_builtin_cmpbge 1
#define HAVE_builtin_amask 1
#define HAVE_builtin_implver 1
#define HAVE_builtin_rpcc 1
#define HAVE_builtin_perr (TARGET_MAX)
#define HAVE_load_locked_si 1
#define HAVE_load_locked_di 1
#define HAVE_store_conditional_si 1
#define HAVE_store_conditional_di 1
#define HAVE_atomic_compare_and_swapqi_1 1
#define HAVE_atomic_compare_and_swaphi_1 1
#define HAVE_atomic_exchangesi 1
#define HAVE_atomic_exchangedi 1
#define HAVE_atomic_exchangeqi_1 1
#define HAVE_atomic_exchangehi_1 1
#define HAVE_atomic_addsi 1
#define HAVE_atomic_subsi 1
#define HAVE_atomic_orsi 1
#define HAVE_atomic_xorsi 1
#define HAVE_atomic_andsi 1
#define HAVE_atomic_adddi 1
#define HAVE_atomic_subdi 1
#define HAVE_atomic_ordi 1
#define HAVE_atomic_xordi 1
#define HAVE_atomic_anddi 1
#define HAVE_atomic_nandsi 1
#define HAVE_atomic_nanddi 1
#define HAVE_atomic_fetch_addsi 1
#define HAVE_atomic_fetch_subsi 1
#define HAVE_atomic_fetch_orsi 1
#define HAVE_atomic_fetch_xorsi 1
#define HAVE_atomic_fetch_andsi 1
#define HAVE_atomic_fetch_adddi 1
#define HAVE_atomic_fetch_subdi 1
#define HAVE_atomic_fetch_ordi 1
#define HAVE_atomic_fetch_xordi 1
#define HAVE_atomic_fetch_anddi 1
#define HAVE_atomic_fetch_nandsi 1
#define HAVE_atomic_fetch_nanddi 1
#define HAVE_atomic_add_fetchsi 1
#define HAVE_atomic_sub_fetchsi 1
#define HAVE_atomic_or_fetchsi 1
#define HAVE_atomic_xor_fetchsi 1
#define HAVE_atomic_and_fetchsi 1
#define HAVE_atomic_add_fetchdi 1
#define HAVE_atomic_sub_fetchdi 1
#define HAVE_atomic_or_fetchdi 1
#define HAVE_atomic_xor_fetchdi 1
#define HAVE_atomic_and_fetchdi 1
#define HAVE_atomic_nand_fetchsi 1
#define HAVE_atomic_nand_fetchdi 1
#define HAVE_call_value_osf_tlsgd 1
#define HAVE_call_value_osf_tlsldm 1
#define HAVE_extendsidi2 1
#define HAVE_adddi3 1
#define HAVE_umuldi3_highpart 1
#define HAVE_umulditi3 1
#define HAVE_divsi3 1
#define HAVE_modsi3 1
#define HAVE_udivsi3 1
#define HAVE_umodsi3 1
#define HAVE_divdi3 1
#define HAVE_moddi3 1
#define HAVE_udivdi3 1
#define HAVE_umoddi3 1
#define HAVE_ffsdi2 (TARGET_CIX)
#define HAVE_bswapsi2 (!optimize_size)
#define HAVE_bswapdi2 (!optimize_size)
#define HAVE_extendqidi2 1
#define HAVE_extendhidi2 1
#define HAVE_unaligned_extendqidi 1
#define HAVE_unaligned_extendhidi 1
#define HAVE_abstf2 (TARGET_HAS_XFLOATING_LIBS)
#define HAVE_negtf2 (TARGET_HAS_XFLOATING_LIBS)
#define HAVE_addtf3 (TARGET_HAS_XFLOATING_LIBS)
#define HAVE_subtf3 (TARGET_HAS_XFLOATING_LIBS)
#define HAVE_multf3 (TARGET_HAS_XFLOATING_LIBS)
#define HAVE_divtf3 (TARGET_HAS_XFLOATING_LIBS)
#define HAVE_fix_truncdfdi2 (TARGET_FP)
#define HAVE_fixuns_truncdfdi2 (TARGET_FP)
#define HAVE_fix_truncsfdi2 (TARGET_FP)
#define HAVE_fixuns_truncsfdi2 (TARGET_FP)
#define HAVE_fix_trunctfdi2 (TARGET_HAS_XFLOATING_LIBS)
#define HAVE_fixuns_trunctfdi2 (TARGET_HAS_XFLOATING_LIBS)
#define HAVE_floatditf2 (TARGET_HAS_XFLOATING_LIBS)
#define HAVE_floatunsdisf2 (TARGET_FP)
#define HAVE_floatunsdidf2 (TARGET_FP)
#define HAVE_floatunsditf2 (TARGET_HAS_XFLOATING_LIBS)
#define HAVE_extendsfdf2 (TARGET_FP)
#define HAVE_extendsftf2 (TARGET_HAS_XFLOATING_LIBS)
#define HAVE_extenddftf2 (TARGET_HAS_XFLOATING_LIBS)
#define HAVE_trunctfdf2 (TARGET_HAS_XFLOATING_LIBS)
#define HAVE_trunctfsf2 (TARGET_FP && TARGET_HAS_XFLOATING_LIBS)
#define HAVE_absdi2 1
#define HAVE_absdi2_same 1
#define HAVE_absdi2_diff 1
#define HAVE_smaxdi3 1
#define HAVE_smindi3 1
#define HAVE_umaxdi3 1
#define HAVE_umindi3 1
#define HAVE_smaxdf3 (TARGET_FP)
#define HAVE_smindf3 (TARGET_FP)
#define HAVE_smaxsf3 (TARGET_FP && alpha_fptm < ALPHA_FPTM_SU)
#define HAVE_sminsf3 (TARGET_FP && alpha_fptm < ALPHA_FPTM_SU)
#define HAVE_cbranchdf4 (TARGET_FP)
#define HAVE_cbranchtf4 (TARGET_HAS_XFLOATING_LIBS)
#define HAVE_cbranchdi4 1
#define HAVE_cstoredf4 (TARGET_FP)
#define HAVE_cstoretf4 (TARGET_HAS_XFLOATING_LIBS)
#define HAVE_cstoredi4 1
#define HAVE_movsicc 1
#define HAVE_movdicc 1
#define HAVE_movsfcc 1
#define HAVE_movdfcc 1
#define HAVE_call 1
#define HAVE_sibcall 1
#define HAVE_call_osf 1
#define HAVE_call_vms 1
#define HAVE_call_value 1
#define HAVE_sibcall_value 1
#define HAVE_call_value_osf 1
#define HAVE_call_value_vms 1
#define HAVE_untyped_call 1
#define HAVE_return (direct_return ())
#define HAVE_tablejump 1
#define HAVE_clear_cache 1
#define HAVE_set_thread_pointerdi 1
#define HAVE_movsf 1
#define HAVE_movdf 1
#define HAVE_movtf 1
#define HAVE_movsi 1
#define HAVE_movdi 1
#define HAVE_movti 1
#define HAVE_aligned_loadqi 1
#define HAVE_aligned_loadhi 1
#define HAVE_unaligned_loadqi 1
#define HAVE_unaligned_loadhi 1
#define HAVE_aligned_store 1
#define HAVE_unaligned_storeqi 1
#define HAVE_unaligned_storehi 1
#define HAVE_movqi 1
#define HAVE_movhi 1
#define HAVE_movcqi (!TARGET_BWX)
#define HAVE_reload_inqi (!TARGET_BWX)
#define HAVE_reload_inhi (!TARGET_BWX)
#define HAVE_reload_incqi (!TARGET_BWX)
#define HAVE_reload_outqi (!TARGET_BWX)
#define HAVE_reload_outhi (!TARGET_BWX)
#define HAVE_reload_outcqi (!TARGET_BWX)
#define HAVE_movv8qi 1
#define HAVE_movv4hi 1
#define HAVE_movv2si 1
#define HAVE_movmisalignv8qi 1
#define HAVE_movmisalignv4hi 1
#define HAVE_movmisalignv2si 1
#define HAVE_vec_shl_v8qi 1
#define HAVE_vec_shl_v4hi 1
#define HAVE_vec_shl_v2si 1
#define HAVE_vec_shr_v8qi 1
#define HAVE_vec_shr_v4hi 1
#define HAVE_vec_shr_v2si 1
#define HAVE_extvmisaligndi 1
#define HAVE_extzvdi 1
#define HAVE_extzvmisaligndi 1
#define HAVE_insvmisaligndi 1
#define HAVE_cpymemqi 1
#define HAVE_setmemqi 1
#define HAVE_stack_probe_internal 1
#define HAVE_allocate_stack 1
#define HAVE_prologue 1
#define HAVE_prologue_ldgp 1
#define HAVE_epilogue 1
#define HAVE_sibcall_epilogue 1
#define HAVE_builtin_longjmp 1
#define HAVE_builtin_setjmp_receiver 1
#define HAVE_exception_receiver 1
#define HAVE_extbl 1
#define HAVE_extwl 1
#define HAVE_extll 1
#define HAVE_extql 1
#define HAVE_builtin_insbl 1
#define HAVE_builtin_inswl 1
#define HAVE_builtin_insll 1
#define HAVE_inswh 1
#define HAVE_inslh 1
#define HAVE_insqh 1
#define HAVE_mskbl 1
#define HAVE_mskwl 1
#define HAVE_mskll 1
#define HAVE_mskql 1
#define HAVE_mskwh 1
#define HAVE_msklh 1
#define HAVE_mskqh 1
#define HAVE_builtin_zap 1
#define HAVE_builtin_zapnot 1
#define HAVE_builtin_minub8 (TARGET_MAX)
#define HAVE_builtin_minsb8 (TARGET_MAX)
#define HAVE_builtin_minuw4 (TARGET_MAX)
#define HAVE_builtin_minsw4 (TARGET_MAX)
#define HAVE_builtin_maxub8 (TARGET_MAX)
#define HAVE_builtin_maxsb8 (TARGET_MAX)
#define HAVE_builtin_maxuw4 (TARGET_MAX)
#define HAVE_builtin_maxsw4 (TARGET_MAX)
#define HAVE_builtin_pklb (TARGET_MAX)
#define HAVE_builtin_pkwb (TARGET_MAX)
#define HAVE_builtin_unpkbl (TARGET_MAX)
#define HAVE_builtin_unpkbw (TARGET_MAX)
#define HAVE_memory_barrier 1
#define HAVE_atomic_compare_and_swapsi 1
#define HAVE_atomic_compare_and_swapdi 1
#define HAVE_atomic_compare_and_swapqi 1
#define HAVE_atomic_compare_and_swaphi 1
#define HAVE_atomic_exchangeqi 1
#define HAVE_atomic_exchangehi 1
extern rtx        gen_addsi3                                  (rtx, rtx, rtx);
extern rtx        gen_addvsi3                                 (rtx, rtx, rtx);
extern rtx        gen_addvdi3                                 (rtx, rtx, rtx);
extern rtx        gen_negsi2                                  (rtx, rtx);
extern rtx        gen_negdi2                                  (rtx, rtx);
extern rtx        gen_negvsi2                                 (rtx, rtx);
extern rtx        gen_negvdi2                                 (rtx, rtx);
extern rtx        gen_subsi3                                  (rtx, rtx, rtx);
extern rtx        gen_subdi3                                  (rtx, rtx, rtx);
extern rtx        gen_subvsi3                                 (rtx, rtx, rtx);
extern rtx        gen_subvdi3                                 (rtx, rtx, rtx);
extern rtx        gen_mulsi3                                  (rtx, rtx, rtx);
extern rtx        gen_muldi3                                  (rtx, rtx, rtx);
extern rtx        gen_mulvsi3                                 (rtx, rtx, rtx);
extern rtx        gen_mulvdi3                                 (rtx, rtx, rtx);
extern rtx        gen_anddi3                                  (rtx, rtx, rtx);
extern rtx        gen_zero_extendqihi2                        (rtx, rtx);
extern rtx        gen_zero_extendqisi2                        (rtx, rtx);
extern rtx        gen_zero_extendqidi2                        (rtx, rtx);
extern rtx        gen_zero_extendhisi2                        (rtx, rtx);
extern rtx        gen_zero_extendhidi2                        (rtx, rtx);
extern rtx        gen_zero_extendsidi2                        (rtx, rtx);
extern rtx        gen_andnotsi3                               (rtx, rtx, rtx);
extern rtx        gen_andnotdi3                               (rtx, rtx, rtx);
extern rtx        gen_iordi3                                  (rtx, rtx, rtx);
extern rtx        gen_one_cmpldi2                             (rtx, rtx);
extern rtx        gen_xordi3                                  (rtx, rtx, rtx);
extern rtx        gen_clzdi2                                  (rtx, rtx);
extern rtx        gen_ctzdi2                                  (rtx, rtx);
extern rtx        gen_popcountdi2                             (rtx, rtx);
extern rtx        gen_ashldi3                                 (rtx, rtx, rtx);
extern rtx        gen_ashlsi3                                 (rtx, rtx, rtx);
extern rtx        gen_lshrdi3                                 (rtx, rtx, rtx);
extern rtx        gen_ashrdi3                                 (rtx, rtx, rtx);
extern rtx        gen_extendqihi2                             (rtx, rtx);
extern rtx        gen_extendqisi2                             (rtx, rtx);
extern rtx        gen_extendhisi2                             (rtx, rtx);
extern rtx        gen_extxl                                   (rtx, rtx, rtx, rtx);
extern rtx        gen_extqh                                   (rtx, rtx, rtx);
extern rtx        gen_extwh                                   (rtx, rtx, rtx);
extern rtx        gen_extlh                                   (rtx, rtx, rtx);
extern rtx        gen_insbl_const                             (rtx, rtx, rtx);
extern rtx        gen_inswl_const                             (rtx, rtx, rtx);
extern rtx        gen_insll_const                             (rtx, rtx, rtx);
extern rtx        gen_insbl                                   (rtx, rtx, rtx);
extern rtx        gen_inswl                                   (rtx, rtx, rtx);
extern rtx        gen_insll                                   (rtx, rtx, rtx);
extern rtx        gen_insql                                   (rtx, rtx, rtx);
extern rtx        gen_insxh                                   (rtx, rtx, rtx, rtx);
extern rtx        gen_mskxl                                   (rtx, rtx, rtx, rtx);
extern rtx        gen_mskxh                                   (rtx, rtx, rtx, rtx);
extern rtx        gen_abssf2                                  (rtx, rtx);
extern rtx        gen_absdf2                                  (rtx, rtx);
extern rtx        gen_negsf2                                  (rtx, rtx);
extern rtx        gen_negdf2                                  (rtx, rtx);
extern rtx        gen_copysignsf3                             (rtx, rtx, rtx);
extern rtx        gen_copysigndf3                             (rtx, rtx, rtx);
extern rtx        gen_addsf3                                  (rtx, rtx, rtx);
extern rtx        gen_adddf3                                  (rtx, rtx, rtx);
extern rtx        gen_subsf3                                  (rtx, rtx, rtx);
extern rtx        gen_subdf3                                  (rtx, rtx, rtx);
extern rtx        gen_mulsf3                                  (rtx, rtx, rtx);
extern rtx        gen_muldf3                                  (rtx, rtx, rtx);
extern rtx        gen_divsf3                                  (rtx, rtx, rtx);
extern rtx        gen_divdf3                                  (rtx, rtx, rtx);
extern rtx        gen_sqrtsf2                                 (rtx, rtx);
extern rtx        gen_sqrtdf2                                 (rtx, rtx);
extern rtx        gen_floatdisf2                              (rtx, rtx);
extern rtx        gen_floatdidf2                              (rtx, rtx);
extern rtx        gen_truncdfsf2                              (rtx, rtx);
extern rtx        gen_smaxqi3                                 (rtx, rtx, rtx);
extern rtx        gen_sminqi3                                 (rtx, rtx, rtx);
extern rtx        gen_umaxqi3                                 (rtx, rtx, rtx);
extern rtx        gen_uminqi3                                 (rtx, rtx, rtx);
extern rtx        gen_smaxhi3                                 (rtx, rtx, rtx);
extern rtx        gen_sminhi3                                 (rtx, rtx, rtx);
extern rtx        gen_umaxhi3                                 (rtx, rtx, rtx);
extern rtx        gen_uminhi3                                 (rtx, rtx, rtx);
extern rtx        gen_blockage                                (void);
extern rtx        gen_jump                                    (rtx);
extern rtx        gen_indirect_jump                           (rtx);
extern rtx        gen_imb                                     (void);
extern rtx        gen_trap                                    (void);
extern rtx        gen_get_thread_pointerdi                    (rtx);
extern rtx        gen_movdi_er_high_g                         (rtx, rtx, rtx, rtx);
extern rtx        gen_movdi_er_tlsgd                          (rtx, rtx, rtx, rtx);
extern rtx        gen_movdi_er_tlsldm                         (rtx, rtx, rtx);
extern rtx        gen_force_movdi                             (rtx, rtx);
extern rtx        gen_reload_inqi_aligned                     (rtx, rtx);
extern rtx        gen_reload_inhi_aligned                     (rtx, rtx);
extern rtx        gen_reload_outqi_aligned                    (rtx, rtx, rtx, rtx);
extern rtx        gen_reload_outhi_aligned                    (rtx, rtx, rtx, rtx);
extern rtx        gen_smaxv8qi3                               (rtx, rtx, rtx);
extern rtx        gen_sminv8qi3                               (rtx, rtx, rtx);
extern rtx        gen_umaxv8qi3                               (rtx, rtx, rtx);
extern rtx        gen_uminv8qi3                               (rtx, rtx, rtx);
extern rtx        gen_smaxv4hi3                               (rtx, rtx, rtx);
extern rtx        gen_sminv4hi3                               (rtx, rtx, rtx);
extern rtx        gen_umaxv4hi3                               (rtx, rtx, rtx);
extern rtx        gen_uminv4hi3                               (rtx, rtx, rtx);
extern rtx        gen_one_cmplv8qi2                           (rtx, rtx);
extern rtx        gen_one_cmplv4hi2                           (rtx, rtx);
extern rtx        gen_one_cmplv2si2                           (rtx, rtx);
extern rtx        gen_andv8qi3                                (rtx, rtx, rtx);
extern rtx        gen_andv4hi3                                (rtx, rtx, rtx);
extern rtx        gen_andv2si3                                (rtx, rtx, rtx);
extern rtx        gen_iorv8qi3                                (rtx, rtx, rtx);
extern rtx        gen_iorv4hi3                                (rtx, rtx, rtx);
extern rtx        gen_iorv2si3                                (rtx, rtx, rtx);
extern rtx        gen_xorv8qi3                                (rtx, rtx, rtx);
extern rtx        gen_xorv4hi3                                (rtx, rtx, rtx);
extern rtx        gen_xorv2si3                                (rtx, rtx, rtx);
extern rtx        gen_prologue_stack_probe_loop               (rtx, rtx);
extern rtx        gen_prologue_mcount                         (void);
extern rtx        gen_init_fp                                 (rtx, rtx, rtx);
extern rtx        gen_builtin_longjmp_internal                (rtx);
static inline rtx gen_arg_home                                (void);
static inline rtx
gen_arg_home(void)
{
  return 0;
}
extern rtx        gen_prefetch                                (rtx, rtx, rtx);
extern rtx        gen_trapb                                   (void);
extern rtx        gen_nop                                     (void);
extern rtx        gen_fnop                                    (void);
extern rtx        gen_unop                                    (void);
extern rtx        gen_realign                                 (rtx);
extern rtx        gen_builtin_cmpbge                          (rtx, rtx, rtx);
extern rtx        gen_builtin_amask                           (rtx, rtx);
extern rtx        gen_builtin_implver                         (rtx);
extern rtx        gen_builtin_rpcc                            (rtx);
extern rtx        gen_builtin_perr                            (rtx, rtx, rtx);
extern rtx        gen_load_locked_si                          (rtx, rtx);
extern rtx        gen_load_locked_di                          (rtx, rtx);
extern rtx        gen_store_conditional_si                    (rtx, rtx, rtx);
extern rtx        gen_store_conditional_di                    (rtx, rtx, rtx);
extern rtx        gen_atomic_compare_and_swapqi_1             (rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_compare_and_swaphi_1             (rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_exchangesi                       (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_exchangedi                       (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_exchangeqi_1                     (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_exchangehi_1                     (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_addsi                            (rtx, rtx, rtx);
extern rtx        gen_atomic_subsi                            (rtx, rtx, rtx);
extern rtx        gen_atomic_orsi                             (rtx, rtx, rtx);
extern rtx        gen_atomic_xorsi                            (rtx, rtx, rtx);
extern rtx        gen_atomic_andsi                            (rtx, rtx, rtx);
extern rtx        gen_atomic_adddi                            (rtx, rtx, rtx);
extern rtx        gen_atomic_subdi                            (rtx, rtx, rtx);
extern rtx        gen_atomic_ordi                             (rtx, rtx, rtx);
extern rtx        gen_atomic_xordi                            (rtx, rtx, rtx);
extern rtx        gen_atomic_anddi                            (rtx, rtx, rtx);
extern rtx        gen_atomic_nandsi                           (rtx, rtx, rtx);
extern rtx        gen_atomic_nanddi                           (rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_addsi                      (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_subsi                      (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_orsi                       (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_xorsi                      (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_andsi                      (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_adddi                      (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_subdi                      (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_ordi                       (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_xordi                      (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_anddi                      (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_nandsi                     (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_nanddi                     (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_add_fetchsi                      (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_sub_fetchsi                      (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_or_fetchsi                       (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_xor_fetchsi                      (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_and_fetchsi                      (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_add_fetchdi                      (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_sub_fetchdi                      (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_or_fetchdi                       (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_xor_fetchdi                      (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_and_fetchdi                      (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_nand_fetchsi                     (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_nand_fetchdi                     (rtx, rtx, rtx, rtx);
extern rtx        gen_call_value_osf_tlsgd                    (rtx, rtx, rtx);
extern rtx        gen_call_value_osf_tlsldm                   (rtx, rtx, rtx);
extern rtx        gen_extendsidi2                             (rtx, rtx);
extern rtx        gen_adddi3                                  (rtx, rtx, rtx);
extern rtx        gen_umuldi3_highpart                        (rtx, rtx, rtx);
extern rtx        gen_umulditi3                               (rtx, rtx, rtx);
extern rtx        gen_divsi3                                  (rtx, rtx, rtx);
extern rtx        gen_modsi3                                  (rtx, rtx, rtx);
extern rtx        gen_udivsi3                                 (rtx, rtx, rtx);
extern rtx        gen_umodsi3                                 (rtx, rtx, rtx);
extern rtx        gen_divdi3                                  (rtx, rtx, rtx);
extern rtx        gen_moddi3                                  (rtx, rtx, rtx);
extern rtx        gen_udivdi3                                 (rtx, rtx, rtx);
extern rtx        gen_umoddi3                                 (rtx, rtx, rtx);
extern rtx        gen_ffsdi2                                  (rtx, rtx);
extern rtx        gen_bswapsi2                                (rtx, rtx);
extern rtx        gen_bswapdi2                                (rtx, rtx);
extern rtx        gen_extendqidi2                             (rtx, rtx);
extern rtx        gen_extendhidi2                             (rtx, rtx);
extern rtx        gen_unaligned_extendqidi                    (rtx, rtx);
extern rtx        gen_unaligned_extendhidi                    (rtx, rtx);
extern rtx        gen_abstf2                                  (rtx, rtx);
extern rtx        gen_negtf2                                  (rtx, rtx);
extern rtx        gen_addtf3                                  (rtx, rtx, rtx);
extern rtx        gen_subtf3                                  (rtx, rtx, rtx);
extern rtx        gen_multf3                                  (rtx, rtx, rtx);
extern rtx        gen_divtf3                                  (rtx, rtx, rtx);
extern rtx        gen_fix_truncdfdi2                          (rtx, rtx);
extern rtx        gen_fixuns_truncdfdi2                       (rtx, rtx);
extern rtx        gen_fix_truncsfdi2                          (rtx, rtx);
extern rtx        gen_fixuns_truncsfdi2                       (rtx, rtx);
extern rtx        gen_fix_trunctfdi2                          (rtx, rtx);
extern rtx        gen_fixuns_trunctfdi2                       (rtx, rtx);
extern rtx        gen_floatditf2                              (rtx, rtx);
extern rtx        gen_floatunsdisf2                           (rtx, rtx);
extern rtx        gen_floatunsdidf2                           (rtx, rtx);
extern rtx        gen_floatunsditf2                           (rtx, rtx);
extern rtx        gen_extendsfdf2                             (rtx, rtx);
extern rtx        gen_extendsftf2                             (rtx, rtx);
extern rtx        gen_extenddftf2                             (rtx, rtx);
extern rtx        gen_trunctfdf2                              (rtx, rtx);
extern rtx        gen_trunctfsf2                              (rtx, rtx);
extern rtx        gen_absdi2                                  (rtx, rtx);
extern rtx        gen_absdi2_same                             (rtx, rtx);
extern rtx        gen_absdi2_diff                             (rtx, rtx);
extern rtx        gen_smaxdi3                                 (rtx, rtx, rtx);
extern rtx        gen_smindi3                                 (rtx, rtx, rtx);
extern rtx        gen_umaxdi3                                 (rtx, rtx, rtx);
extern rtx        gen_umindi3                                 (rtx, rtx, rtx);
extern rtx        gen_smaxdf3                                 (rtx, rtx, rtx);
extern rtx        gen_smindf3                                 (rtx, rtx, rtx);
extern rtx        gen_smaxsf3                                 (rtx, rtx, rtx);
extern rtx        gen_sminsf3                                 (rtx, rtx, rtx);
extern rtx        gen_cbranchdf4                              (rtx, rtx, rtx, rtx);
extern rtx        gen_cbranchtf4                              (rtx, rtx, rtx, rtx);
extern rtx        gen_cbranchdi4                              (rtx, rtx, rtx, rtx);
extern rtx        gen_cstoredf4                               (rtx, rtx, rtx, rtx);
extern rtx        gen_cstoretf4                               (rtx, rtx, rtx, rtx);
extern rtx        gen_cstoredi4                               (rtx, rtx, rtx, rtx);
extern rtx        gen_movsicc                                 (rtx, rtx, rtx, rtx);
extern rtx        gen_movdicc                                 (rtx, rtx, rtx, rtx);
extern rtx        gen_movsfcc                                 (rtx, rtx, rtx, rtx);
extern rtx        gen_movdfcc                                 (rtx, rtx, rtx, rtx);
extern rtx        gen_call                                    (rtx, rtx, rtx, rtx);
extern rtx        gen_sibcall                                 (rtx, rtx);
extern rtx        gen_call_osf                                (rtx, rtx);
extern rtx        gen_call_vms                                (rtx, rtx);
extern rtx        gen_call_value                              (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_sibcall_value                           (rtx, rtx, rtx);
extern rtx        gen_call_value_osf                          (rtx, rtx, rtx);
extern rtx        gen_call_value_vms                          (rtx, rtx, rtx);
extern rtx        gen_untyped_call                            (rtx, rtx, rtx);
extern rtx        gen_return                                  (void);
extern rtx        gen_tablejump                               (rtx, rtx);
extern rtx        gen_clear_cache                             (rtx, rtx);
extern rtx        gen_set_thread_pointerdi                    (rtx);
static inline rtx gen_builtin_establish_vms_condition_handler (rtx, rtx);
static inline rtx
gen_builtin_establish_vms_condition_handler(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b))
{
  return 0;
}
static inline rtx gen_builtin_revert_vms_condition_handler    (rtx);
static inline rtx
gen_builtin_revert_vms_condition_handler(rtx ARG_UNUSED (a))
{
  return 0;
}
extern rtx        gen_movsf                                   (rtx, rtx);
extern rtx        gen_movdf                                   (rtx, rtx);
extern rtx        gen_movtf                                   (rtx, rtx);
extern rtx        gen_movsi                                   (rtx, rtx);
extern rtx        gen_movdi                                   (rtx, rtx);
extern rtx        gen_movti                                   (rtx, rtx);
extern rtx        gen_aligned_loadqi                          (rtx, rtx, rtx, rtx);
extern rtx        gen_aligned_loadhi                          (rtx, rtx, rtx, rtx);
extern rtx        gen_unaligned_loadqi                        (rtx, rtx, rtx, rtx);
extern rtx        gen_unaligned_loadhi                        (rtx, rtx, rtx, rtx);
extern rtx        gen_aligned_store                           (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_unaligned_storeqi                       (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_unaligned_storehi                       (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_movqi                                   (rtx, rtx);
extern rtx        gen_movhi                                   (rtx, rtx);
extern rtx        gen_movcqi                                  (rtx, rtx);
extern rtx        gen_reload_inqi                             (rtx, rtx, rtx);
extern rtx        gen_reload_inhi                             (rtx, rtx, rtx);
extern rtx        gen_reload_incqi                            (rtx, rtx, rtx);
extern rtx        gen_reload_outqi                            (rtx, rtx, rtx);
extern rtx        gen_reload_outhi                            (rtx, rtx, rtx);
extern rtx        gen_reload_outcqi                           (rtx, rtx, rtx);
extern rtx        gen_movv8qi                                 (rtx, rtx);
extern rtx        gen_movv4hi                                 (rtx, rtx);
extern rtx        gen_movv2si                                 (rtx, rtx);
extern rtx        gen_movmisalignv8qi                         (rtx, rtx);
extern rtx        gen_movmisalignv4hi                         (rtx, rtx);
extern rtx        gen_movmisalignv2si                         (rtx, rtx);
extern rtx        gen_vec_shl_v8qi                            (rtx, rtx, rtx);
extern rtx        gen_vec_shl_v4hi                            (rtx, rtx, rtx);
extern rtx        gen_vec_shl_v2si                            (rtx, rtx, rtx);
extern rtx        gen_vec_shr_v8qi                            (rtx, rtx, rtx);
extern rtx        gen_vec_shr_v4hi                            (rtx, rtx, rtx);
extern rtx        gen_vec_shr_v2si                            (rtx, rtx, rtx);
extern rtx        gen_extvmisaligndi                          (rtx, rtx, rtx, rtx);
extern rtx        gen_extzvdi                                 (rtx, rtx, rtx, rtx);
extern rtx        gen_extzvmisaligndi                         (rtx, rtx, rtx, rtx);
extern rtx        gen_insvmisaligndi                          (rtx, rtx, rtx, rtx);
extern rtx        gen_cpymemqi                                (rtx, rtx, rtx, rtx);
static inline rtx gen_cpymemdi                                (rtx, rtx, rtx, rtx);
static inline rtx
gen_cpymemdi(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c), rtx ARG_UNUSED (d))
{
  return 0;
}
extern rtx        gen_setmemqi                                (rtx, rtx, rtx, rtx);
static inline rtx gen_setmemdi                                (rtx, rtx, rtx, rtx);
static inline rtx
gen_setmemdi(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c), rtx ARG_UNUSED (d))
{
  return 0;
}
extern rtx        gen_stack_probe_internal                    (rtx);
extern rtx        gen_allocate_stack                          (rtx, rtx);
extern rtx        gen_prologue                                (void);
extern rtx        gen_prologue_ldgp                           (void);
extern rtx        gen_epilogue                                (void);
extern rtx        gen_sibcall_epilogue                        (void);
extern rtx        gen_builtin_longjmp                         (rtx);
extern rtx        gen_builtin_setjmp_receiver                 (rtx);
extern rtx        gen_exception_receiver                      (void);
static inline rtx gen_nonlocal_goto_receiver                  (void);
static inline rtx
gen_nonlocal_goto_receiver(void)
{
  return 0;
}
extern rtx        gen_extbl                                   (rtx, rtx, rtx);
extern rtx        gen_extwl                                   (rtx, rtx, rtx);
extern rtx        gen_extll                                   (rtx, rtx, rtx);
extern rtx        gen_extql                                   (rtx, rtx, rtx);
extern rtx        gen_builtin_insbl                           (rtx, rtx, rtx);
extern rtx        gen_builtin_inswl                           (rtx, rtx, rtx);
extern rtx        gen_builtin_insll                           (rtx, rtx, rtx);
extern rtx        gen_inswh                                   (rtx, rtx, rtx);
extern rtx        gen_inslh                                   (rtx, rtx, rtx);
extern rtx        gen_insqh                                   (rtx, rtx, rtx);
extern rtx        gen_mskbl                                   (rtx, rtx, rtx);
extern rtx        gen_mskwl                                   (rtx, rtx, rtx);
extern rtx        gen_mskll                                   (rtx, rtx, rtx);
extern rtx        gen_mskql                                   (rtx, rtx, rtx);
extern rtx        gen_mskwh                                   (rtx, rtx, rtx);
extern rtx        gen_msklh                                   (rtx, rtx, rtx);
extern rtx        gen_mskqh                                   (rtx, rtx, rtx);
extern rtx        gen_builtin_zap                             (rtx, rtx, rtx);
extern rtx        gen_builtin_zapnot                          (rtx, rtx, rtx);
extern rtx        gen_builtin_minub8                          (rtx, rtx, rtx);
extern rtx        gen_builtin_minsb8                          (rtx, rtx, rtx);
extern rtx        gen_builtin_minuw4                          (rtx, rtx, rtx);
extern rtx        gen_builtin_minsw4                          (rtx, rtx, rtx);
extern rtx        gen_builtin_maxub8                          (rtx, rtx, rtx);
extern rtx        gen_builtin_maxsb8                          (rtx, rtx, rtx);
extern rtx        gen_builtin_maxuw4                          (rtx, rtx, rtx);
extern rtx        gen_builtin_maxsw4                          (rtx, rtx, rtx);
extern rtx        gen_builtin_pklb                            (rtx, rtx);
extern rtx        gen_builtin_pkwb                            (rtx, rtx);
extern rtx        gen_builtin_unpkbl                          (rtx, rtx);
extern rtx        gen_builtin_unpkbw                          (rtx, rtx);
extern rtx        gen_memory_barrier                          (void);
extern rtx        gen_atomic_compare_and_swapsi               (rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_compare_and_swapdi               (rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_compare_and_swapqi               (rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_compare_and_swaphi               (rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_exchangeqi                       (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_exchangehi                       (rtx, rtx, rtx, rtx);

#endif /* GCC_INSN_FLAGS_H */
