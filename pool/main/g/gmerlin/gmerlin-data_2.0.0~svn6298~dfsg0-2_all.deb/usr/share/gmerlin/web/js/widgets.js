/* New widget library */

