#ifndef __BG_VERSION_H_
#define __BG_VERSION_H_

#define BG_VERSION "2.0.0"

#define BG_VERSION_MAJOR 2
#define BG_VERSION_MINOR 0
#define BG_VERSION_MICRO 0

#define BG_MAKE_BUILD(a,b,c) ((a << 16) + (b << 8) + c)

#define BG_BUILD \
BG_MAKE_BUILD(BG_VERSION_MAJOR, \
                BG_VERSION_MINOR, \
                BG_VERSION_MICRO)

#endif // __BG_VERSION_H_
