var searchData=
[
  ['get_5fpointer_5ffunc_625',['get_pointer_func',['../structglobus__module__descriptor__s.html#a4e06505985336d2f87eb229bcb274a09',1,'globus_module_descriptor_s']]]
];
