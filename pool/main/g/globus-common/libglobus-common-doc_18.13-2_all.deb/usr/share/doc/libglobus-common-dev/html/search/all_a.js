var searchData=
[
  ['memory_20pool_359',['Memory Pool',['../group__globus__memory.html',1,'']]],
  ['module_20activation_20management_360',['Module Activation Management',['../group__globus__module.html',1,'']]],
  ['module_5fname_361',['module_name',['../structglobus__module__descriptor__s.html#a432ea5394ce4e3870880735864fc4f9b',1,'globus_module_descriptor_s']]],
  ['mutual_20exclusion_362',['Mutual Exclusion',['../group__globus__mutex.html',1,'']]]
];
