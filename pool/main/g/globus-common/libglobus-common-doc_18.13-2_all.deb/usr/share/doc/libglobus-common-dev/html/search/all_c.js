var searchData=
[
  ['password_364',['password',['../structglobus__url__t.html#a86cb729a9e34a4ff4bb845911caa4c4f',1,'globus_url_t']]],
  ['port_365',['port',['../structglobus__url__t.html#a1002c75ce212166a6e54a0715cbd33c2',1,'globus_url_t']]],
  ['priority_20queue_366',['Priority Queue',['../group__globus__priority__q.html',1,'']]]
];
