var searchData=
[
  ['globus_5fcallback_5ferror_5ftype_5ft_663',['globus_callback_error_type_t',['../group__globus__callback.html#gabdc22c8e6432da1fd9ee7a43da965cc9',1,'globus_callback.h']]],
  ['globus_5fcallback_5fspace_5fbehavior_5ft_664',['globus_callback_space_behavior_t',['../group__globus__callback__spaces.html#gac5c2e2ee259e3bceaea0b201bcc3efaa',1,'globus_callback.h']]],
  ['globus_5furl_5fscheme_5ft_665',['globus_url_scheme_t',['../group__globus__url.html#ga774eeb8d0fd9e51f6be47aef44cf1aec',1,'globus_url.h']]]
];
