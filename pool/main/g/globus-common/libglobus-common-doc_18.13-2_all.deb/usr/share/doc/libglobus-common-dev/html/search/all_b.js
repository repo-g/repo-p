var searchData=
[
  ['one_2dtime_20execution_363',['One-time execution',['../group__globus__thread__once.html',1,'']]]
];
