var searchData=
[
  ['condition_20variables_4',['Condition Variables',['../group__globus__cond.html',1,'']]]
];
