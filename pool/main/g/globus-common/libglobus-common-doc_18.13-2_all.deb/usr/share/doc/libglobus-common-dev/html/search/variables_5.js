var searchData=
[
  ['module_5fname_627',['module_name',['../structglobus__module__descriptor__s.html#a432ea5394ce4e3870880735864fc4f9b',1,'globus_module_descriptor_s']]]
];
