var searchData=
[
  ['url_20string_20parser_373',['URL String Parser',['../group__globus__url.html',1,'']]],
  ['url_5fpath_374',['url_path',['../structglobus__url__t.html#a110e29cafeaabb1fdeba0b1f17ed211a',1,'globus_url_t']]],
  ['url_5fspecific_5fpart_375',['url_specific_part',['../structglobus__url__t.html#a184c8c55bcaea5f9f10226b59f07800a',1,'globus_url_t']]],
  ['user_376',['user',['../structglobus__url__t.html#a7820dc87cbed173a8e81df403d35920a',1,'globus_url_t']]]
];
