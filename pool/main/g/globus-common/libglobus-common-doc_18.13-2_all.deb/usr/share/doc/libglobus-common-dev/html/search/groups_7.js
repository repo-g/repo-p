var searchData=
[
  ['memory_20pool_718',['Memory Pool',['../group__globus__memory.html',1,'']]],
  ['module_20activation_20management_719',['Module Activation Management',['../group__globus__module.html',1,'']]],
  ['mutual_20exclusion_720',['Mutual Exclusion',['../group__globus__mutex.html',1,'']]]
];
