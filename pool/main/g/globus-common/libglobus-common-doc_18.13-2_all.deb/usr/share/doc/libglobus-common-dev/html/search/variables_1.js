var searchData=
[
  ['deactivation_5ffunc_621',['deactivation_func',['../structglobus__module__descriptor__s.html#aeb4392c0f55bd73999a91debd8c530f6',1,'globus_module_descriptor_s']]],
  ['dn_622',['dn',['../structglobus__url__t.html#a44bfef2ffbac39a2c13afead20896634',1,'globus_url_t']]]
];
