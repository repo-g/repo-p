var searchData=
[
  ['error_20construction_701',['Error Construction',['../group__globus__errno__error__object.html',1,'(Global Namespace)'],['../group__globus__generic__error__object.html',1,'(Global Namespace)']]],
  ['error_20data_20accessors_20and_20modifiers_702',['Error Data Accessors and Modifiers',['../group__globus__errno__error__accessor.html',1,'(Global Namespace)'],['../group__globus__generic__error__accessor.html',1,'(Global Namespace)']]],
  ['error_20handling_20helpers_703',['Error Handling Helpers',['../group__globus__errno__error__utility.html',1,'(Global Namespace)'],['../group__globus__generic__error__utility.html',1,'(Global Namespace)']]]
];
