var searchData=
[
  ['activation_5ffunc_618',['activation_func',['../structglobus__module__descriptor__s.html#a618e87d23472e7a4559b0c9dd987b2fb',1,'globus_module_descriptor_s']]],
  ['atexit_5ffunc_619',['atexit_func',['../structglobus__module__descriptor__s.html#aedd35e569e27d48a0a04a1e07b05c77a',1,'globus_module_descriptor_s']]],
  ['attributes_620',['attributes',['../structglobus__url__t.html#a17daeb126e4a903bc9c8e6a137d37265',1,'globus_url_t']]]
];
