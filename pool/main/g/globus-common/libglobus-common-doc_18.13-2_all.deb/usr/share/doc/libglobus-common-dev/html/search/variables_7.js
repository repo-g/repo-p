var searchData=
[
  ['scheme_630',['scheme',['../structglobus__url__t.html#ac21843402017d0a6bf169b6a750ab532',1,'globus_url_t']]],
  ['scheme_5ftype_631',['scheme_type',['../structglobus__url__t.html#ae55d4a3c79a86a30e892a8f94da0623c',1,'globus_url_t']]],
  ['scope_632',['scope',['../structglobus__url__t.html#a9f56bc7e168c9ba8b74c5c823d67f27b',1,'globus_url_t']]]
];
