/*************** interface to a parallel communication system ********/
#   include "ga.h"
#   define SYNC      GA_Sync
#   define NPROC     GA_Nnodes
#   define ME        GA_Nodeid
#   define ERROR     GA_Error

