var PolarStereographic_8hpp =
[
    [ "GeographicLib::PolarStereographic", "classGeographicLib_1_1PolarStereographic.html", "classGeographicLib_1_1PolarStereographic" ]
];