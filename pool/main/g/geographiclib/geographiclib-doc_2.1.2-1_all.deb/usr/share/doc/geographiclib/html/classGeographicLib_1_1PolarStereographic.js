var classGeographicLib_1_1PolarStereographic =
[
    [ "PolarStereographic", "classGeographicLib_1_1PolarStereographic.html#a170d21f9c7a2e922c57fc83a44ea3dfa", null ],
    [ "SetScale", "classGeographicLib_1_1PolarStereographic.html#a3f957214eb1d1248277a680e4c4ceed5", null ],
    [ "Forward", "classGeographicLib_1_1PolarStereographic.html#ac958cab16437326a4ffaea0e7a10c3aa", null ],
    [ "Reverse", "classGeographicLib_1_1PolarStereographic.html#a0fbe410880f20fe78b7b17bef574ce73", null ],
    [ "Forward", "classGeographicLib_1_1PolarStereographic.html#aa2d66422f3c26b7db7522de3fc05b8e8", null ],
    [ "Reverse", "classGeographicLib_1_1PolarStereographic.html#adc59298b4e00d0bbbcd123a279eb3ed7", null ],
    [ "EquatorialRadius", "classGeographicLib_1_1PolarStereographic.html#a407ab6f87a6b4ea053cb8e8ca7665695", null ],
    [ "Flattening", "classGeographicLib_1_1PolarStereographic.html#ab3cb35ac5f3f31305d4a40c6c9a0326b", null ],
    [ "CentralScale", "classGeographicLib_1_1PolarStereographic.html#a9c8370a7eb202620b99f9f95ac57acfc", null ],
    [ "UPS", "classGeographicLib_1_1PolarStereographic.html#aa968efa8480ecff213cf8a41f1fb2687", null ]
];