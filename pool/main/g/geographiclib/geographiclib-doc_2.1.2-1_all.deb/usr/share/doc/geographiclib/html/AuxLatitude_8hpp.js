var AuxLatitude_8hpp =
[
    [ "GeographicLib::AuxAngle< T >", "classGeographicLib_1_1AuxAngle.html", "classGeographicLib_1_1AuxAngle" ],
    [ "GeographicLib::AuxLatitude< T >", "classGeographicLib_1_1AuxLatitude.html", "classGeographicLib_1_1AuxLatitude" ],
    [ "GEOGRAPHICLIB_AUXLATITUDE_ORDER", "AuxLatitude_8hpp.html#ae1458a0b8d00bd107f479d5d5f697d7d", null ]
];