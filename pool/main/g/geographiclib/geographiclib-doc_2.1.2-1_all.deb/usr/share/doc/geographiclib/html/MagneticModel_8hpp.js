var MagneticModel_8hpp =
[
    [ "GeographicLib::MagneticModel", "classGeographicLib_1_1MagneticModel.html", "classGeographicLib_1_1MagneticModel" ]
];