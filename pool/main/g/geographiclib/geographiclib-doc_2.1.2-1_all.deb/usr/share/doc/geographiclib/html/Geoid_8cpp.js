var Geoid_8cpp =
[
    [ "GEOGRAPHICLIB_DATA", "Geoid_8cpp.html#a45687ef771d809c1c369daea074cc109", null ],
    [ "GEOGRAPHICLIB_GEOID_DEFAULT_NAME", "Geoid_8cpp.html#ad6a9d10e96f7073461e02388058be5ab", null ]
];