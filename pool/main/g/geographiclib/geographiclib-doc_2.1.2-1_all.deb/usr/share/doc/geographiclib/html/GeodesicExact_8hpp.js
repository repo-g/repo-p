var GeodesicExact_8hpp =
[
    [ "GeographicLib::GeodesicExact", "classGeographicLib_1_1GeodesicExact.html", "classGeographicLib_1_1GeodesicExact" ]
];