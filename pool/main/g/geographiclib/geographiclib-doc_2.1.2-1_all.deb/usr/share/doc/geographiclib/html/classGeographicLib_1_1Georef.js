var classGeographicLib_1_1Georef =
[
    [ "Forward", "classGeographicLib_1_1Georef.html#a7b06b5af0bdc8464449078c0277d8bbc", null ],
    [ "Reverse", "classGeographicLib_1_1Georef.html#abb43fbcfb00a963bc8e71db69a97854a", null ],
    [ "Resolution", "classGeographicLib_1_1Georef.html#aa7a7dc7fab9031fe2cad7b8acea5261d", null ],
    [ "Precision", "classGeographicLib_1_1Georef.html#a08f061e445595cfb0f4c54867c3964f1", null ]
];