var Geoid_8hpp =
[
    [ "GeographicLib::Geoid", "classGeographicLib_1_1Geoid.html", "classGeographicLib_1_1Geoid" ],
    [ "GEOGRAPHICLIB_GEOID_PGM_PIXEL_WIDTH", "Geoid_8hpp.html#a905bae3bb674c2fdbbd7e9c32a85b8df", null ]
];