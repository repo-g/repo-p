var classGeographicLib_1_1OSGB =
[
    [ "Forward", "classGeographicLib_1_1OSGB.html#a92618eea9870908e11446875d80aab6b", null ],
    [ "Reverse", "classGeographicLib_1_1OSGB.html#ae006380e574858a81011752dd1d4af60", null ],
    [ "Forward", "classGeographicLib_1_1OSGB.html#a0f705bee98c6669ca7a95394712fd758", null ],
    [ "Reverse", "classGeographicLib_1_1OSGB.html#ab804929a4126ed390a40d35e837b4001", null ],
    [ "GridReference", "classGeographicLib_1_1OSGB.html#a0a79e8f2babae1eb0305a0e728fea8c8", null ],
    [ "GridReference", "classGeographicLib_1_1OSGB.html#a3693cfef49442747750e8393c81014aa", null ],
    [ "EquatorialRadius", "classGeographicLib_1_1OSGB.html#a67af52d02ee16e533774b5ac5ffc078a", null ],
    [ "Flattening", "classGeographicLib_1_1OSGB.html#aae688ebd8c126f22517eaa0a01d659f8", null ],
    [ "CentralScale", "classGeographicLib_1_1OSGB.html#a65210bfdcac362f393a8f81f28259ad0", null ],
    [ "OriginLatitude", "classGeographicLib_1_1OSGB.html#ad6bcef7e2dcc2992831e101bf0b05fa8", null ],
    [ "OriginLongitude", "classGeographicLib_1_1OSGB.html#a4eb3b20734af47c9661d40581555c345", null ],
    [ "FalseNorthing", "classGeographicLib_1_1OSGB.html#a74072d4e62fcd4ca679b222716b6a6a1", null ],
    [ "FalseEasting", "classGeographicLib_1_1OSGB.html#ab27e19f7688f6b472d217b31aeae079c", null ]
];