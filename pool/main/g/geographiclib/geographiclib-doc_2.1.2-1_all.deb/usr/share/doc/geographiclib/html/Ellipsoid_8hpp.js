var Ellipsoid_8hpp =
[
    [ "GeographicLib::Ellipsoid", "classGeographicLib_1_1Ellipsoid.html", "classGeographicLib_1_1Ellipsoid" ]
];