var classGeographicLib_1_1UTMUPS =
[
    [ "zonespec", "classGeographicLib_1_1UTMUPS.html#a0c459615da18cc899a960bdc8c5b11b7", [
      [ "MINPSEUDOZONE", "classGeographicLib_1_1UTMUPS.html#a0c459615da18cc899a960bdc8c5b11b7a058ac8a834bbc78ce73d9b37a1a5dfb9", null ],
      [ "INVALID", "classGeographicLib_1_1UTMUPS.html#a0c459615da18cc899a960bdc8c5b11b7aeb6750fb82edce6e5b58178a38ee8bd0", null ],
      [ "MATCH", "classGeographicLib_1_1UTMUPS.html#a0c459615da18cc899a960bdc8c5b11b7a9059a8e3b4721e27869e99ed1ae3d320", null ],
      [ "UTM", "classGeographicLib_1_1UTMUPS.html#a0c459615da18cc899a960bdc8c5b11b7aacc8f89ac6144b1e445ca21cbe9a2533", null ],
      [ "STANDARD", "classGeographicLib_1_1UTMUPS.html#a0c459615da18cc899a960bdc8c5b11b7adf96495ab4bfbf495f1fe31aebb9e406", null ],
      [ "MAXPSEUDOZONE", "classGeographicLib_1_1UTMUPS.html#a0c459615da18cc899a960bdc8c5b11b7ac22db7e136b6e06fba7c3c06b5888362", null ],
      [ "MINZONE", "classGeographicLib_1_1UTMUPS.html#a0c459615da18cc899a960bdc8c5b11b7af91adc987ae7295bfb6d3786b23c58e1", null ],
      [ "UPS", "classGeographicLib_1_1UTMUPS.html#a0c459615da18cc899a960bdc8c5b11b7a40256f9ab9f277957f8ab697bcd2fd42", null ],
      [ "MINUTMZONE", "classGeographicLib_1_1UTMUPS.html#a0c459615da18cc899a960bdc8c5b11b7a1413e6cc83d4bf1eb4ad1c0f1d745eb6", null ],
      [ "MAXUTMZONE", "classGeographicLib_1_1UTMUPS.html#a0c459615da18cc899a960bdc8c5b11b7ae8e04ab8df50a062c1fe277a6880bc19", null ],
      [ "MAXZONE", "classGeographicLib_1_1UTMUPS.html#a0c459615da18cc899a960bdc8c5b11b7a12dabceb6da15aa0fc94b9406aca921a", null ]
    ] ],
    [ "StandardZone", "classGeographicLib_1_1UTMUPS.html#a62623c295d1b43318a9fa762c3da94ea", null ],
    [ "Forward", "classGeographicLib_1_1UTMUPS.html#a921d6c23e728e0b17651902d43fb56e8", null ],
    [ "Reverse", "classGeographicLib_1_1UTMUPS.html#aaf417ae6bed6da324aa03fc96ee0dda4", null ],
    [ "Forward", "classGeographicLib_1_1UTMUPS.html#aa21ec1bc26f691e0a6f2ccc44debe6f0", null ],
    [ "Reverse", "classGeographicLib_1_1UTMUPS.html#ac8cbfd7b15c96b52b876b54ce68f7b4d", null ],
    [ "Transfer", "classGeographicLib_1_1UTMUPS.html#ac333eaff84cc487fee67440de3383bf7", null ],
    [ "DecodeZone", "classGeographicLib_1_1UTMUPS.html#ad74d52d7ebeff195019745f791f30562", null ],
    [ "EncodeZone", "classGeographicLib_1_1UTMUPS.html#a8ebfb44e3475482f7ce5ace0e840069e", null ],
    [ "DecodeEPSG", "classGeographicLib_1_1UTMUPS.html#aad33325ea4fdb2d36ca49738dbf23773", null ],
    [ "EncodeEPSG", "classGeographicLib_1_1UTMUPS.html#a188cfaa3585d1337c856b1addcdf3e0c", null ],
    [ "UTMShift", "classGeographicLib_1_1UTMUPS.html#abd70d3f90f5c79a09bdd217b67e6729b", null ],
    [ "EquatorialRadius", "classGeographicLib_1_1UTMUPS.html#a7f521b6e9df70dfa29d164b101b94f74", null ],
    [ "Flattening", "classGeographicLib_1_1UTMUPS.html#a182de2e29f1181c55a266777039b8a9d", null ]
];