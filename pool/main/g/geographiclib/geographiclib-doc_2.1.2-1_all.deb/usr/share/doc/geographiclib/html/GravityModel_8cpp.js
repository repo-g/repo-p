var GravityModel_8cpp =
[
    [ "GEOGRAPHICLIB_DATA", "GravityModel_8cpp.html#a45687ef771d809c1c369daea074cc109", null ],
    [ "GEOGRAPHICLIB_GRAVITY_DEFAULT_NAME", "GravityModel_8cpp.html#adacf2a85fb390397d1f985fc7e880611", null ]
];