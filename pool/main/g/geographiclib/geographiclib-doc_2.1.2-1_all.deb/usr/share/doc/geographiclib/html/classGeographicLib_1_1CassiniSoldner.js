var classGeographicLib_1_1CassiniSoldner =
[
    [ "CassiniSoldner", "classGeographicLib_1_1CassiniSoldner.html#a4fd00cc4ec0f84ede2d2ce7f5621d527", null ],
    [ "CassiniSoldner", "classGeographicLib_1_1CassiniSoldner.html#abde11c73ee57e3162f8a35ac941cb898", null ],
    [ "Reset", "classGeographicLib_1_1CassiniSoldner.html#af9bdc7088bca547dcc191691b2737759", null ],
    [ "Forward", "classGeographicLib_1_1CassiniSoldner.html#af240875ac77c58b4798b636843660351", null ],
    [ "Reverse", "classGeographicLib_1_1CassiniSoldner.html#aecebcfcf173eaad0f8e9b79a298dab38", null ],
    [ "Forward", "classGeographicLib_1_1CassiniSoldner.html#ac08c96828dd21d0805608d15020de870", null ],
    [ "Reverse", "classGeographicLib_1_1CassiniSoldner.html#a6c7f42e5f1ab61cedd987e508169736c", null ],
    [ "Init", "classGeographicLib_1_1CassiniSoldner.html#a7fb806ea0e14cd9d22e62398b7f556f7", null ],
    [ "LatitudeOrigin", "classGeographicLib_1_1CassiniSoldner.html#a1a4e4120796d1891f042a37189abfa5d", null ],
    [ "LongitudeOrigin", "classGeographicLib_1_1CassiniSoldner.html#ada0b22054f9c2843111326d1df703e17", null ],
    [ "EquatorialRadius", "classGeographicLib_1_1CassiniSoldner.html#aa488545cc3236e9a15eb4e95eaad8b10", null ],
    [ "Flattening", "classGeographicLib_1_1CassiniSoldner.html#ab070c6065dee563cfd299031672c2ba9", null ]
];