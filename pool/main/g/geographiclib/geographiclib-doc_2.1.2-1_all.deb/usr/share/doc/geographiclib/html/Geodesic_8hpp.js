var Geodesic_8hpp =
[
    [ "GeographicLib::Geodesic", "classGeographicLib_1_1Geodesic.html", "classGeographicLib_1_1Geodesic" ],
    [ "GEOGRAPHICLIB_GEODESIC_ORDER", "Geodesic_8hpp.html#ad09a19b0956ce78fcdd5dc664bf0d6e4", null ]
];