var GeoCoords_8hpp =
[
    [ "GeographicLib::GeoCoords", "classGeographicLib_1_1GeoCoords.html", "classGeographicLib_1_1GeoCoords" ]
];