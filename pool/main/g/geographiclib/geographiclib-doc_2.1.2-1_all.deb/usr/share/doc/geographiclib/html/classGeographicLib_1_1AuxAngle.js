var classGeographicLib_1_1AuxAngle =
[
    [ "real", "classGeographicLib_1_1AuxAngle.html#a2d23b40556c8a66f42585428f67174e4", null ],
    [ "AuxAngle", "classGeographicLib_1_1AuxAngle.html#a4c76ac62ed6a3892e5877b11179d9492", null ],
    [ "y", "classGeographicLib_1_1AuxAngle.html#a7b54ee9e36c24c51d4ae8e88620d1766", null ],
    [ "x", "classGeographicLib_1_1AuxAngle.html#a3380a6f55b7c2f9fc4eb4beeffb3afd1", null ],
    [ "y", "classGeographicLib_1_1AuxAngle.html#a267f365560bb807eb6914e1aa9228ec1", null ],
    [ "x", "classGeographicLib_1_1AuxAngle.html#afcebac1137f0cf85c74c3d03f893585e", null ],
    [ "degrees", "classGeographicLib_1_1AuxAngle.html#a6c22abfd2ac18f504947c200e9e6c3a8", null ],
    [ "radians", "classGeographicLib_1_1AuxAngle.html#aea650694863c19b9933f3d3d77ef1e59", null ],
    [ "tan", "classGeographicLib_1_1AuxAngle.html#a8378e458a21b7d0b7dad7329eaf956ab", null ],
    [ "normalized", "classGeographicLib_1_1AuxAngle.html#ae6158f2b7962eb08426b0d53dad32729", null ],
    [ "normalize", "classGeographicLib_1_1AuxAngle.html#ae2159c1f4e5089835ef27f6ae74fe164", null ],
    [ "copyquadrant", "classGeographicLib_1_1AuxAngle.html#a9d514fd40b6d64fc2a8c9b47fdcad920", null ],
    [ "operator+=", "classGeographicLib_1_1AuxAngle.html#a03110f7bece0fbf63e7ff6cedbf816f1", null ],
    [ "degrees", "classGeographicLib_1_1AuxAngle.html#abb9e53019f7a23e0b8e84fc8be7a63e4", null ],
    [ "radians", "classGeographicLib_1_1AuxAngle.html#a3f495cfb26fe3534b17432c15c3d85ec", null ],
    [ "NaN", "classGeographicLib_1_1AuxAngle.html#acacb3db10197eb8f1d029f928f30e9c0", null ],
    [ "AbsError", "classGeographicLib_1_1AuxAngle.html#aac4fb8fdf7048afb070f8e15efc5605c", null ],
    [ "RelError", "classGeographicLib_1_1AuxAngle.html#a5880cdbff5520d89ece043c1cf4715cb", null ]
];