var Constants_8hpp =
[
    [ "GeographicLib::Constants", "classGeographicLib_1_1Constants.html", "classGeographicLib_1_1Constants" ],
    [ "GeographicLib::GeographicErr", "classGeographicLib_1_1GeographicErr.html", "classGeographicLib_1_1GeographicErr" ],
    [ "GEOGRAPHICLIB_EXPORT", "Constants_8hpp.html#a4eef709a4899767a7eba818ce2e3450e", null ],
    [ "GEOGRAPHICLIB_DEPRECATED", "Constants_8hpp.html#ab656f5990d603ef2611943cc07944106", null ]
];