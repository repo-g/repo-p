var classGeographicLib_1_1Geoid =
[
    [ "convertflag", "classGeographicLib_1_1Geoid.html#a58ddbd0fd48c25b361f45bdb70dadb96", [
      [ "ELLIPSOIDTOGEOID", "classGeographicLib_1_1Geoid.html#a58ddbd0fd48c25b361f45bdb70dadb96a4a1db06e9dcfa1ebb345c616151ab70d", null ],
      [ "NONE", "classGeographicLib_1_1Geoid.html#a58ddbd0fd48c25b361f45bdb70dadb96a677322ba74ea5494e67478c3dc1780d5", null ],
      [ "GEOIDTOELLIPSOID", "classGeographicLib_1_1Geoid.html#a58ddbd0fd48c25b361f45bdb70dadb96a96385bcbc41f3d933588f6d6a9868473", null ]
    ] ],
    [ "Geoid", "classGeographicLib_1_1Geoid.html#ac3556c755dad0d43c3be0913df08b395", null ],
    [ "CacheArea", "classGeographicLib_1_1Geoid.html#aacffcd7e83eaad9266ae74ce917c54ea", null ],
    [ "CacheAll", "classGeographicLib_1_1Geoid.html#a64d6dfd88efc53c689cfb09545b67ed2", null ],
    [ "CacheClear", "classGeographicLib_1_1Geoid.html#ab11f77f9eba0e503a769d76a4afddd6e", null ],
    [ "operator()", "classGeographicLib_1_1Geoid.html#ab93330904bbfd607d6adde2cef844b9b", null ],
    [ "ConvertHeight", "classGeographicLib_1_1Geoid.html#aa52f250ffe18aa9fee6e7e4cc03071ae", null ],
    [ "Description", "classGeographicLib_1_1Geoid.html#a23c14306c58069df33c666a70fa52896", null ],
    [ "DateTime", "classGeographicLib_1_1Geoid.html#ab09d185007255e597647cb64c62b5c32", null ],
    [ "GeoidFile", "classGeographicLib_1_1Geoid.html#a58a6ab8dfea0b1ee21eeb177ee7a3b7e", null ],
    [ "GeoidName", "classGeographicLib_1_1Geoid.html#ac41c00fc2082547131f077883f30189b", null ],
    [ "GeoidDirectory", "classGeographicLib_1_1Geoid.html#a2becc86f9e7ed6d14d26ba3eb4a46984", null ],
    [ "Interpolation", "classGeographicLib_1_1Geoid.html#a984ca5eac6c17e7584a2ed343031f32a", null ],
    [ "MaxError", "classGeographicLib_1_1Geoid.html#a12668c63d8715a3ff2d9e4d9e8617f3b", null ],
    [ "RMSError", "classGeographicLib_1_1Geoid.html#a49507be2c8320885bea6db302b3f8721", null ],
    [ "Offset", "classGeographicLib_1_1Geoid.html#aac01a387af5a6fe17d74bedf63ac47dd", null ],
    [ "Scale", "classGeographicLib_1_1Geoid.html#a0060edb55887d0ab1bbd78ceda0e0c09", null ],
    [ "ThreadSafe", "classGeographicLib_1_1Geoid.html#ac0b6229c3d11300cfec7c93176e601b6", null ],
    [ "Cache", "classGeographicLib_1_1Geoid.html#a39d46978c54e60c61fd4d2151e008c05", null ],
    [ "CacheWest", "classGeographicLib_1_1Geoid.html#af5d1a448f4bd37d0300321c8125a495b", null ],
    [ "CacheEast", "classGeographicLib_1_1Geoid.html#a27da0e1d3f0bc09cab81af828fc842e2", null ],
    [ "CacheNorth", "classGeographicLib_1_1Geoid.html#aa0890021bb649965afd0d7f78d7f856f", null ],
    [ "CacheSouth", "classGeographicLib_1_1Geoid.html#a6338896cfa5970c6193bdde60c2379e0", null ],
    [ "EquatorialRadius", "classGeographicLib_1_1Geoid.html#a9360958e89bdeea69a9529be85e6f6e6", null ],
    [ "Flattening", "classGeographicLib_1_1Geoid.html#a45429da51799960f722cd5d18a47b544", null ],
    [ "DefaultGeoidPath", "classGeographicLib_1_1Geoid.html#a1ff180883abcea3c4c4cc111af1d5240", null ],
    [ "DefaultGeoidName", "classGeographicLib_1_1Geoid.html#aa61b4b6cf9cde6ca1f39d92e6a87593c", null ]
];