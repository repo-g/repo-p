var dir_d28a4824dc47e487b107a5db32ef43c4 =
[
    [ "AuxLatitude.cpp", "AuxLatitude_8cpp.html", null ],
    [ "AuxLatitude.hpp", "AuxLatitude_8hpp.html", "AuxLatitude_8hpp" ],
    [ "JacobiConformal.hpp", "JacobiConformal_8hpp.html", "JacobiConformal_8hpp" ]
];