var PolygonArea_8hpp =
[
    [ "GeographicLib::PolygonAreaT< GeodType >", "classGeographicLib_1_1PolygonAreaT.html", "classGeographicLib_1_1PolygonAreaT" ]
];