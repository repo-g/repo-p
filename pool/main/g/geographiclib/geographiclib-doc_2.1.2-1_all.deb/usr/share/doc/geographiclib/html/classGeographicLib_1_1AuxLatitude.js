var classGeographicLib_1_1AuxLatitude =
[
    [ "real", "classGeographicLib_1_1AuxLatitude.html#a2d9c6ac56af235bd9bdc1c5eb57dccd3", null ],
    [ "angle", "classGeographicLib_1_1AuxLatitude.html#a8bab705210ee282fca7ba01fc9d22a07", null ],
    [ "aux", "classGeographicLib_1_1AuxLatitude.html#a25c23c25ce2a9ed3621c2b49fa8ecb7c", [
      [ "GEOGRAPHIC", "classGeographicLib_1_1AuxLatitude.html#a25c23c25ce2a9ed3621c2b49fa8ecb7caca1940ebdd1587e261a107e9a8c55532", null ],
      [ "PARAMETRIC", "classGeographicLib_1_1AuxLatitude.html#a25c23c25ce2a9ed3621c2b49fa8ecb7ca824c78e0c87a146f9a343c784d629d73", null ],
      [ "GEOCENTRIC", "classGeographicLib_1_1AuxLatitude.html#a25c23c25ce2a9ed3621c2b49fa8ecb7ca2de7b909c90e6201cce58a3c51e14e7d", null ],
      [ "RECTIFYING", "classGeographicLib_1_1AuxLatitude.html#a25c23c25ce2a9ed3621c2b49fa8ecb7ca2352294345fde877b83aad09ec32783f", null ],
      [ "CONFORMAL", "classGeographicLib_1_1AuxLatitude.html#a25c23c25ce2a9ed3621c2b49fa8ecb7cae28954aed8b00556207f0c1c93b500df", null ],
      [ "AUTHALIC", "classGeographicLib_1_1AuxLatitude.html#a25c23c25ce2a9ed3621c2b49fa8ecb7ca0a634753392a71b74b567967c71e97bf", null ],
      [ "AUXNUMBER", "classGeographicLib_1_1AuxLatitude.html#a25c23c25ce2a9ed3621c2b49fa8ecb7ca4a303441c343e28f2fe91cc1d0cf9535", null ],
      [ "COMMON", "classGeographicLib_1_1AuxLatitude.html#a25c23c25ce2a9ed3621c2b49fa8ecb7ca360d3da26eccefaa7d867cb1898e960c", null ],
      [ "GEODETIC", "classGeographicLib_1_1AuxLatitude.html#a25c23c25ce2a9ed3621c2b49fa8ecb7ca963cabef372fea1befdf595753c652e6", null ],
      [ "REDUCED", "classGeographicLib_1_1AuxLatitude.html#a25c23c25ce2a9ed3621c2b49fa8ecb7cabf9d02c02d678a67f0c01ed6fc94a6ee", null ]
    ] ],
    [ "AuxLatitude", "classGeographicLib_1_1AuxLatitude.html#a9b829f45fe299c84a4d4a34c23c83cb9", null ],
    [ "AuxLatitude", "classGeographicLib_1_1AuxLatitude.html#a7844441fc2b25c8d6626434d3e98a1fb", null ],
    [ "Convert", "classGeographicLib_1_1AuxLatitude.html#afe4c9be30bb05a1a96cb8fd192aa0985", null ],
    [ "ToAuxiliary", "classGeographicLib_1_1AuxLatitude.html#a8248c14941196a8c3a37172c77d35265", null ],
    [ "FromAuxiliary", "classGeographicLib_1_1AuxLatitude.html#a695ed88d8f76aa978f8a0983a78673c0", null ],
    [ "Flattening", "classGeographicLib_1_1AuxLatitude.html#a1d501325e637ac828ab5c87fdd2aceac", null ],
    [ "Lmax", "classGeographicLib_1_1AuxLatitude.html#ad02c83f712de2641b9ecbaf04640bb67", null ]
];