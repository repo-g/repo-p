var MagneticCircle_8hpp =
[
    [ "GeographicLib::MagneticCircle", "classGeographicLib_1_1MagneticCircle.html", "classGeographicLib_1_1MagneticCircle" ]
];