var NearestNeighbor_8hpp =
[
    [ "GeographicLib::NearestNeighbor< dist_t, pos_t, distfun_t >", "classGeographicLib_1_1NearestNeighbor.html", "classGeographicLib_1_1NearestNeighbor" ],
    [ "swap", "NearestNeighbor_8hpp.html#a737df319ce79fda0ba311bb8d437ad85", null ]
];