var classGeographicLib_1_1MagneticCircle =
[
    [ "MagneticCircle", "classGeographicLib_1_1MagneticCircle.html#a49170460b1833722ad9bc45b92c86e5a", null ],
    [ "operator()", "classGeographicLib_1_1MagneticCircle.html#a6d420a65e151a89712f48201b7322511", null ],
    [ "operator()", "classGeographicLib_1_1MagneticCircle.html#ab13c4b5702337cfceb07dfa4a047f9cb", null ],
    [ "FieldGeocentric", "classGeographicLib_1_1MagneticCircle.html#a6473d41abc8abd36063b49b72468030a", null ],
    [ "Init", "classGeographicLib_1_1MagneticCircle.html#a83ebc788f3ecec38ba0baa67551bd109", null ],
    [ "EquatorialRadius", "classGeographicLib_1_1MagneticCircle.html#a96ba1a7407d19e20d66629785f7c639a", null ],
    [ "Flattening", "classGeographicLib_1_1MagneticCircle.html#a1e7b507bef88707f6ef30b3adcabd426", null ],
    [ "Latitude", "classGeographicLib_1_1MagneticCircle.html#a98fcd53e6391e355fc0a0cfe82ca1802", null ],
    [ "Height", "classGeographicLib_1_1MagneticCircle.html#a96ff224c1df56776055f9615968bf7e7", null ],
    [ "Time", "classGeographicLib_1_1MagneticCircle.html#a042b2f2b6a3699b33a4ed7b342de6c38", null ],
    [ "MagneticModel", "classGeographicLib_1_1MagneticCircle.html#af6619ebe4c078705fc49a0d9f950b431", null ]
];