var classGeographicLib_1_1SphericalEngine =
[
    [ "coeff", "classGeographicLib_1_1SphericalEngine_1_1coeff.html", "classGeographicLib_1_1SphericalEngine_1_1coeff" ],
    [ "normalization", "classGeographicLib_1_1SphericalEngine.html#a5332d09191e018cbddc568c1fc71949f", [
      [ "FULL", "classGeographicLib_1_1SphericalEngine.html#a5332d09191e018cbddc568c1fc71949fac720ca87adfc478dbfc13a37f0cf8ba9", null ],
      [ "SCHMIDT", "classGeographicLib_1_1SphericalEngine.html#a5332d09191e018cbddc568c1fc71949fa2e3db3efd68d118e3f357a97eb77a131", null ]
    ] ],
    [ "Value", "classGeographicLib_1_1SphericalEngine.html#a1157f59596dd15bf0a21b6a7fb99630b", null ],
    [ "Circle", "classGeographicLib_1_1SphericalEngine.html#af6a5fa63535d47cf528b733bb6a97901", null ],
    [ "RootTable", "classGeographicLib_1_1SphericalEngine.html#a7fac63262c0a8bb18aee8c962a08d429", null ],
    [ "ClearRootTable", "classGeographicLib_1_1SphericalEngine.html#ab3fb8f933adb257df6b7537268d55a75", null ],
    [ "CircularEngine", "classGeographicLib_1_1SphericalEngine.html#a0c689dbf7b6bf2fb4cffb109085b1d3b", null ]
];