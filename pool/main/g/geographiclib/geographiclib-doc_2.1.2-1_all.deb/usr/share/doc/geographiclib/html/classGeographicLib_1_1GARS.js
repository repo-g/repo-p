var classGeographicLib_1_1GARS =
[
    [ "Forward", "classGeographicLib_1_1GARS.html#a893a9175209082955218b85e0b7f60c4", null ],
    [ "Reverse", "classGeographicLib_1_1GARS.html#a0d0598d43a46e1237a26345ab984cf53", null ],
    [ "Resolution", "classGeographicLib_1_1GARS.html#a51615a93c7664dbd83a826ae1184702e", null ],
    [ "Precision", "classGeographicLib_1_1GARS.html#a5e21af28adcbc732e5f6b3f55b714ace", null ]
];