var classGeographicLib_1_1DST =
[
    [ "DST", "classGeographicLib_1_1DST.html#a4723e950777e1a94eb03f78e2f98df17", null ],
    [ "reset", "classGeographicLib_1_1DST.html#a0c25a572bd42d5a683c388b70b3d2e3c", null ],
    [ "N", "classGeographicLib_1_1DST.html#aaff7b28ff98c78b1d9578c852fe43016", null ],
    [ "transform", "classGeographicLib_1_1DST.html#a348fa07171f895b6197d6a24e30645b1", null ],
    [ "refine", "classGeographicLib_1_1DST.html#acaaf0c73d4c492efd7a3105eeb416173", null ],
    [ "eval", "classGeographicLib_1_1DST.html#a579e8f012bf2abb7ae219ecd60e8989a", null ],
    [ "integral", "classGeographicLib_1_1DST.html#ae8105df090da8036535d1de61b3e08a8", null ],
    [ "integral", "classGeographicLib_1_1DST.html#a9e6acb779cc5a8bcb1feeb68a546cf8c", null ]
];