var MagneticModel_8cpp =
[
    [ "GEOGRAPHICLIB_DATA", "MagneticModel_8cpp.html#a45687ef771d809c1c369daea074cc109", null ],
    [ "GEOGRAPHICLIB_MAGNETIC_DEFAULT_NAME", "MagneticModel_8cpp.html#afa2356a6826501e3b6c6037fb9012b02", null ]
];