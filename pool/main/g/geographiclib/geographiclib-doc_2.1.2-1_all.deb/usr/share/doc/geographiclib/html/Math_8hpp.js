var Math_8hpp =
[
    [ "GeographicLib::Math", "classGeographicLib_1_1Math.html", "classGeographicLib_1_1Math" ],
    [ "GEOGRAPHICLIB_WORDS_BIGENDIAN", "Math_8hpp.html#a2a4e5f86d0c84b647e1bc7783cfa0d8d", null ],
    [ "GEOGRAPHICLIB_HAVE_LONG_DOUBLE", "Math_8hpp.html#a8db7330869775b17ca84845f1ecaba6e", null ],
    [ "GEOGRAPHICLIB_PRECISION", "Math_8hpp.html#afb94d2448fd85c3c76929fff394303b0", null ],
    [ "GEOGRAPHICLIB_VOLATILE", "Math_8hpp.html#a953299c4d680cef5bc84752abfd31e5c", null ],
    [ "GEOGRAPHICLIB_PANIC", "Math_8hpp.html#ae0b3e43f19badf1bbf60e4a3c7c193f4", null ]
];