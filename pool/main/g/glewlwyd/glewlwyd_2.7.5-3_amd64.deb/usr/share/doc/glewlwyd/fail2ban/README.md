# Fail2ban filter

Read [Fail2ban filter](../INSTALL.md#fail2ban-filter) documentation for more information.
