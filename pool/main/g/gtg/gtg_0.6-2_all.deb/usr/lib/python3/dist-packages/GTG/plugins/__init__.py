"""Optional plug-ins for GTG"""
