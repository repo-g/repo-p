from GTG.plugins.gamify.gamify import Gamify
assert Gamify
