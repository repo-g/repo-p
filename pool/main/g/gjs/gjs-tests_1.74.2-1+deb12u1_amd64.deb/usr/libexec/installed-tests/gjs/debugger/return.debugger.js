// SPDX-License-Identifier: MIT OR LGPL-2.0-or-later
// SPDX-FileCopyrightText: 2018 Philip Chimento <philip.chimento@gmail.com>
function func1() {
    return 1;
}

function func2() {
    return 2;
}

function func3() {
    return 3;
}

print(func1());
print(func2());
print(func3());
