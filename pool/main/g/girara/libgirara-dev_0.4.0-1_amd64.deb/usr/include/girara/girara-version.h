/* SPDX-License-Identifier: Zlib */

#ifndef GIRARA_VERSION_H
#define GIRARA_VERSION_H

#define GIRARA_VERSION_MAJOR 0
#define GIRARA_VERSION_MINOR 4
#define GIRARA_VERSION_REV 0
#define GIRARA_VERSION "0.4.0"

#endif
