var searchData=
[
  ['read_0',['read',['../structgirara__input__history__io__interface__s.html#a30a3f034c607c5f8ad7cd6240e024127',1,'girara_input_history_io_interface_s']]],
  ['reserved1_1',['reserved1',['../structgirara__input__history__io__interface__s.html#a7426e62ca7626caa020752bbe681be17',1,'girara_input_history_io_interface_s::reserved1()'],['../structgirara__input__history__class__s.html#a484c45917d877e87a86539cb47ffabc8',1,'girara_input_history_class_s::reserved1()']]],
  ['reserved2_2',['reserved2',['../structgirara__input__history__io__interface__s.html#ae18abf3f7c17f39140af79211e252fd9',1,'girara_input_history_io_interface_s::reserved2()'],['../structgirara__input__history__class__s.html#af6f8705522ba25f6171db27df2b1b175',1,'girara_input_history_class_s::reserved2()']]],
  ['reserved3_3',['reserved3',['../structgirara__input__history__io__interface__s.html#aa319013ee42fa0005497dec436502dd6',1,'girara_input_history_io_interface_s::reserved3()'],['../structgirara__input__history__class__s.html#ad87563a0dc0ef7c6cb24b509cc8961fa',1,'girara_input_history_class_s::reserved3()']]],
  ['reserved4_4',['reserved4',['../structgirara__input__history__io__interface__s.html#a898e57d1865dd156ac2f6c4d3cc83642',1,'girara_input_history_io_interface_s::reserved4()'],['../structgirara__input__history__class__s.html#abbbd0181d800c27b1cf17753bd2c0c18',1,'girara_input_history_class_s::reserved4()']]],
  ['reset_5',['reset',['../structgirara__input__history__class__s.html#a5bcd9d186be84c1e6a1d20fce154cd2d',1,'girara_input_history_class_s']]],
  ['results_6',['results',['../structgirara__session__s.html#af38749283bfc60b95e029a2061f959ef',1,'girara_session_s']]]
];
