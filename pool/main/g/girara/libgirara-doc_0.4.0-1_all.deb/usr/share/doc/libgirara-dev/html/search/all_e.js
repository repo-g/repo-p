var searchData=
[
  ['overlay_0',['overlay',['../structgirara__session__private__s.html#a72d9196c25fb1e06c27cae63c67f8f41',1,'girara_session_private_s']]]
];
