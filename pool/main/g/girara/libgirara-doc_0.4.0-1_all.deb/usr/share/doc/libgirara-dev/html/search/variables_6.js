var searchData=
[
  ['girara_5fvisible_0',['GIRARA_VISIBLE',['../log_8h.html#aae4a315268e990af168dedea0fc343db',1,'GIRARA_VISIBLE():&#160;log.h'],['../session_8h.html#aae4a315268e990af168dedea0fc343db',1,'GIRARA_VISIBLE():&#160;session.h']]],
  ['global_1',['global',['../structgirara__session__s.html#aeaf463bb011addbd5a789b7beb211ee4',1,'girara_session_s']]],
  ['gtk_2',['gtk',['../structgirara__session__private__s.html#ad11a412deb6fe30fe9305aeb0621b010',1,'girara_session_private_s::gtk()'],['../structgirara__session__s.html#ae1b2ec31516ab9f040fd5a7f2ada2145',1,'girara_session_s::gtk()']]]
];
