var searchData=
[
  ['session_5fname_0',['session_name',['../structgirara__session__private__s.html#ab66f8a0ccf93d505717c7f9b84c37177',1,'girara_session_private_s']]],
  ['settings_1',['settings',['../structgirara__session__private__s.html#ac439526205e2729cb3708ed832865270',1,'girara_session_private_s']]],
  ['shortcut_5fmappings_2',['shortcut_mappings',['../structgirara__session__private__s.html#ac3b8fce9e58536d6f0a37766d89a3855',1,'girara_session_private_s']]],
  ['shortcuts_3',['shortcuts',['../structgirara__session__s.html#a09cae02b74ac52fa9879d5cd3cb06392',1,'girara_session_s']]],
  ['signals_4',['signals',['../structgirara__session__s.html#ac9ccfe9319b3fa981aa04a96e76ff54d',1,'girara_session_s']]],
  ['special_5fcommands_5',['special_commands',['../structgirara__session__s.html#a451e4a20599f11f28150fd8ad850dc38',1,'girara_session_s']]],
  ['statusbar_6',['statusbar',['../structgirara__session__s.html#abc109fa208001af214fba6ba0d3baad2',1,'girara_session_s']]],
  ['statusbar_5fentries_7',['statusbar_entries',['../structgirara__session__s.html#a17098418d9bd9c9b272d02aef5f676bf',1,'girara_session_s']]],
  ['statusbar_5fitems_8',['statusbar_items',['../structgirara__session__private__s.html#ac654af9342064f8b63e4f79e4a0864eb',1,'girara_session_private_s']]]
];
