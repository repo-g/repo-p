var searchData=
[
  ['format_5fcommand_0',['FORMAT_COMMAND',['../internal_8h.html#ae6427b6f47f186387a5407c10a670fa5',1,'internal.h']]],
  ['format_5fdescription_1',['FORMAT_DESCRIPTION',['../internal_8h.html#aeb8d80c6d5db2bb93976f13e66677fb9',1,'internal.h']]]
];
