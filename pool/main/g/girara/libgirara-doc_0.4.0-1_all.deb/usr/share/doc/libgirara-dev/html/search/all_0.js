var searchData=
[
  ['_5f_5fhas_5fattribute_0',['__has_attribute',['../macros_8h.html#a54d2d7742701f3f112afbcd8d4f9ccdb',1,'macros.h']]],
  ['_5f_5fhas_5fbuiltin_1',['__has_builtin',['../macros_8h.html#a447121dcab4275b7839a56082b7a1ab8',1,'macros.h']]]
];
