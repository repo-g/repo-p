var searchData=
[
  ['session_2eh_0',['session.h',['../session_8h.html',1,'']]],
  ['settings_2eh_1',['settings.h',['../settings_8h.html',1,'']]],
  ['shortcuts_2eh_2',['shortcuts.h',['../shortcuts_8h.html',1,'']]],
  ['statusbar_2eh_3',['statusbar.h',['../statusbar_8h.html',1,'']]]
];
