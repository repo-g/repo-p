var searchData=
[
  ['template_2eh_0',['template.h',['../template_8h.html',1,'']]],
  ['text_1',['text',['../structgirara__statusbar__item__s.html#a7420e3093a3f38c930067170dd8bf2e1',1,'girara_statusbar_item_s']]],
  ['type_2',['type',['../structgirara__event__s.html#a9d4a53d7cacf408f11cc7bfa82a0adf7',1,'girara_event_s']]],
  ['types_2eh_3',['types.h',['../types_8h.html',1,'']]]
];
