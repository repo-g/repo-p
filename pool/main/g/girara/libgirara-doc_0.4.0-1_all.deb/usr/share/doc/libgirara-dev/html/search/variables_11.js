var searchData=
[
  ['text_0',['text',['../structgirara__statusbar__item__s.html#a7420e3093a3f38c930067170dd8bf2e1',1,'girara_statusbar_item_s']]],
  ['type_1',['type',['../structgirara__event__s.html#a9d4a53d7cacf408f11cc7bfa82a0adf7',1,'girara_event_s']]]
];
