var searchData=
[
  ['data_0',['data',['../structgirara__session__s.html#a4e12667d293f67bd5c00594fdf764a1e',1,'girara_session_s::data()'],['../structgirara__argument__s.html#ac77594bedc20c15741359b20fed22b69',1,'girara_argument_s::data()']]],
  ['datastructures_2eh_1',['datastructures.h',['../datastructures_8h.html',1,'']]],
  ['description_2',['description',['../structgirara__command__s.html#a3798e77cb108b0c69f97d64981bccaf3',1,'girara_command_s']]]
];
