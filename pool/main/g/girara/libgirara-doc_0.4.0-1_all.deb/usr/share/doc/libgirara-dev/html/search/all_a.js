var searchData=
[
  ['key_0',['key',['../structgirara__shortcut__s.html#ad992cbaee8f76bef99ff9aa62857bc72',1,'girara_shortcut_s::key()'],['../structgirara__inputbar__shortcut__s.html#a728c9d1fee6f663d6a35318bf162b39f',1,'girara_inputbar_shortcut_s::key()']]]
];
