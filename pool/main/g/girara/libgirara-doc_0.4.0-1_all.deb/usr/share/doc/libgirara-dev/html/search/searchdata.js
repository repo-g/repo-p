var indexSectionsWithContent =
{
  0: "_abcdefghiklmnoprstuvwxy",
  1: "g",
  2: "cdegilmstu",
  3: "cglsw",
  4: "abcdefghiklmnoprstuvwxy",
  5: "gw",
  6: "g",
  7: "bfgisux",
  8: "_fghlu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros"
};

