var searchData=
[
  ['string_0',['STRING',['../types_8h.html#afb6c7b777b0affc9804cb569debdd969aee847e634a4297b274316de8a8ca9921',1,'types.h']]]
];
