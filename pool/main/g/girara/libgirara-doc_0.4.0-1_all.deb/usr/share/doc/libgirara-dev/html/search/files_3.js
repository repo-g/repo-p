var searchData=
[
  ['girara_2dversion_2eh_0',['girara-version.h',['../girara-version_8h.html',1,'']]],
  ['girara_2eh_1',['girara.h',['../girara_8h.html',1,'']]]
];
