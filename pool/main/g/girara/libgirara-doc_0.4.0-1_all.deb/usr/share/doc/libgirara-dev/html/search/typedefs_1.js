var searchData=
[
  ['window_0',['Window',['../session_8h.html#af01e7097ca1d0ac81857d505b94a6bae',1,'session.h']]]
];
