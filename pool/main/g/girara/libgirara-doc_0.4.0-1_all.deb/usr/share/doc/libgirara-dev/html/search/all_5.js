var searchData=
[
  ['elements_0',['elements',['../structgirara__session__private__s.html#af83808980baa6c9c0f6f1206e035a712',1,'girara_session_private_s']]],
  ['embed_1',['embed',['../structgirara__session__s.html#ab4daf0e107f2180f960a844bd35633d4',1,'girara_session_s']]],
  ['entry_2eh_2',['entry.h',['../entry_8h.html',1,'']]],
  ['event_5ftype_3',['event_type',['../structgirara__mouse__event__s.html#ada0ee9ebb563096451f881dec05ae95f',1,'girara_mouse_event_s']]],
  ['events_4',['events',['../structgirara__session__s.html#ab51197c77f6d75c27afabf9b939bd240',1,'girara_session_s']]]
];
