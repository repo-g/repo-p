var searchData=
[
  ['widget_5fadd_5fclass_0',['widget_add_class',['../internal_8h.html#abdec81d9c3db3225cef102541a11d1d9',1,'internal.h']]],
  ['widget_5fremove_5fclass_1',['widget_remove_class',['../internal_8h.html#ab6ed187af804e16df7e53c8bc53de60c',1,'internal.h']]]
];
