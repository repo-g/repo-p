var searchData=
[
  ['window_0',['window',['../structgirara__session__s.html#a66b2ce8c819f723b542ebb4835c86f58',1,'girara_session_s']]]
];
