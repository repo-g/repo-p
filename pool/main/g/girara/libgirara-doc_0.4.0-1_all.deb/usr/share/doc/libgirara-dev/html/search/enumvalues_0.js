var searchData=
[
  ['boolean_0',['BOOLEAN',['../types_8h.html#afb6c7b777b0affc9804cb569debdd969a8a583f16e8d237a423c8c1d9087a4c72',1,'types.h']]]
];
