var searchData=
[
  ['n_0',['n',['../structgirara__session__private__s.html#a791483d688587116824b144da4392e84',1,'girara_session_private_s::n()'],['../structgirara__argument__s.html#a5535fbff0052df18ef903aad04551c94',1,'girara_argument_s::n()']]],
  ['name_1',['name',['../structgirara__mode__string__s.html#a83d4eba27ad3cf66cd8a3276729f1b91',1,'girara_mode_string_s']]],
  ['next_2',['next',['../structgirara__input__history__class__s.html#ac623910d8d47f3c47156860f2dd69868',1,'girara_input_history_class_s']]],
  ['normal_3',['normal',['../structgirara__session__s.html#a50a0a73a6ccc5d41201597d41c1dc1e3',1,'girara_session_s']]],
  ['notification_5farea_4',['notification_area',['../structgirara__session__s.html#a5a2c2379a0304ccdabf9333b0a96ba9a',1,'girara_session_s']]],
  ['notification_5ftext_5',['notification_text',['../structgirara__session__s.html#aee11eac2d67f83a37c9e2b646373ff02',1,'girara_session_s']]]
];
