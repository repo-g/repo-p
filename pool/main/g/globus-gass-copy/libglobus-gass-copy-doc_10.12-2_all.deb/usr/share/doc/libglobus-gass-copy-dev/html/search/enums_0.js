var searchData=
[
  ['globus_5fgass_5fcopy_5fglob_5fentry_5ft_136',['globus_gass_copy_glob_entry_t',['../group__globus__gass__copy.html#ga36dbf746822bd9d5d5f8a4f57e6e5fab',1,'globus_gass_copy.h']]],
  ['globus_5fgass_5fcopy_5fstatus_5ft_137',['globus_gass_copy_status_t',['../group__globus__gass__copy.html#gadc5d1cc2cfb4b55c1d65c161c258c289',1,'globus_gass_copy.h']]],
  ['globus_5fgass_5fcopy_5furl_5fmode_5ft_138',['globus_gass_copy_url_mode_t',['../group__globus__gass__copy.html#ga0c40e6169cbec2c997698000d24da2ab',1,'globus_gass_copy.h']]]
];
