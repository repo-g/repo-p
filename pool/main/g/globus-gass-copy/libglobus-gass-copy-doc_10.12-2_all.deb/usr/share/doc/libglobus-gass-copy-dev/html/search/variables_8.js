var searchData=
[
  ['send_5fallo_121',['send_allo',['../structglobus__gass__copy__handle__s.html#ab3ce172b29dc21b7d25d0c3ecc9df323',1,'globus_gass_copy_handle_s']]],
  ['size_122',['size',['../structglobus__gass__copy__glob__stat__t.html#a2b1fe264bdbf14d2a7f13a6955de757e',1,'globus_gass_copy_glob_stat_t']]],
  ['state_123',['state',['../structglobus__gass__copy__handle__s.html#ac39925a0dcfb48deb1414994c70946d6',1,'globus_gass_copy_handle_s']]],
  ['status_124',['status',['../structglobus__gass__copy__handle__s.html#ad0b777ecdd8f1de4bd64204a9bcef29b',1,'globus_gass_copy_handle_s']]],
  ['symlink_5ftarget_125',['symlink_target',['../structglobus__gass__copy__glob__stat__t.html#adf38b8152cb505c1cdfb718aa5df29c8',1,'globus_gass_copy_glob_stat_t']]]
];
