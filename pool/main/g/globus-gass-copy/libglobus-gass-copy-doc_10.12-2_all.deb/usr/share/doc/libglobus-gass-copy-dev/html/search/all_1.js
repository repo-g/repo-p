var searchData=
[
  ['buffer_5flength_1',['buffer_length',['../structglobus__gass__copy__handle__s.html#ab2fd9d5a57d3ebbe1a9e685dcdf48b70',1,'globus_gass_copy_handle_s']]]
];
