var searchData=
[
  ['globus_5fgass_5fcopy_5fattr_5fs_71',['globus_gass_copy_attr_s',['../structglobus__gass__copy__attr__s.html',1,'']]],
  ['globus_5fgass_5fcopy_5fglob_5fstat_5ft_72',['globus_gass_copy_glob_stat_t',['../structglobus__gass__copy__glob__stat__t.html',1,'']]],
  ['globus_5fgass_5fcopy_5fhandle_5fs_73',['globus_gass_copy_handle_s',['../structglobus__gass__copy__handle__s.html',1,'']]],
  ['globus_5fgass_5fcopy_5fhandleattr_5fs_74',['globus_gass_copy_handleattr_s',['../structglobus__gass__copy__handleattr__s.html',1,'']]]
];
