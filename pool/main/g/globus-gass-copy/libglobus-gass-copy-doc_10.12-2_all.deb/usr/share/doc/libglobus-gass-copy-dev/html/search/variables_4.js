var searchData=
[
  ['ftp_5fhandle_5f2_115',['ftp_handle_2',['../structglobus__gass__copy__handle__s.html#a12d6deae83715330ff956f6cb505ea59',1,'globus_gass_copy_handle_s']]]
];
