var searchData=
[
  ['unique_5fid_127',['unique_id',['../structglobus__gass__copy__glob__stat__t.html#af72a5a9a05412d15010b37e481004611',1,'globus_gass_copy_glob_stat_t']]],
  ['user_5fcallback_128',['user_callback',['../structglobus__gass__copy__handle__s.html#a3b8ba9543e7421d7fee78704776504a3',1,'globus_gass_copy_handle_s']]],
  ['user_5fcancel_5fcallback_129',['user_cancel_callback',['../structglobus__gass__copy__handle__s.html#ae2a8fb5d8e32a5bd9221543a76ac3a23',1,'globus_gass_copy_handle_s']]],
  ['user_5fpointer_130',['user_pointer',['../structglobus__gass__copy__handle__s.html#ad063a9648245b5a8a05eec0be4bec4ee',1,'globus_gass_copy_handle_s']]]
];
