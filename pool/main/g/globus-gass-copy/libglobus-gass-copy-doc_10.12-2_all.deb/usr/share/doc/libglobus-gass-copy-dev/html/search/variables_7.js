var searchData=
[
  ['partial_5foffset_119',['partial_offset',['../structglobus__gass__copy__handle__s.html#a6e75ec92622d4c3252799fab121336b7',1,'globus_gass_copy_handle_s']]],
  ['performance_120',['performance',['../structglobus__gass__copy__handle__s.html#a9119a65859cf1c9173d6d479e38284be',1,'globus_gass_copy_handle_s']]]
];
