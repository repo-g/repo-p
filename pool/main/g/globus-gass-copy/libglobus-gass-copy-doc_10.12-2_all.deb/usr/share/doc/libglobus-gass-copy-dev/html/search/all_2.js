var searchData=
[
  ['callback_5farg_2',['callback_arg',['../structglobus__gass__copy__handle__s.html#a436b00f8fb957695bc579ba08164de15',1,'globus_gass_copy_handle_s']]],
  ['cancel_5fcallback_5farg_3',['cancel_callback_arg',['../structglobus__gass__copy__handle__s.html#af2d2e5ee513b8c18f664a2772d26fc32',1,'globus_gass_copy_handle_s']]]
];
