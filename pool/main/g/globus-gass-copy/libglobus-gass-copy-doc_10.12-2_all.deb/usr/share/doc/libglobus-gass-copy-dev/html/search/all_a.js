var searchData=
[
  ['type_66',['type',['../structglobus__gass__copy__glob__stat__t.html#aaf1a81218b225ac2a71a51138d7b919f',1,'globus_gass_copy_glob_stat_t']]]
];
