var searchData=
[
  ['no_5fthird_5fparty_5ftransfers_58',['no_third_party_transfers',['../structglobus__gass__copy__handle__s.html#a90efd782f6168f5b2ba027ce5eb75287',1,'globus_gass_copy_handle_s']]]
];
