var searchData=
[
  ['globus_5fgass_5fcopy_5fattr_5ft_131',['globus_gass_copy_attr_t',['../group__globus__gass__copy.html#ga76a1ef1d796ae39e7c93fc95c20d73f9',1,'globus_gass_copy.h']]],
  ['globus_5fgass_5fcopy_5fcallback_5ft_132',['globus_gass_copy_callback_t',['../group__globus__gass__copy.html#ga7a931b8eb85933f49b1a340561f089e7',1,'globus_gass_copy.h']]],
  ['globus_5fgass_5fcopy_5fglob_5fentry_5fcb_5ft_133',['globus_gass_copy_glob_entry_cb_t',['../group__globus__gass__copy.html#ga20f88e5b5f6d4d4cddae6cc8269ac7a8',1,'globus_gass_copy.h']]],
  ['globus_5fgass_5fcopy_5fhandleattr_5ft_134',['globus_gass_copy_handleattr_t',['../group__globus__gass__copy.html#ga0121a2138d5bb1bf03a82a56c1de5713',1,'globus_gass_copy.h']]],
  ['globus_5fgass_5fcopy_5fperformance_5fcb_5ft_135',['globus_gass_copy_performance_cb_t',['../group__globus__gass__copy.html#ga2644fce179a3b66d0f8bc237b94115c6',1,'globus_gass_copy.h']]]
];
