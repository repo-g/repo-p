#warning GSXibLoading.h is now included using the path <GNUstepGUI/GSXibLoading.h>
#include <GNUstepGUI/GSXibLoading.h>
