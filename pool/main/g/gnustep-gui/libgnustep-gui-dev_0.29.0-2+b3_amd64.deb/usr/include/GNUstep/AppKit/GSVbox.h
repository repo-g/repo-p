#warning GSVbox.h is now included using the path <GNUstepGUI/GSVbox.h>
#include <GNUstepGUI/GSVbox.h>
