#warning GSHbox.h is now included using the path <GNUstepGUI/GSHbox.h>
#include <GNUstepGUI/GSHbox.h>
