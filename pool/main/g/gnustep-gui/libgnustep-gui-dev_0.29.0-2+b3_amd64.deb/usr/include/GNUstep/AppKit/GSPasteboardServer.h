#warning GSPasteboardServer.h is now included using the path <GNUstepGUI/GSPasteboardServer.h>
#include <GNUstepGUI/GSPasteboardServer.h>
