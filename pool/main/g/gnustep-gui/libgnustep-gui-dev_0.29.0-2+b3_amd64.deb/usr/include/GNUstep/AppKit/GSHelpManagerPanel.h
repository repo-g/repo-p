#warning GSHelpManagerPanel.h is now included using the path <GNUstepGUI/GSHelpManagerPanel.h>
#include <GNUstepGUI/GSHelpManagerPanel.h>
