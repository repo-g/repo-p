#warning GSToolbarView.h is now included using the path <GNUstepGUI/GSToolbarView.h>
#include <GNUstepGUI/GSToolbarView.h>
