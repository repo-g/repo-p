#warning GSMemoryPanel.h is now included using the path <GNUstepGUI/GSMemoryPanel.h>
#include <GNUstepGUI/GSMemoryPanel.h>
