#warning GSVersion.h is now included using the path <GNUstepGUI/GSVersion.h>
#include <GNUstepGUI/GSVersion.h>
