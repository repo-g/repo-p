#warning GSHorizontalTypesetter.h is now included using the path <GNUstepGUI/GSHorizontalTypesetter.h>
#include <GNUstepGUI/GSHorizontalTypesetter.h>
