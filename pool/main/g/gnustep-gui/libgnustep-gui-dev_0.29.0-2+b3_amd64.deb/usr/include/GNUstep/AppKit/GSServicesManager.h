#warning GSServicesManager.h is now included using the path <GNUstepGUI/GSServicesManager.h>
#include <GNUstepGUI/GSServicesManager.h>
