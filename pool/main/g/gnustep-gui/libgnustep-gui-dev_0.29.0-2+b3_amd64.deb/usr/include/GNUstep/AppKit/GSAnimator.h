#warning GSAnimator.h is now included using the path <GNUstepGUI/GSAnimator.h>
#include <GNUstepGUI/GSAnimator.h>
