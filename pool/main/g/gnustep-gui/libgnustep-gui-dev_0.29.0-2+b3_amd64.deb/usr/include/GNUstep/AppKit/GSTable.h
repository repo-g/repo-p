#warning GSTable.h is now included using the path <GNUstepGUI/GSTable.h>
#include <GNUstepGUI/GSTable.h>
