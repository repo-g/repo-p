#warning GSSoundSource.h is now included using the path <GNUstepGUI/GSSoundSource.h>
#include <GNUstepGUI/GSSoundSource.h>
