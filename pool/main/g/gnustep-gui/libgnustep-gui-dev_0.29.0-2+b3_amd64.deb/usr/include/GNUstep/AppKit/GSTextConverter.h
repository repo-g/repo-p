#warning GSTextConverter.h is now included using the path <GNUstepGUI/GSTextConverter.h>
#include <GNUstepGUI/GSTextConverter.h>
