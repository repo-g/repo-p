#warning GSInfoPanel.h is now included using the path <GNUstepGUI/GSInfoPanel.h>
#include <GNUstepGUI/GSInfoPanel.h>
