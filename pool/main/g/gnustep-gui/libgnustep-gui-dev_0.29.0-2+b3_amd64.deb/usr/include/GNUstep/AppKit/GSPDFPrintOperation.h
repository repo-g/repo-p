#warning GSPDFPrintOperation.h is now included using the path <GNUstepGUI/GSPDFPrintOperation.h>
#include <GNUstepGUI/GSPDFPrintOperation.h>
