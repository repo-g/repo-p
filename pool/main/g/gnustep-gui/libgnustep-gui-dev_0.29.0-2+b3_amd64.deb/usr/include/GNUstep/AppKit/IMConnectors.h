#warning IMConnectors.h is now included using the path <GNUstepGUI/IMConnectors.h>
#include <GNUstepGUI/IMConnectors.h>
