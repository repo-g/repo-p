#warning GSLayoutManager_internal.h is now included using the path <GNUstepGUI/GSLayoutManager_internal.h>
#include <GNUstepGUI/GSLayoutManager_internal.h>
