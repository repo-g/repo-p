#warning GMAppKit.h is now included using the path <GNUstepGUI/GMAppKit.h>
#include <GNUstepGUI/GMAppKit.h>
