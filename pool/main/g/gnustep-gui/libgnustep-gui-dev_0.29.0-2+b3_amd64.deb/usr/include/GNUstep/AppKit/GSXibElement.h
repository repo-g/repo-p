#warning GSXibElement.h is now included using the path <GNUstepGUI/GSXibElement.h>
#include <GNUstepGUI/GSXibElement.h>
