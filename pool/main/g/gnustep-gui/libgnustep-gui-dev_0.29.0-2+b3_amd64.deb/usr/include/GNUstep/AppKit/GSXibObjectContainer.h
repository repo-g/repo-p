#warning GSXibObjectContainer.h is now included using the path <GNUstepGUI/GSXibObjectContainer.h>
#include <GNUstepGUI/GSXibObjectContainer.h>
