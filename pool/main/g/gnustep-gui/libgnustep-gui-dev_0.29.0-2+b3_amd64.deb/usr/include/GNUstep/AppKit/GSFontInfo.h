#warning GSFontInfo.h is now included using the path <GNUstepGUI/GSFontInfo.h>
#include <GNUstepGUI/GSFontInfo.h>
