#warning GSSoundSink.h is now included using the path <GNUstepGUI/GSSoundSink.h>
#include <GNUstepGUI/GSSoundSink.h>
