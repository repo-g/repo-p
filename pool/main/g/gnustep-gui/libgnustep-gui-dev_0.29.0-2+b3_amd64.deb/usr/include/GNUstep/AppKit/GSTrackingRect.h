#warning GSTrackingRect.h is now included using the path <GNUstepGUI/GSTrackingRect.h>
#include <GNUstepGUI/GSTrackingRect.h>
