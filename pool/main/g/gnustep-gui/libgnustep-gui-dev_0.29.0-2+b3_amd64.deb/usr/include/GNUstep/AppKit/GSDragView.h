#warning GSDragView.h is now included using the path <GNUstepGUI/GSDragView.h>
#include <GNUstepGUI/GSDragView.h>
