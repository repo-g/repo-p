#warning IMCustomObject.h is now included using the path <GNUstepGUI/IMCustomObject.h>
#include <GNUstepGUI/IMCustomObject.h>
