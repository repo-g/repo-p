#warning GSWindowDecorationView.h is now included using the path <GNUstepGUI/GSWindowDecorationView.h>
#include <GNUstepGUI/GSWindowDecorationView.h>
