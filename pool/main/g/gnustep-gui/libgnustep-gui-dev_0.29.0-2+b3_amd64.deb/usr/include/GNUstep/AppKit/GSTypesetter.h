#warning GSTypesetter.h is now included using the path <GNUstepGUI/GSTypesetter.h>
#include <GNUstepGUI/GSTypesetter.h>
