#warning GSImageMagickImageRep.h is now included using the path <GNUstepGUI/GSImageMagickImageRep.h>
#include <GNUstepGUI/GSImageMagickImageRep.h>
