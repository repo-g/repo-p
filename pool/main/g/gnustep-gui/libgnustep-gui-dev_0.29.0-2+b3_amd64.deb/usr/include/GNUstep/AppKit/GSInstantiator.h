#warning GSInstantiator.h is now included using the path <GNUstepGUI/GSInstantiator.h>
#include <GNUstepGUI/GSInstantiator.h>
