#warning GSGormLoading.h is now included using the path <GNUstepGUI/GSGormLoading.h>
#include <GNUstepGUI/GSGormLoading.h>
