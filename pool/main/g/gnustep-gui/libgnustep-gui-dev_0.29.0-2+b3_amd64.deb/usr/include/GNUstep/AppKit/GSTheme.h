#warning GSTheme.h is now included using the path <GNUstepGUI/GSTheme.h>
#include <GNUstepGUI/GSTheme.h>
