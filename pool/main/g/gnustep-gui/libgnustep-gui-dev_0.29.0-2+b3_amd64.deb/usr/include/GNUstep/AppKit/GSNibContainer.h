#warning GSNibContainer.h is now included using the path <GNUstepGUI/GSNibContainer.h>
#include <GNUstepGUI/GSNibContainer.h>
