#warning GMArchiver.h is now included using the path <GNUstepGUI/GMArchiver.h>
#include <GNUstepGUI/GMArchiver.h>
