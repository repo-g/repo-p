#warning GSDisplayServer.h is now included using the path <GNUstepGUI/GSDisplayServer.h>
#include <GNUstepGUI/GSDisplayServer.h>
