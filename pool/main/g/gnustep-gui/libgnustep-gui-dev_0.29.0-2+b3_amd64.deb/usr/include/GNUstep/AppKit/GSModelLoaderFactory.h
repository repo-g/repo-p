#warning GSModelLoaderFactory.h is now included using the path <GNUstepGUI/GSModelLoaderFactory.h>
#include <GNUstepGUI/GSModelLoaderFactory.h>
