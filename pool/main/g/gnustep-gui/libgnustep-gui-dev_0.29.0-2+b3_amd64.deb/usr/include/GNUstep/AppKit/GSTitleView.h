#warning GSTitleView.h is now included using the path <GNUstepGUI/GSTitleView.h>
#include <GNUstepGUI/GSTitleView.h>
