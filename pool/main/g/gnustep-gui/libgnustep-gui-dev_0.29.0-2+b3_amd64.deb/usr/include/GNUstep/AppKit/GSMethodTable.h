#warning GSMethodTable.h is now included using the path <GNUstepGUI/GSMethodTable.h>
#include <GNUstepGUI/GSMethodTable.h>
