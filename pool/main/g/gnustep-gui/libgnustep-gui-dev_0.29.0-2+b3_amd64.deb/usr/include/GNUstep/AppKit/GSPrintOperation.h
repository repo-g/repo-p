#warning GSPrintOperation.h is now included using the path <GNUstepGUI/GSPrintOperation.h>
#include <GNUstepGUI/GSPrintOperation.h>
