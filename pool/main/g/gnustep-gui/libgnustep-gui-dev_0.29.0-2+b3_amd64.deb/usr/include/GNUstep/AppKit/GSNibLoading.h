#warning GSNibLoading.h is now included using the path <GNUstepGUI/GSNibLoading.h>
#include <GNUstepGUI/GSNibLoading.h>
