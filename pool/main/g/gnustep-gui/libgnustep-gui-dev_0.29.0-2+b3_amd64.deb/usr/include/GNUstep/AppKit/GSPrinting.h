#warning GSPrinting.h is now included using the path <GNUstepGUI/GSPrinting.h>
#include <GNUstepGUI/GSPrinting.h>
