#warning IMLoading.h is now included using the path <GNUstepGUI/IMLoading.h>
#include <GNUstepGUI/IMLoading.h>
