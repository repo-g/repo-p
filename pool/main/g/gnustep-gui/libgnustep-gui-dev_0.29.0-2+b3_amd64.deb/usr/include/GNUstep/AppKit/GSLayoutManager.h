#warning GSLayoutManager.h is now included using the path <GNUstepGUI/GSLayoutManager.h>
#include <GNUstepGUI/GSLayoutManager.h>
