#warning GSHelpAttachment.h is now included using the path <GNUstepGUI/GSHelpAttachment.h>
#include <GNUstepGUI/GSHelpAttachment.h>
