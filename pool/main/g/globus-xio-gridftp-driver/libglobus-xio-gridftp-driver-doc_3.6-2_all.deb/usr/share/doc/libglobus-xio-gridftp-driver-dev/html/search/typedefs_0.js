var searchData=
[
  ['globus_5fl_5fxio_5fgridftp_5fmode_5ft_44',['globus_l_xio_gridftp_mode_t',['../group__globus__xio__gridftp__driver.html#ga73b83602138402a2ac77a07b49053d05',1,'globus_xio_gridftp_driver.h']]]
];
