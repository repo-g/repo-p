/*
 * gwyconfig.h
 *
 * This is a generated file.  Please modify 'configure.ac'.
 */

#ifndef __GWY_CONFIG_H__
#define __GWY_CONFIG_H__

#define GWYDDION_HAS_OPENGL 1

#define GWY_SHARED_LIBRARY_EXTENSION "so"

/* Math functions become available when gwymathfallback.h is included. */
/* In 2.x also when gwymath.h is included. */

/* Define to 1 if you have the cbrt() function. */
#define GWY_HAVE_CBRT 1

/* Define to 1 if you have the exp10() function. */
#define GWY_HAVE_EXP10 1

/* Define to 1 if you have the hypot() function. */
#define GWY_HAVE_HYPOT 1

/* Define to 1 if you have the pow10() function. */
#undef GWY_HAVE_POW10

/* Define to 1 if you have the acosh() function. */
#define GWY_HAVE_ACOSH 1

/* Define to 1 if you have the asinh() function. */
#define GWY_HAVE_ASINH 1

/* Define to 1 if you have the atanh() function. */
#define GWY_HAVE_ATANH 1

/* Define to 1 if you have the isinf() function. */
#define GWY_HAVE_ISINF 1

/* Define to 1 if you have the isnan() function. */
#define GWY_HAVE_ISNAN 1

#endif /* __GWY_CONFIG_H__ */
