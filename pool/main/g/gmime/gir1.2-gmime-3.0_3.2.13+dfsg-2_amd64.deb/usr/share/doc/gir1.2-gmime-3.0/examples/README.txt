This directory contains example files of how to use GMime under
GObject Introspection in different languages.

If you want to suggest an example in another language, please submit
it to the debian BTS using:

   reportbug gir1.2-gmime-3.0

or mail it to:

  GMime Development Mailing List <gmime-devel-list@gnome.org>
