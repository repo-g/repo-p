var searchData=
[
  ['exif_5fmethods_0',['exif_methods',['../lua_8c.html#ae65388773267617954dbff00feb3c479',1,'lua.c']]]
];
