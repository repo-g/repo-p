var searchData=
[
  ['lua_2ec_0',['lua.c',['../lua_8c.html',1,'']]]
];
