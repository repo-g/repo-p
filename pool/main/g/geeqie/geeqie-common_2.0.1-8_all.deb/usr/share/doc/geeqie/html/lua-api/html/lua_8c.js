var lua_8c =
[
    [ "lua_exif_get_datum", "lua_8c.html#ac9ce283551bf63c8147cb780bff5d209", null ],
    [ "lua_image_get_date", "lua_8c.html#a44364b90fbb9ff09543f6fd0307f3a0a", null ],
    [ "lua_image_get_exif", "lua_8c.html#a085dc763b1a2fc6e8eeb4e0bb315268e", null ],
    [ "lua_image_get_extension", "lua_8c.html#a87e2f0caafe7c3b7c56d3956d9fcc7c1", null ],
    [ "lua_image_get_marks", "lua_8c.html#aa9c605d65074a310c050f036c8c8d4c8", null ],
    [ "lua_image_get_name", "lua_8c.html#a1890e1bdf4c29bd0ab64afc24188f1dd", null ],
    [ "lua_image_get_path", "lua_8c.html#a65ddfd7d38490cdb6d21d1d09408c253", null ],
    [ "lua_image_get_size", "lua_8c.html#a2299bcb5935a4c8f02c0e1c20e4e2ed9", null ],
    [ "exif_methods", "lua_8c.html#ae65388773267617954dbff00feb3c479", null ],
    [ "image_methods", "lua_8c.html#ac8629eaf0c7d181e68644c972af0c5c4", null ]
];