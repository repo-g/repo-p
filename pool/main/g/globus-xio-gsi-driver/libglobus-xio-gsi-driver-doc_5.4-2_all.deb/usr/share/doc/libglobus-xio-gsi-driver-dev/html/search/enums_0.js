var searchData=
[
  ['globus_5fxio_5fgsi_5fauthorization_5fmode_5ft_69',['globus_xio_gsi_authorization_mode_t',['../group__globus__xio__gsi__driver.html#ga77d64e17675e41e59cd7bd521be371ef',1,'globus_xio_gsi.h']]],
  ['globus_5fxio_5fgsi_5fcmd_5ft_70',['globus_xio_gsi_cmd_t',['../group__globus__xio__gsi__driver.html#ga914ae1745d5c6d2bf7c2a251adaa2b3a',1,'globus_xio_gsi.h']]],
  ['globus_5fxio_5fgsi_5fdelegation_5fmode_5ft_71',['globus_xio_gsi_delegation_mode_t',['../group__globus__xio__gsi__driver.html#ga557ecc80442ce687103a485729831db0',1,'globus_xio_gsi.h']]],
  ['globus_5fxio_5fgsi_5ferror_5ft_72',['globus_xio_gsi_error_t',['../group__globus__xio__gsi__driver.html#ga3d4c97e3dd438b97e25d19bd2cfd782c',1,'globus_xio_gsi.h']]],
  ['globus_5fxio_5fgsi_5fprotection_5flevel_5ft_73',['globus_xio_gsi_protection_level_t',['../group__globus__xio__gsi__driver.html#ga819abda8eb90c0247b8146ca9793af77',1,'globus_xio_gsi.h']]],
  ['globus_5fxio_5fgsi_5fproxy_5fmode_5ft_74',['globus_xio_gsi_proxy_mode_t',['../group__globus__xio__gsi__driver.html#gab673735248b59a2854caed81644205d7',1,'globus_xio_gsi.h']]]
];
