var searchData=
[
  ['globus_5fxio_5fgsi_5fdelegation_5faccept_5fcallback_5ft_67',['globus_xio_gsi_delegation_accept_callback_t',['../group__globus__xio__gsi__driver.html#ga66ef49154719cbd5507e7273c1e4f8c3',1,'globus_xio_gsi.h']]],
  ['globus_5fxio_5fgsi_5fdelegation_5finit_5fcallback_5ft_68',['globus_xio_gsi_delegation_init_callback_t',['../group__globus__xio__gsi__driver.html#ga80197984bebc78e7cafac2e3268a94d8',1,'globus_xio_gsi.h']]]
];
