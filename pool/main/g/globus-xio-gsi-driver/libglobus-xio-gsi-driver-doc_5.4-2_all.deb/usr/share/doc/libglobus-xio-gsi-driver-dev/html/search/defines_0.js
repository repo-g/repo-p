var searchData=
[
  ['globus_5fxio_5fgsi_5fattr_5fcntl_127',['globus_xio_gsi_attr_cntl',['../globus__xio__gsi_8h.html#a9045234c05e62afbfa3418b13b25ca27',1,'globus_xio_gsi.h']]]
];
