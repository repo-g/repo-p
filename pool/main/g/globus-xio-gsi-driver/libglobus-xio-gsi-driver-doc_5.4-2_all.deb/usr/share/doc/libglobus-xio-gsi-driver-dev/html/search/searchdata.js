var indexSectionsWithContent =
{
  0: "g",
  1: "g",
  2: "g",
  3: "g",
  4: "g",
  5: "g",
  6: "g",
  7: "g",
  8: "g"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "typedefs",
  4: "enums",
  5: "enumvalues",
  6: "defines",
  7: "groups",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Typedefs",
  4: "Enumerations",
  5: "Enumerator",
  6: "Macros",
  7: "Modules",
  8: "Pages"
};

