var searchData=
[
  ['globus_5fgsi_5fproxy_5fhandle_5fattrs_5ft_129',['globus_gsi_proxy_handle_attrs_t',['../group__globus__gsi__proxy__handle__attrs.html#ga66b2fcd0c7df2737bef97c2011895cc3',1,'globus_gsi_proxy.h']]],
  ['globus_5fgsi_5fproxy_5fhandle_5ft_130',['globus_gsi_proxy_handle_t',['../group__globus__gsi__proxy__handle.html#ga8aa60a8f880c91bae12994052ceeafc4',1,'globus_gsi_proxy.h']]]
];
