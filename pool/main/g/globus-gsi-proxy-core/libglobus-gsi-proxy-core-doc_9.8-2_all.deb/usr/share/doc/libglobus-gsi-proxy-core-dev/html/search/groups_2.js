var searchData=
[
  ['handle_20attributes_153',['Handle Attributes',['../group__globus__gsi__proxy__handle__attrs.html',1,'']]],
  ['handle_20management_154',['Handle Management',['../group__globus__gsi__proxy__handle.html',1,'']]]
];
