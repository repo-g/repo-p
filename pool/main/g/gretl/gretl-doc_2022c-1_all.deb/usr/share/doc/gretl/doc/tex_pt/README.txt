Note, 2016-12-30, by Allin Cottrell

I have removed untranslated out-of-date TeX source files from this
directory. If anyone wishes to work on a Portuguese translation of
the Gretl User's Guide, he/she may copy the current English files
from the ../tex directory into here.

--- original note --- 

These LaTex files are far from being translated.

The reason that this structure was created is to provide a platform for collaboration on the translation to Portuguese.

September of 2008,
Hélio Guilherme
