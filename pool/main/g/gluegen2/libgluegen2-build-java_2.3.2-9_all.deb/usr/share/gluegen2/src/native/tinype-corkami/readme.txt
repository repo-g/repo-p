TinyPE XP-W8 Compatible - x86 32bit and 64bit - 268 bytes

https://code.google.com/p/corkami/wiki/PE
https://code.google.com/p/corkami/source/browse/trunk/src/PE/tiny.asm

by Ange Albertini, BSD Licence, 2010-2013

tiny-simple.asm (diff to tiny.asm):
  - remove printf, and msvcrt.dll import
  - just return 0

+++

See also:

Tiny PE
http://www.phreedom.org/research/tinype/
by Alexander Sotirov

+++

Compiled w/ yasm 1.2.0 for win64 or win32.
http://yasm.tortall.net/

+++
