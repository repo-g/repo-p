#ifndef __stdarg_h
#define __stdarg_h

#include <gluegen_types.h>

#endif /* __stdarg_h */

