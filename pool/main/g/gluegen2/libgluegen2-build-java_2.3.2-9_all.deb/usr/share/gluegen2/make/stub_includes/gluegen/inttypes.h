#ifndef __inttypes_h
#define __inttypes_h

#include <gluegen_types.h>

#endif /* __stdint_h */

