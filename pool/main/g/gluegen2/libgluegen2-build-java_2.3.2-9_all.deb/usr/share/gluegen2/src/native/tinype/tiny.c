#undef UNICODE
#define UNICODE
#include <windows.h>

// const char * id = "JogAmp Windows Universal Test PE Executable";

// int __main()
// int main()
// int main( int argc, char* argv[] )
int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd)
{
    return 0;
}
