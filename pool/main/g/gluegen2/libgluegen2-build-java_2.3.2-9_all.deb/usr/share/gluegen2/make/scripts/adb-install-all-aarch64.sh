adb $* install ../build-android-aarch64/jogamp-android-launcher.apk
adb $* install ../build-android-aarch64/gluegen-rt-android-aarch64.apk
