#ifndef __stdio_h
#define __stdio_h

#include <gluegen_types.h>

#endif /* __stdio_h */

