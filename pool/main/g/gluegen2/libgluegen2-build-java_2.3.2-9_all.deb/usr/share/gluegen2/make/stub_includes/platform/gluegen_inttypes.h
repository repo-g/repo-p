#ifndef __gluegen_inttypes_h
#define __gluegen_inttypes_h

#ifdef __GLUEGEN__
    #error "This file is not intended to be used for GlueGen code generation, use the gluegen/make/stub_includes/gluegen variation instead!"
#endif

#include <gluegen_stdint.h>

#endif /* __gluegen_inttypes_h */

