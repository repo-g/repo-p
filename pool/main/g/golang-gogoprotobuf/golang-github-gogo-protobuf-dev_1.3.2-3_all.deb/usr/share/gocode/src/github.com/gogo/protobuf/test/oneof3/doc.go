package oneof3
