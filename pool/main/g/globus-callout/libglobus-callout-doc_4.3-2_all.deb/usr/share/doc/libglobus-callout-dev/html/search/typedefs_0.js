var searchData=
[
  ['globus_5fcallout_5ffunction_5ft_35',['globus_callout_function_t',['../group__globus__callout__call.html#ga44a2a47f9af96daeb6f4472d94f457f3',1,'globus_callout.h']]],
  ['globus_5fcallout_5fhandle_5ft_36',['globus_callout_handle_t',['../group__globus__callout__handle.html#ga7afe1905f0a00916859e9ff5dc1125ff',1,'globus_callout.h']]]
];
