var searchData=
[
  ['globus_5fi_5fcallout_5fmodule_34',['globus_i_callout_module',['../group__globus__callout__activation.html#ga9182ab03efdcf918f995274b39e792d8',1,'globus_i_callout_module():&#160;globus_callout.c'],['../group__globus__callout__activation.html#ga9182ab03efdcf918f995274b39e792d8',1,'globus_i_callout_module():&#160;globus_callout.c']]]
];
