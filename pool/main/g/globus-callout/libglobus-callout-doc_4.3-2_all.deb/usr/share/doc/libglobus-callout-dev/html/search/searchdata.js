var indexSectionsWithContent =
{
  0: "acg",
  1: "g",
  2: "g",
  3: "g",
  4: "g",
  5: "g",
  6: "g",
  7: "acg",
  8: "g"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "typedefs",
  5: "enums",
  6: "enumvalues",
  7: "groups",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Variables",
  4: "Typedefs",
  5: "Enumerations",
  6: "Enumerator",
  7: "Modules",
  8: "Pages"
};

