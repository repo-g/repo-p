/* gtkspell/gtkspellmmconfig.h.  Generated from gtkspellmmconfig.h.in by configure.  */
/* This file is part of gtkspellmm. */

/* Major version number of gtkspellmm. */
#define GTKSPELLMM_MAJOR_VERSION 3

/* Micro version number of gtkspellmm. */
#define GTKSPELLMM_MICRO_VERSION 5

/* Minor version number of gtkspellmm. */
#define GTKSPELLMM_MINOR_VERSION 0
