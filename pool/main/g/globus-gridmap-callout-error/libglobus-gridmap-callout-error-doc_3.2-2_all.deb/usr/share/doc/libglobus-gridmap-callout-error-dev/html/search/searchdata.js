var indexSectionsWithContent =
{
  0: "adg",
  1: "g",
  2: "g",
  3: "ad"
};

var indexSectionNames =
{
  0: "all",
  1: "enums",
  2: "enumvalues",
  3: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Enumerations",
  2: "Enumerator",
  3: "Modules"
};

