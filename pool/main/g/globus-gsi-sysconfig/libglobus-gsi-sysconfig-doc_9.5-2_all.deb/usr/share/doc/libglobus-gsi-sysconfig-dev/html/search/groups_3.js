var searchData=
[
  ['globus_20gsi_20system_20config_20api_214',['Globus GSI System Config API',['../group__globus__gsi__sysconfig.html',1,'']]]
];
