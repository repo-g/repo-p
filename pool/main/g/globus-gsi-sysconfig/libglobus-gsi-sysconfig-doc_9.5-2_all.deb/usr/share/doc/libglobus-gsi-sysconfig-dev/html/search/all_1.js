var searchData=
[
  ['data_20types_1',['Data Types',['../group__globus__gsi__sysconfig__datatypes.html',1,'']]],
  ['defines_2',['Defines',['../group__globus__gsi__system__config__defines.html',1,'']]]
];
