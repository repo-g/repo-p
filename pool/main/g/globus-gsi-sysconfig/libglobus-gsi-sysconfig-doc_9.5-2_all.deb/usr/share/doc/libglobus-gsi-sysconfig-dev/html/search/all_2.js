var searchData=
[
  ['functions_20for_20all_20platforms_3',['Functions for all platforms',['../group__globus__gsi__sysconfig__shared.html',1,'']]],
  ['functions_20for_20unix_20platforms_4',['Functions for UNIX platforms',['../group__globus__gsi__sysconfig__unix.html',1,'']]],
  ['functions_20for_20win32_20platforms_5',['Functions for Win32 platforms',['../group__globus__gsi__sysconfig__win32.html',1,'']]]
];
