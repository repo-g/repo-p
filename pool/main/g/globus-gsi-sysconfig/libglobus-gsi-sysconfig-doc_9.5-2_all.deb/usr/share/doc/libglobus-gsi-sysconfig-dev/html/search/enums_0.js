var searchData=
[
  ['globus_5fgsi_5fproxy_5ffile_5ftype_5ft_172',['globus_gsi_proxy_file_type_t',['../group__globus__gsi__sysconfig__datatypes.html#ga94d70620ea9adb2fb5b11b4e38244f30',1,'globus_gsi_system_config_constants.h']]],
  ['globus_5fgsi_5fsysconfig_5ferror_5ft_173',['globus_gsi_sysconfig_error_t',['../group__globus__gsi__sysconfig__datatypes.html#ga40caf4c88fabf0c4f270071f47f3959a',1,'globus_gsi_system_config_constants.h']]]
];
