var indexSectionsWithContent =
{
  0: "adfg",
  1: "g",
  2: "g",
  3: "g",
  4: "g",
  5: "adfg",
  6: "g"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "enums",
  4: "enumvalues",
  5: "groups",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Enumerations",
  4: "Enumerator",
  5: "Modules",
  6: "Pages"
};

