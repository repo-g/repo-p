-- Revert environments

BEGIN;

DROP TABLE environments;

COMMIT;
