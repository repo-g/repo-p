-- Revert nodes

BEGIN;

DROP TABLE nodes;

COMMIT;
