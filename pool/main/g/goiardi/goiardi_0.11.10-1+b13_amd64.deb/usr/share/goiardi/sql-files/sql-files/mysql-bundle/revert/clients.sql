-- Revert clients

BEGIN;

DROP TABLE clients;

COMMIT;
