-- Revert roles

BEGIN;

DROP TABLE goiardi.roles;

COMMIT;
