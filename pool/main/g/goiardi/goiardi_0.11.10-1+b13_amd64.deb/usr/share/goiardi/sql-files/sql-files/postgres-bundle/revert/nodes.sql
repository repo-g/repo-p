-- Revert nodes

BEGIN;

DROP TABLE goiardi.nodes;

COMMIT;
