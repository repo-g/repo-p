-- Revert organizations

BEGIN;

DROP TABLE organizations;

COMMIT;
