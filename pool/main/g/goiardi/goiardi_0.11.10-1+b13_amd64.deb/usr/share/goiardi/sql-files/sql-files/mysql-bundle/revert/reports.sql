-- Revert reports

BEGIN;

DROP TABLE reports;

COMMIT;
