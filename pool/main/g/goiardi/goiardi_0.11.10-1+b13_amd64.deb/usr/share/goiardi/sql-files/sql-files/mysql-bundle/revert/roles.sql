-- Revert roles

BEGIN;

DROP TABLE roles;

COMMIT;
