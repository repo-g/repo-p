-- Revert sandboxes

BEGIN;

DROP TABLE sandboxes;

COMMIT;
