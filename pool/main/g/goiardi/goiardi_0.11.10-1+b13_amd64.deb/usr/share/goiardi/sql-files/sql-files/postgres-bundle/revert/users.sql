-- Revert users

BEGIN;

DROP TABLE goiardi.users;

COMMIT;
