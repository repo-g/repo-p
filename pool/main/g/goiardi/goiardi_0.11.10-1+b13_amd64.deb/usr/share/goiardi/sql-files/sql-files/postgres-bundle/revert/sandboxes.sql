-- Revert sandboxes

BEGIN;

DROP TABLE goiardi.sandboxes;

COMMIT;
