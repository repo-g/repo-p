-- Revert clients

BEGIN;

DROP TABLE goiardi.clients;

COMMIT;
