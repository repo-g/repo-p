-- Revert organizations

BEGIN;

DROP TABLE goiardi.organizations;

COMMIT;
