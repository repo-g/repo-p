-- Revert data_bags

BEGIN;

DROP TABLE goiardi.data_bags;

COMMIT;
