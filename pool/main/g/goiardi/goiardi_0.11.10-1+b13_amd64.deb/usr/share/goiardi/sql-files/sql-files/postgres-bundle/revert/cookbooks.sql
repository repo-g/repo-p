-- Revert cookbooks

BEGIN;

DROP TABLE goiardi.cookbooks;

COMMIT;
