-- Revert goiardi_schema

BEGIN;

DROP SCHEMA goiardi;

COMMIT;
