-- Revert data_bags

BEGIN;

DROP TABLE data_bags;

COMMIT;
