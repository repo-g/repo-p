-- Revert users

BEGIN;

DROP TABLE users;

COMMIT;
