-- Revert log_infos

BEGIN;

DROP TABLE log_infos;

COMMIT;
