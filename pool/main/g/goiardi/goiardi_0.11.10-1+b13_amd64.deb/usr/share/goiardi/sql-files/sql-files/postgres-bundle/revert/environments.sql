-- Revert environments

BEGIN;

DROP TABLE goiardi.environments;

COMMIT;
