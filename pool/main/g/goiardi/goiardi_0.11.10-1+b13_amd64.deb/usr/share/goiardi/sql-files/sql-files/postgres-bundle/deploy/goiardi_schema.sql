-- Deploy goiardi_schema

BEGIN;

CREATE SCHEMA goiardi;

COMMIT;
