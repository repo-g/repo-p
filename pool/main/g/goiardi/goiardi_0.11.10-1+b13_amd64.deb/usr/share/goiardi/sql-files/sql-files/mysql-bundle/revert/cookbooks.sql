-- Revert cookbooks

BEGIN;

DROP TABLE cookbooks;

COMMIT;
