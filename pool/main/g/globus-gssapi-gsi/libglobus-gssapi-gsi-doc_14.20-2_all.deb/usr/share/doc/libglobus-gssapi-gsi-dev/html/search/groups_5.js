var searchData=
[
  ['request_20flags_129',['Request Flags',['../group__globus__gsi__gss__requested__context__flags.html',1,'']]],
  ['return_20flags_130',['Return Flags',['../group__globus__gsi__gss__returned__context__flags.html',1,'']]]
];
