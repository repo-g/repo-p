var searchData=
[
  ['delegation_126',['Delegation',['../group__globus__gsi__gssapi__extensions__delegation.html',1,'']]]
];
