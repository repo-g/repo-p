var searchData=
[
  ['delegation_3',['Delegation',['../group__globus__gsi__gssapi__extensions__delegation.html',1,'']]]
];
