var searchData=
[
  ['read_5fvhost_5fcred_5fdir_2ec_67',['read_vhost_cred_dir.c',['../read__vhost__cred__dir_8c.html',1,'']]],
  ['request_20flags_68',['Request Flags',['../group__globus__gsi__gss__requested__context__flags.html',1,'']]],
  ['return_20flags_69',['Return Flags',['../group__globus__gsi__gss__returned__context__flags.html',1,'']]]
];
