var searchData=
[
  ['globus_20openssl_20module_1',['Globus OpenSSL Module',['../group__globus__openssl__module.html',1,'(Global Namespace)'],['../index.html',1,'(Global Namespace)']]],
  ['globus_5fopenssl_2eh_2',['globus_openssl.h',['../globus__openssl_8h.html',1,'']]],
  ['globus_5fopenssl_5fmodule_3',['GLOBUS_OPENSSL_MODULE',['../group__globus__openssl__activation.html#ga976697225776651cf46289f745017f32',1,'globus_openssl.h']]]
];
