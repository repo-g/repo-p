// Gmsh - Copyright (C) 1997-2021 C. Geuzaine, J.-F. Remacle
//
// See the LICENSE.txt file for license information. Please report all
// issues on https://gitlab.onelab.info/gmsh/gmsh/issues.

#ifndef GMSH_VERSION_H
#define GMSH_VERSION_H

#define GMSH_MAJOR_VERSION 4
#define GMSH_MINOR_VERSION 8
#define GMSH_PATCH_VERSION 4
#define GMSH_EXTRA_VERSION ""
#define GMSH_VERSION       "4.8.4"
#define GMSH_DATE          "20230512"
#define GMSH_HOST          "debian-build-farm"
#define GMSH_PACKAGER      "nobody"
#define GMSH_OS            "Linux64-sdk"
#define GMSH_SHORT_LICENSE "GNU General Public License"

#endif
