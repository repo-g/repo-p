package losetup

import "testing"

func TestValid(t *testing.T) {
	// TODO: coherent way of testing
}
