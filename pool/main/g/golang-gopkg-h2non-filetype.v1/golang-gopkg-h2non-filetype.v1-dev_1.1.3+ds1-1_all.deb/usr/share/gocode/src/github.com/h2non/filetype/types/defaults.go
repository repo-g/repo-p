package types

// Unknown default type
var Unknown = NewType("unknown", "")
