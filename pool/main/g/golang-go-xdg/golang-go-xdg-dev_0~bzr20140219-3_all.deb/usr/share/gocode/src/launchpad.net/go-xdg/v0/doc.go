// (c) 2014 John R. Lenton. See LICENSE.

// xdg implements helpers for you to use the XDG spec in your apps.
//
// For now, that's just the base directory spec,
// http://standards.freedesktop.org/basedir-spec/basedir-spec-latest.html
package xdg
