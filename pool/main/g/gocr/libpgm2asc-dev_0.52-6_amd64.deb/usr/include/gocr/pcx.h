
#include "pnm.h"

void readpcx(char *name,pix *p,int vvv);

/* write 8bit palette no RLE, ToDo: obsolete?  */
void writebmp(char *name,pix p,int vvv);

/* ------------------------------------------------------------------------ */
