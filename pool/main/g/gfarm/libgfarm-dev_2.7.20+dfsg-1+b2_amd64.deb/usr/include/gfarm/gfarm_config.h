/* include/gfarm/gfarm_config.h.  Generated from gfarm_config.h.in by configure.  */
/* include/gfarm/gfarm_config.h.in.  Generated from configure.ac by autoheader.  */


#ifndef GFARM_CONFIG_H
#define GFARM_CONFIG_H


/* Define if building universal (internal helper macro) */
/* #undef AC_APPLE_UNIVERSAL_BUILD */

/* avoid locking for calling EVP_get_digestbyname() */
/* #undef DISABLE_GETDIGEST_LOCK */

/* support XML extended attributes and XPath search */
/* #undef ENABLE_XMLATTR */

/* Define to 1 if you have the `backtrace' function. */
#define HAVE_BACKTRACE 1

/* Define to 1 if you have the <byteswap.h> header file. */
#define HAVE_BYTESWAP_H 1

/* Define to 1 if you have the `clock_gettime' function. */
#define HAVE_CLOCK_GETTIME 1

/* Define to 1 if you have the `CRYPTO_set_id_callback' function. */
/* #undef HAVE_CRYPTO_SET_ID_CALLBACK */

/* Define to 1 if you have the `CRYPTO_set_locking_callback' function. */
/* #undef HAVE_CRYPTO_SET_LOCKING_CALLBACK */

/* Define to 1 if you have the <crypt.h> header file. */
#define HAVE_CRYPT_H 1

/* Define to 1 if you have the `daemon_symbols' function. */
/* #undef HAVE_DAEMON_SYMBOLS */

/* Define to 1 if you have the <dlfcn.h> header file. */
#define HAVE_DLFCN_H 1

/* struct dirent has d_namlen member */
/* #undef HAVE_D_NAMLEN */

/* struct dirent has d_off member */
#define HAVE_D_OFF 1

/* struct dirent has d_type member */
#define HAVE_D_TYPE 1

/* Define to 1 if epoll functions are implemented. */
#define HAVE_EPOLL 1

/* Define to 1 if you have the <execinfo.h> header file. */
#define HAVE_EXECINFO_H 1

/* Define to 1 if you have the `fdatasync' function. */
#define HAVE_FDATASYNC 1

/* Define to 1 if you have the `fdopendir' function. */
#define HAVE_FDOPENDIR 1

/* Define to 1 if you have the `futimes' function. */
#define HAVE_FUTIMES 1

/* Define to 1 if you have the `futimesat' function. */
#define HAVE_FUTIMESAT 1

/* Define to 1 if you have the `getdents' function. */
/* #undef HAVE_GETDENTS */

/* Define to 1 if you have the `getifaddrs' function. */
#define HAVE_GETIFADDRS 1

/* Define to 1 if you have the `getloadavg' function. */
#define HAVE_GETLOADAVG 1

/* Define to 1 if you have the `getopt_long' function. */
#define HAVE_GETOPT_LONG 1

/* Define to 1 if you have the `getpassphrase' function. */
/* #undef HAVE_GETPASSPHRASE */

/* 5 arguments getpwnam_r() which is compatible with SUSv2 exists */
#define HAVE_GETPWNAM_R 1

/* 5 arguments getspnam_r() exists */
#define HAVE_GETSPNAM_R 1

/* Grid Security Infrastructure exists */
/* #undef HAVE_GSI */

/* support InfiniBand RDMA between client and gfsd */
/* #undef HAVE_INFINIBAND */

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* LDAP library exists */
#define HAVE_LDAP 1

/* Define to 1 if you have the `ldap_memfree' function. */
#define HAVE_LDAP_MEMFREE 1

/* Define to 1 if you have the `ldap_perror' function. */
#define HAVE_LDAP_PERROR 1

/* Define to 1 if you have the `ldap_set_option' function. */
#define HAVE_LDAP_SET_OPTION 1

/* Define to 1 if you have the `ldap_start_tls_s' function. */
#define HAVE_LDAP_START_TLS_S 1

/* Define to 1 if you have the `cext' library (-lcext). */
/* #undef HAVE_LIBCEXT */

/* Define to 1 if you have the `compat' library (-lcompat). */
/* #undef HAVE_LIBCOMPAT */

/* Define to 1 if you have the `crypt' library (-lcrypt). */
#define HAVE_LIBCRYPT 1

/* Define to 1 if you have the `dl' library (-ldl). */
#define HAVE_LIBDL 1

/* Define to 1 if you have the `gen' library (-lgen). */
/* #undef HAVE_LIBGEN */

/* Define to 1 if you have the `nsl' library (-lnsl). */
#define HAVE_LIBNSL 1

/* Define to 1 if you have the `perfstat' library (-lperfstat). */
/* #undef HAVE_LIBPERFSTAT */

/* Define to 1 if you have the `rt' library (-lrt). */
#define HAVE_LIBRT 1

/* Define to 1 if you have the `socket' library (-lsocket). */
/* #undef HAVE_LIBSOCKET */

/* support Linux sendfile */
#define HAVE_LINUX_SENDFILE 1

/* Define to 1 if you have the <machine/endian.h> header file. */
/* #undef HAVE_MACHINE_ENDIAN_H */

/* Define to 1 if you have the `mkdtemp' function. */
#define HAVE_MKDTEMP 1

/* getaddrinfo(3) and getnameinfo(3) are MT-Safe */
#define HAVE_MTSAFE_NETDB 1

/* Define to 1 if you have the `poll' function. */
#define HAVE_POLL 1

/* Define to 1 if you have the `popcount64' function. */
/* #undef HAVE_POPCOUNT64 */

/* PostgreSQL library exists */
#define HAVE_POSTGRESQL 1

/* Define to 1 if you have the `pread' function. */
#define HAVE_PREAD 1

/* Define to 1 if you have the `printf' function. */
#define HAVE_PRINTF 1

/* Define to 1 if you have the `pstat' function. */
/* #undef HAVE_PSTAT */

/* PS_STRINGS exists */
/* #undef HAVE_PS_STRINGS */

/* pthread library exists */
#define HAVE_PTHREAD 1

/* pthread_attr_setstacksize() exists */
#define HAVE_PTHREAD_ATTR_SETSTACKSIZE 1

/* Define to 1 if you have the `pthread_barrier_wait' function. */
#define HAVE_PTHREAD_BARRIER_WAIT 1

/* Define to 1 if you have the `pthread_mutex_timedlock' function. */
#define HAVE_PTHREAD_MUTEX_TIMEDLOCK 1

/* PTHREAD_PRIO_INHERIT is usable */
#define HAVE_PTHREAD_PRIO_INHERIT 1

/* Define to 1 if you have the `pwrite' function. */
#define HAVE_PWRITE 1

/* Define to 1 if you have the `random' function. */
#define HAVE_RANDOM 1

/* Define to 1 if you have the `setlogin' function. */
/* #undef HAVE_SETLOGIN */

/* Define to 1 if you have the `setproctitle' function. */
/* #undef HAVE_SETPROCTITLE */

/* Define to 1 if you have the `setrlimit' function. */
#define HAVE_SETRLIMIT 1

/* Define to 1 if you have the <shadow.h> header file. */
#define HAVE_SHADOW_H 1

/* Define to 1 if you have the `sigtimedwait' function. */
#define HAVE_SIGTIMEDWAIT 1

/* Define to 1 if you have the `snprintf' function. */
#define HAVE_SNPRINTF 1

/* Define to 1 if you have the `statfs' function. */
#define HAVE_STATFS 1

/* Define to 1 if you have the `statvfs' function. */
#define HAVE_STATVFS 1

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdio.h> header file. */
#define HAVE_STDIO_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the `strtoll' function. */
#define HAVE_STRTOLL 1

/* Define to 1 if you have the `strtoq' function. */
#define HAVE_STRTOQ 1

/* Define to 1 if `st_atimespec.tv_nsec' is a member of `struct stat'. */
/* #undef HAVE_STRUCT_STAT_ST_ATIMESPEC_TV_NSEC */

/* Define to 1 if `st_atim.tv_nsec' is a member of `struct stat'. */
#define HAVE_STRUCT_STAT_ST_ATIM_TV_NSEC 1

/* Define to 1 if `st_mtimespec.tv_nsec' is a member of `struct stat'. */
/* #undef HAVE_STRUCT_STAT_ST_MTIMESPEC_TV_NSEC */

/* Define to 1 if `st_mtim.tv_nsec' is a member of `struct stat'. */
#define HAVE_STRUCT_STAT_ST_MTIM_TV_NSEC 1

/* Define to 1 if you have the <sys/loadavg.h> header file. */
/* #undef HAVE_SYS_LOADAVG_H */

/* Define to 1 if you have the <sys/pstat.h> header file. */
/* #undef HAVE_SYS_PSTAT_H */

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define to 1 if you have the <sys/xattr.h> header file. */
#define HAVE_SYS_XATTR_H 1

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* Define to 1 if you have the `utimensat' function. */
#define HAVE_UTIMENSAT 1

/* Define to 1 if you have the `__builtin_popcountll' function. */
#define HAVE___BUILTIN_POPCOUNTLL 1

/* ib_query_gid has ${ib_query_gid} args. */
/* #undef IB_QUERY_GID_ARG */

/* Define to the sub-directory where libtool stores uninstalled libraries. */
#define LT_OBJDIR ".libs/"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT ""

/* Define to the full name of this package. */
#define PACKAGE_NAME "gfarm"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "gfarm 2.7.20"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "gfarm"

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION "2.7.20"

/* The size of `long', as computed by sizeof. */
#define SIZEOF_LONG 8

/* The size of `long long', as computed by sizeof. */
#define SIZEOF_LONG_LONG 8

/* Define to 1 if all of the C90 standard headers exist (not just the ones
   required in a freestanding environment). This macro is provided for
   backward compatibility; new code need not use it. */
#define STDC_HEADERS 1

/* Define WORDS_BIGENDIAN to 1 if your processor stores words with the most
   significant byte first (like Motorola and SPARC, unlike Intel). */
#if defined AC_APPLE_UNIVERSAL_BUILD
# if defined __BIG_ENDIAN__
#  define WORDS_BIGENDIAN 1
# endif
#else
# ifndef WORDS_BIGENDIAN
/* #  undef WORDS_BIGENDIAN */
# endif
#endif

/* 3rd argument type of bind(2)/connect(2), if <sys/socket.h> doesn't define
   */
/* #undef socklen_t */


/* Grid Security Infrastructure exists */
/* #undef HAVE_GSI */

/* 5 arguments getpwnam_r() which is compatible with SUSv2 exists */
#define HAVE_GETPWNAM_R 1

/* 5 arguments getspnam_r() exists */
#define HAVE_GETSPNAM_R 1

/* 3rd argument type of bind(2)/connect(2), if <sys/socket.h> doesn't define */
/* #undef socklen_t */

#if SIZEOF_LONG == 8
	typedef long gfarm_int64_t;
	typedef unsigned long gfarm_uint64_t;
#	define GFARM_INT64_MAX		0x7fffffffffffffffL
#	define GFARM_UINT64_MAX		0xffffffffffffffffL
#	define GFARM_PRId64 "ld"
#	define gfarm_strtoi64(s, endptr)	strtol(s, endptr, 0)
#elif SIZEOF_LONG_LONG == 8
	typedef long long gfarm_int64_t;
	typedef unsigned long long gfarm_uint64_t;
#	define GFARM_INT64_MAX		0x7fffffffffffffffLL
#	define GFARM_UINT64_MAX		0xffffffffffffffffLL
#	define GFARM_PRId64 "lld"
#	define gfarm_strtoi64(s, endptr)	strtoll(s, endptr, 0)
#else
	error! cannot find 64bit integer type
#endif

#endif /* GFARM_CONFIG_H */

