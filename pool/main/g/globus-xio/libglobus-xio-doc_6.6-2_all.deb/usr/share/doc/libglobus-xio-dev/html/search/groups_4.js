var searchData=
[
  ['opening_2fclosing_572',['Opening/Closing',['../group__globus__xio__file__driver__instance.html',1,'(Global Namespace)'],['../group__globus__xio__http__driver__instance.html',1,'(Global Namespace)'],['../group__globus__xio__mode__e__driver__instance.html',1,'(Global Namespace)'],['../group__globus__xio__ordering__driver__instance.html',1,'(Global Namespace)'],['../group__globus__xio__tcp__driver__instance.html',1,'(Global Namespace)'],['../group__globus__xio__udp__driver__instance.html',1,'(Global Namespace)']]]
];
