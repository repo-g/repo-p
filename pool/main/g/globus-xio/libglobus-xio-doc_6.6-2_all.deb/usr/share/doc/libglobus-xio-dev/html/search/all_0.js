var searchData=
[
  ['attributes_20and_20cntls_0',['Attributes and Cntls',['../group__globus__xio__file__driver__cntls.html',1,'(Global Namespace)'],['../group__globus__xio__http__driver__cntls.html',1,'(Global Namespace)'],['../group__globus__xio__mode__e__driver__cntls.html',1,'(Global Namespace)'],['../group__globus__xio__ordering__driver__cntls.html',1,'(Global Namespace)'],['../group__globus__xio__tcp__driver__cntls.html',1,'(Global Namespace)'],['../group__globus__xio__udp__driver__cntls.html',1,'(Global Namespace)']]]
];
