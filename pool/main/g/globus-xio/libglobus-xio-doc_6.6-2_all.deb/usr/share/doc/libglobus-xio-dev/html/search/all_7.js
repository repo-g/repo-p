var searchData=
[
  ['server_286',['Server',['../group__globus__xio__http__driver__server.html',1,'(Global Namespace)'],['../group__globus__xio__mode__e__driver__server.html',1,'(Global Namespace)'],['../group__globus__xio__tcp__driver__server.html',1,'(Global Namespace)']]]
];
