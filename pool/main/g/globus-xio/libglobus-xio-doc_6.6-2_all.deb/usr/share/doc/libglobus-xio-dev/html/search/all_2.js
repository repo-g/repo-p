var searchData=
[
  ['env_20variables_3',['Env Variables',['../group__globus__xio__mode__e__driver__envs.html',1,'(Global Namespace)'],['../group__globus__xio__ordering__driver__envs.html',1,'(Global Namespace)'],['../group__globus__xio__tcp__driver__envs.html',1,'(Global Namespace)'],['../group__globus__xio__udp__driver__envs.html',1,'(Global Namespace)']]],
  ['environment_20variables_4',['Environment Variables',['../group__globus__xio__file__driver__envs.html',1,'']]],
  ['error_20types_5',['Error Types',['../group__globus__xio__file__driver__errors.html',1,'(Global Namespace)'],['../group__globus__xio__http__driver__errors.html',1,'(Global Namespace)'],['../group__globus__xio__mode__e__driver__errors.html',1,'(Global Namespace)'],['../group__globus__xio__ordering__driver__errors.html',1,'(Global Namespace)'],['../group__globus__xio__tcp__driver__errors.html',1,'(Global Namespace)'],['../group__globus__xio__udp__driver__errors.html',1,'(Global Namespace)']]]
];
