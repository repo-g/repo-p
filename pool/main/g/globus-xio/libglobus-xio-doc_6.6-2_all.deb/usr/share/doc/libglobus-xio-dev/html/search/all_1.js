var searchData=
[
  ['data_20descriptors_1',['Data descriptors',['../group__globus__xio__data__descriptors.html',1,'']]],
  ['driver_20programming_3a_20string_20options_2',['Driver Programming: String options',['../group__string__globus__xio__driver__programming.html',1,'']]]
];
