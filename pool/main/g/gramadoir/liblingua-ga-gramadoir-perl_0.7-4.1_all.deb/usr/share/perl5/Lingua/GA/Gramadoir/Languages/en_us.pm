package Lingua::GA::Gramadoir::Languages::en_us;

use strict;
use warnings;
use base qw(Lingua::GA::Gramadoir::Languages);
use vars qw(%Lexicon);

%Lexicon = (
	'_AUTO' => 1,


);
1;
