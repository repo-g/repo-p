package Lingua::GA::Gramadoir::Languages;

use strict;
use warnings;
use Locale::Maketext 1.01;
use base qw(Locale::Maketext);

1;
