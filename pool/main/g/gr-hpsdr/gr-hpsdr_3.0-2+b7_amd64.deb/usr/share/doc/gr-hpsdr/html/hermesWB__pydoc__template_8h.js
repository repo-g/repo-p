var hermesWB__pydoc__template_8h =
[
    [ "D", "hermesWB__pydoc__template_8h.html#a74021f021dcdfbb22891787b79c5529d", null ],
    [ "__doc_gr_hpsdr_hermesWB", "hermesWB__pydoc__template_8h.html#a48a9d35a7022473451c3d193825e7c16", null ],
    [ "__doc_gr_hpsdr_hermesWB_hermesWB", "hermesWB__pydoc__template_8h.html#ae67b64bc16b937285f39cc0dbe8f242e", null ],
    [ "__doc_gr_hpsdr_hermesWB_make", "hermesWB__pydoc__template_8h.html#a785dae7983eb1b3cffc603f2a561bca6", null ],
    [ "__doc_gr_hpsdr_hermesWB_set_AlexRxAntenna", "hermesWB__pydoc__template_8h.html#a139d9ec9dbd14da45d38c7af27f55e5f", null ],
    [ "__doc_gr_hpsdr_hermesWB_set_AlexRxHPF", "hermesWB__pydoc__template_8h.html#a935821fd043e5b792a749f4f7ba3fac4", null ],
    [ "__doc_gr_hpsdr_hermesWB_set_AlexTxAntenna", "hermesWB__pydoc__template_8h.html#a63f9ea09a5640a7d8e9956dc85e9ba6b", null ],
    [ "__doc_gr_hpsdr_hermesWB_set_AlexTxLPF", "hermesWB__pydoc__template_8h.html#a02bc5f5f8e00ad3088d853e7cb928d9e", null ],
    [ "__doc_gr_hpsdr_hermesWB_set_ClockSource", "hermesWB__pydoc__template_8h.html#a3e0a49151b7eb46190f059edebf3966b", null ],
    [ "__doc_gr_hpsdr_hermesWB_set_RxPreamp", "hermesWB__pydoc__template_8h.html#a44560e9d8c7596c780418462cb8d541f", null ],
    [ "__doc_gr_hpsdr_hermesWB_start", "hermesWB__pydoc__template_8h.html#a3588dbeb803b5dbb646eeed6a8eae63f", null ],
    [ "__doc_gr_hpsdr_hermesWB_stop", "hermesWB__pydoc__template_8h.html#ab696d349628b4f1e549c31402c5cd0cf", null ]
];