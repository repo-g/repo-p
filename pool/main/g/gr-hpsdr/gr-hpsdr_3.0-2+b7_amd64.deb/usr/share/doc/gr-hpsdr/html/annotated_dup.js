var annotated_dup =
[
    [ "gr", "namespacegr.html", [
      [ "hpsdr", "namespacegr_1_1hpsdr.html", [
        [ "hermesNB", "classgr_1_1hpsdr_1_1hermesNB.html", "classgr_1_1hpsdr_1_1hermesNB" ],
        [ "hermesNB_impl", "classgr_1_1hpsdr_1_1hermesNB__impl.html", "classgr_1_1hpsdr_1_1hermesNB__impl" ],
        [ "hermesWB", "classgr_1_1hpsdr_1_1hermesWB.html", "classgr_1_1hpsdr_1_1hermesWB" ],
        [ "hermesWB_impl", "classgr_1_1hpsdr_1_1hermesWB__impl.html", "classgr_1_1hpsdr_1_1hermesWB__impl" ]
      ] ]
    ] ],
    [ "_METIS_CARD", "struct__METIS__CARD.html", "struct__METIS__CARD" ],
    [ "HermesProxy", "classHermesProxy.html", "classHermesProxy" ],
    [ "HermesProxyW", "classHermesProxyW.html", "classHermesProxyW" ]
];