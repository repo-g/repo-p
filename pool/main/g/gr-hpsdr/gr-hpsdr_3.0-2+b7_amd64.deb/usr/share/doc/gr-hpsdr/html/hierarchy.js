var hierarchy =
[
    [ "_METIS_CARD", "struct__METIS__CARD.html", null ],
    [ "gr::block", null, [
      [ "gr::hpsdr::hermesNB", "classgr_1_1hpsdr_1_1hermesNB.html", [
        [ "gr::hpsdr::hermesNB_impl", "classgr_1_1hpsdr_1_1hermesNB__impl.html", null ]
      ] ],
      [ "gr::hpsdr::hermesWB", "classgr_1_1hpsdr_1_1hermesWB.html", [
        [ "gr::hpsdr::hermesWB_impl", "classgr_1_1hpsdr_1_1hermesWB__impl.html", null ]
      ] ]
    ] ],
    [ "HermesProxy", "classHermesProxy.html", null ],
    [ "HermesProxyW", "classHermesProxyW.html", null ]
];