var classgr_1_1hpsdr_1_1hermesWB =
[
    [ "sptr", "classgr_1_1hpsdr_1_1hermesWB.html#af4a6b5a57e285a52d061e635faa5908c", null ],
    [ "make", "classgr_1_1hpsdr_1_1hermesWB.html#a1caec68906ddf7c21dc38684d83a6412", null ],
    [ "set_AlexRxAntenna", "classgr_1_1hpsdr_1_1hermesWB.html#af692bff3b3b7d3a6c615d673565447ba", null ],
    [ "set_AlexRxHPF", "classgr_1_1hpsdr_1_1hermesWB.html#a2fc217bb6de8ce61ad7c259b7ae5df67", null ],
    [ "set_AlexTxAntenna", "classgr_1_1hpsdr_1_1hermesWB.html#a7f12f376b6230a0408449a0ff8868981", null ],
    [ "set_AlexTxLPF", "classgr_1_1hpsdr_1_1hermesWB.html#ae370be63b4b36ccd33c6210e91f5b76f", null ],
    [ "set_ClockSource", "classgr_1_1hpsdr_1_1hermesWB.html#a83b882a72e01e1eed87fef6d7121e3fd", null ],
    [ "set_RxPreamp", "classgr_1_1hpsdr_1_1hermesWB.html#a56e4e9c3f599ce0bc64c5c3ead36df58", null ],
    [ "start", "classgr_1_1hpsdr_1_1hermesWB.html#ac192918bb3953f89af364d74855c378a", null ],
    [ "stop", "classgr_1_1hpsdr_1_1hermesWB.html#a18e139e131c05ce81388ae181b3bf282", null ]
];