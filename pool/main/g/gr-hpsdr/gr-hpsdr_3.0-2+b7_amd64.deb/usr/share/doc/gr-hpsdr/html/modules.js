var modules =
[
    [ "GNU Radio HPSDR C++ Signal Processing Blocks", "group__block.html", null ]
];