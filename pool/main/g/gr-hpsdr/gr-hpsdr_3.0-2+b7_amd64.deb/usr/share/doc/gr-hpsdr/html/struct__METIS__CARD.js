var struct__METIS__CARD =
[
    [ "ip_address", "struct__METIS__CARD.html#a8596cf4b2c9fc0fe06460769bdcd6af2", null ],
    [ "mac_address", "struct__METIS__CARD.html#a9fbf59ece6dc42f085c69baa61b94c44", null ]
];