var classgr_1_1hpsdr_1_1hermesNB__impl =
[
    [ "hermesNB_impl", "classgr_1_1hpsdr_1_1hermesNB__impl.html#ac913597292794514a8d34fccf9f6218f", null ],
    [ "~hermesNB_impl", "classgr_1_1hpsdr_1_1hermesNB__impl.html#a2171d6a9f1ed9bbe1f77c97daf029e34", null ],
    [ "forecast", "classgr_1_1hpsdr_1_1hermesNB__impl.html#af063caaf556a42d1581f3d8688d09782", null ],
    [ "general_work", "classgr_1_1hpsdr_1_1hermesNB__impl.html#a9d83ae296f9df28d335196572ef34d2a", null ]
];