var HermesProxyW_8h =
[
    [ "HermesProxyW", "classHermesProxyW.html", "classHermesProxyW" ],
    [ "HermesProxyW_H", "HermesProxyW_8h.html#ac874edeb76e5d62be53e0fc5526ccc6f", null ],
    [ "NUMRXIQBUFS", "HermesProxyW_8h.html#a59d421cb83f087a7865031fccbb4e0a6", null ],
    [ "NUMTXBUFS", "HermesProxyW_8h.html#a1de5c03afa06a104981bc88381cf2921", null ],
    [ "RXBUFSIZE", "HermesProxyW_8h.html#a4a941b75a2cf56698a1e769d8214fd50", null ],
    [ "TXBUFSIZE", "HermesProxyW_8h.html#a9a01f28179d1f97c65ac28919f6f1cdb", null ]
];