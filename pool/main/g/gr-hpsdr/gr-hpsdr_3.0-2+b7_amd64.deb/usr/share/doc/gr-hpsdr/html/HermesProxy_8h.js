var HermesProxy_8h =
[
    [ "HermesProxy", "classHermesProxy.html", "classHermesProxy" ],
    [ "MAXRECEIVERS", "HermesProxy_8h.html#ab37f587d5785701b91ebb9c29823df9c", null ],
    [ "NUMRXIQBUFS", "HermesProxy_8h.html#a59d421cb83f087a7865031fccbb4e0a6", null ],
    [ "NUMTXBUFS", "HermesProxy_8h.html#a1de5c03afa06a104981bc88381cf2921", null ],
    [ "RXBUFSIZE", "HermesProxy_8h.html#a4a941b75a2cf56698a1e769d8214fd50", null ],
    [ "TXBUFSIZE", "HermesProxy_8h.html#a9a01f28179d1f97c65ac28919f6f1cdb", null ],
    [ "TXINITIALBURST", "HermesProxy_8h.html#abe0fbee286f5f85a94d29fe26ae393e2", null ],
    [ "IQBuf_t", "HermesProxy_8h.html#ae3655a7edeac87231fb5d8438894c107", null ],
    [ "RawBuf_t", "HermesProxy_8h.html#a999e79de1b1af1d74c47aa4a6555f966", null ]
];