//+build !windows

package tcellterm

var oscTerminators = []rune{0x07, 0x5c}
