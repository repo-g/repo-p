# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (c) 2010  Jon Lund Steffensen <jonlst@gmail.com>

"""defs.py -- GTK+ local definitions"""


LOCALEDIR = '/usr/share/locale'
BINDIR = '/usr/bin'
COMMAND = 'gammastep'
ICON_PREFIX = 'gammastep-'
GETTEXT_PKGNAME = 'gammastep'
INDICATOR_NAME = 'gammastep'
STATUS_TOOLTIP = 'gammastep'
DESKTOP_FILENAME = 'gammastep-indicator.desktop'
