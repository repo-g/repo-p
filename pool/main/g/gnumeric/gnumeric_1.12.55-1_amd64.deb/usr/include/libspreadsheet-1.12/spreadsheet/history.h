#ifndef _GNM_HISTORY_H_
# define _GNM_HISTORY_H_

#include <gnumeric.h>

G_BEGIN_DECLS

char *gnm_history_item_label (char const *uri, int accel_number);

G_END_DECLS

#endif /* _GNM_HISTORY_H_ */
