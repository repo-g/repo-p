#ifndef AUTO_CORRECT_H
#define AUTO_CORRECT_H

#include <gnumeric.h>

char    *autocorrect_tool	 (char const *input);

#endif /* AUTO_CORRECT_H */
