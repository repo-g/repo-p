#ifndef GNM_VALIDATION_COMBO_VIEW_H
#define GNM_VALIDATION_COMBO_VIEW_H

#include <glib-object.h>

GType gnm_validation_combo_view_get_type (void);

#endif /* GNM_VALIDATION_COMBO_VIEW_H */

