#ifndef GNM_SHEET_SLICER_COMBO_FOO_VIEW_H
#define GNM_SHEET_SLICER_COMBO_FOO_VIEW_H

#include <glib-object.h>

GType gnm_sheet_slicer_combo_view_get_type (void);

#endif /* GNM_SHEET_SLICER_COMBO_FOO_VIEW_H */
