#ifndef GNM_FILTER_COMBO_VIEW_H
#define GNM_FILTER_COMBO_VIEW_H

#include <glib-object.h>

GType gnm_filter_combo_view_get_type (void);

#endif /* GNM_FILTER_COMBO_VIEW_H */

