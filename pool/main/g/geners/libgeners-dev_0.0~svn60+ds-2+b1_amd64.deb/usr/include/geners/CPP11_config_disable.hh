#ifndef GENERS_CPP11_CONFIG_HH_
#define GENERS_CPP11_CONFIG_HH_

#include "geners/platform.hh"

#ifdef CPP11_STD_AVAILABLE
#undef CPP11_STD_AVAILABLE
#endif

#endif // GENERS_CPP11_CONFIG_HH_
