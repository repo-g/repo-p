#ifndef GENERS_LISTIO_HH_
#define GENERS_LISTIO_HH_

#include <list>
#include "geners/GenericIO.hh"

gs_specialize_template_id_TT(std::list, 0, 1)

#endif // GENERS_LISTIO_HH_
