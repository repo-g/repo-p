#ifndef GENERS_IOISTUPLE_HH_
#define GENERS_IOISTUPLE_HH_

namespace gs {
    template <class T>
    struct IOIsTuple
    {
        enum {value = 0};
    };
}

#endif // GENERS_IOISTUPLE_HH_
