#ifndef GENERS_DEQUEIO_HH_
#define GENERS_DEQUEIO_HH_

#include <deque>
#include "geners/GenericIO.hh"

gs_specialize_template_id_TT(std::deque, 0, 1)

#endif // GENERS_DEQUEIO_HH_
