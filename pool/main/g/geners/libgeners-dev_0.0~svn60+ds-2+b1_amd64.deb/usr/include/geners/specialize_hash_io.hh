#ifndef GENERS_SPECIALIZE_HASH_IO_HH_
#define GENERS_SPECIALIZE_HASH_IO_HH_

#include "geners/ClassId.hh"

gs_specialize_template_id_T(std::hash, 0, 1)

#endif // GENERS_SPECIALIZE_HASH_IO_HH_
