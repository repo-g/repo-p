#ifndef GENERS_CPP11_CONFIG_HH_
#define GENERS_CPP11_CONFIG_HH_

#include "geners/platform.hh"

#ifndef CPP11_STD_AVAILABLE
#define CPP11_STD_AVAILABLE
#endif

#endif // GENERS_CPP11_CONFIG_HH_
