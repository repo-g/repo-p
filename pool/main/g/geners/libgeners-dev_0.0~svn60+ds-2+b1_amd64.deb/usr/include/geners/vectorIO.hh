#ifndef GENERS_VECTORIO_HH_
#define GENERS_VECTORIO_HH_

#include "geners/GenericIO.hh"

#endif // GENERS_VECTORIO_HH_
