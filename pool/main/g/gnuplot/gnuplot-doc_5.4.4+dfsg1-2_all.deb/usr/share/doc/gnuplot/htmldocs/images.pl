# LaTeX2HTML 2022.2 (Released July 1, 2022)
# Associate images original text with physical files.


$key = q/<;MSF=1.6;AAT/;
$cached_env_img{$key} = q|4#4|; 

$key = q/>;MSF=1.6;AAT/;
$cached_env_img{$key} = q|5#5|; 

$key = q/N;MSF=1.6;AAT/;
$cached_env_img{$key} = q|15#15|; 

$key = q/Q(a,x)=frac{1}{Gamma(x)}intop_{x}^{infty}t^{a-1}e^{-t}dt;MSF=1.6;AAT/;
$cached_env_img{$key} = q|17#17|; 

$key = q/a^b_{cd};MSF=1.6;AAT/;
$cached_env_img{$key} = q|8#8|; 

$key = q/a^x;MSF=1.6;AAT/;
$cached_env_img{$key} = q|6#6|; 

$key = q/a_x;MSF=1.6;AAT/;
$cached_env_img{$key} = q|7#7|; 

$key = q/backslash;MSF=1.6;AAT/;
$cached_env_img{$key} = q|2#2|; 

$key = q/bar{y}=;MSF=1.6;AAT/;
$cached_env_img{$key} = q|24#24|; 

$key = q/frac{1}{Nsigma^3}sum{(y-bar{y})^3};MSF=1.6;AAT/;
$cached_env_img{$key} = q|32#32|; 

$key = q/frac{1}{Nsigma^4}sum{(y-bar{y})^4};MSF=1.6;AAT/;
$cached_env_img{$key} = q|33#33|; 

$key = q/frac{1}{N}sum{y};MSF=1.6;AAT/;
$cached_env_img{$key} = q|25#25|; 

$key = q/frac{1}{N}sum{|{y}-bar{y}|};MSF=1.6;AAT/;
$cached_env_img{$key} = q|34#34|; 

$key = q/imidy_i=max(y);MSF=1.6;AAT/;
$cached_env_img{$key} = q|23#23|; 

$key = q/imidy_i=min(y);MSF=1.6;AAT/;
$cached_env_img{$key} = q|22#22|; 

$key = q/in;MSF=1.6;AAT/;
$cached_env_img{$key} = q|14#14|; 

$key = q/infty;MSF=1.6;AAT/;
$cached_env_img{$key} = q|10#10|; 

$key = q/max(y);MSF=1.6;AAT/;
$cached_env_img{$key} = q|21#21|; 

$key = q/mbox{column}(x);MSF=1.6;AAT/;
$cached_env_img{$key} = q|16#16|; 

$key = q/min(y);MSF=1.6;AAT/;
$cached_env_img{$key} = q|20#20|; 

$key = q/s_y=;MSF=1.6;AAT/;
$cached_env_img{$key} = q|28#28|; 

$key = q/sigma_y=;MSF=1.6;AAT/;
$cached_env_img{$key} = q|26#26|; 

$key = q/sigma_yslashsqrt{2N};MSF=1.6;AAT/;
$cached_env_img{$key} = q|36#36|; 

$key = q/sigma_yslashsqrt{N};MSF=1.6;AAT/;
$cached_env_img{$key} = q|35#35|; 

$key = q/sqrt{24slashN};MSF=1.6;AAT/;
$cached_env_img{$key} = q|38#38|; 

$key = q/sqrt{6slashN};MSF=1.6;AAT/;
$cached_env_img{$key} = q|37#37|; 

$key = q/sqrt{frac{1}{N-1}{sum{{(y-bar{y})}^2}}};MSF=1.6;AAT/;
$cached_env_img{$key} = q|29#29|; 

$key = q/sqrt{frac{1}{N}{sum{{(y-bar{y})}^2}}};MSF=1.6;AAT/;
$cached_env_img{$key} = q|27#27|; 

$key = q/sum{y^2};MSF=1.6;AAT/;
$cached_env_img{$key} = q|31#31|; 

$key = q/sum{y};MSF=1.6;AAT/;
$cached_env_img{$key} = q|30#30|; 

$key = q/tilde{a};MSF=1.6;AAT/;
$cached_env_img{$key} = q|9#9|; 

$key = q/x;MSF=1.6;AAT/;
$cached_env_img{$key} = q|13#13|; 

$key = q/{center}vbox{input{titlepag.tex}}{center};AAT/;
$cached_env_img{$key} = q|1#1|; 

$key = q/|;MSF=1.6;AAT/;
$cached_env_img{$key} = q|3#3|; 

$key = q/~~N~~;MSF=1.6;AAT/;
$cached_env_img{$key} = q|18#18|; 

$key = q/~~~~~;MSF=1.6;AAT/;
$cached_env_img{$key} = q|19#19|; 

1;

