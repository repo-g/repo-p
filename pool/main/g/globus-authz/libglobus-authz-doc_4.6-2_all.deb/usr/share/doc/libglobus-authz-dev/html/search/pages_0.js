var searchData=
[
  ['globus_20gsi_20authorization_20api_31',['Globus GSI Authorization API',['../index.html',1,'']]]
];
