var searchData=
[
  ['globus_5fi_5fgsi_5fauthz_5fmodule_23',['globus_i_gsi_authz_module',['../globus__gsi__authz_8h.html#aa56f1c68e6e1df747a3acc8e3d253deb',1,'globus_gsi_authz.c']]]
];
