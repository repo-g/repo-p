var searchData=
[
  ['globus_5fgsi_5fauthz_2eh_16',['globus_gsi_authz.h',['../globus__gsi__authz_8h.html',1,'']]],
  ['globus_5fgsi_5fauthz_5fconstants_2eh_17',['globus_gsi_authz_constants.h',['../globus__gsi__authz__constants_8h.html',1,'']]]
];
