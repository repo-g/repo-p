var searchData=
[
  ['gsi_20authorization_20api_29',['GSI Authorization API',['../group__globus__gsi__authz.html',1,'']]],
  ['gsi_20credential_20constants_30',['GSI Credential Constants',['../group__globus__gsi__authz__constants.html',1,'']]]
];
