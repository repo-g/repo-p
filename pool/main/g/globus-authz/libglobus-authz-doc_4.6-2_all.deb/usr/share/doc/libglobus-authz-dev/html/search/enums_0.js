var searchData=
[
  ['globus_5fgsi_5fauthz_5ferror_5ft_24',['globus_gsi_authz_error_t',['../group__globus__gsi__authz__constants.html#ga5d2389de9e7358a3ecc0cfa0d310bb16',1,'globus_gsi_authz_constants.h']]]
];
