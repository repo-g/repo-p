var searchData=
[
  ['globus_5fgsi_5fauthz_5ferror_5fbad_5fparameter_25',['GLOBUS_GSI_AUTHZ_ERROR_BAD_PARAMETER',['../group__globus__gsi__authz__constants.html#gga5d2389de9e7358a3ecc0cfa0d310bb16a42d8c011d41574359f74530d5f3b468c',1,'globus_gsi_authz_constants.h']]],
  ['globus_5fgsi_5fauthz_5ferror_5fcallout_26',['GLOBUS_GSI_AUTHZ_ERROR_CALLOUT',['../group__globus__gsi__authz__constants.html#gga5d2389de9e7358a3ecc0cfa0d310bb16a1669e02278558a81de03951abd47b063',1,'globus_gsi_authz_constants.h']]],
  ['globus_5fgsi_5fauthz_5ferror_5ferrno_27',['GLOBUS_GSI_AUTHZ_ERROR_ERRNO',['../group__globus__gsi__authz__constants.html#gga5d2389de9e7358a3ecc0cfa0d310bb16a9c2896f2bbbecbc1e225c8c7995cd17b',1,'globus_gsi_authz_constants.h']]],
  ['globus_5fgsi_5fauthz_5ferror_5fsuccess_28',['GLOBUS_GSI_AUTHZ_ERROR_SUCCESS',['../group__globus__gsi__authz__constants.html#gga5d2389de9e7358a3ecc0cfa0d310bb16ad2e5e714474aaa090c073f5c585d1a34',1,'globus_gsi_authz_constants.h']]]
];
