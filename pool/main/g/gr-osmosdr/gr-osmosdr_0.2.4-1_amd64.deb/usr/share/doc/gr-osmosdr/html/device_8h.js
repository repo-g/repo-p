var device_8h =
[
    [ "osmosdr::device_t", "classosmosdr_1_1device__t.html", "classosmosdr_1_1device__t" ],
    [ "osmosdr::device", "classosmosdr_1_1device.html", "classosmosdr_1_1device" ],
    [ "devices_t", "device_8h.html#a816a598892b3c75162278dcb85e3b8ba", null ],
    [ "string_string_dict_t", "device_8h.html#a810b61ed385a7517ab323b2258c4e849", null ]
];