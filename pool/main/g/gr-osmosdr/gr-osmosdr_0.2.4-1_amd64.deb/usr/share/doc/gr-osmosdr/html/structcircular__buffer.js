var structcircular__buffer =
[
    [ "buffer", "structcircular__buffer.html#a89de3ce51dfc97834f60010ef0bedd6d", null ],
    [ "buffer_end", "structcircular__buffer.html#ad294794dae73692df11357763eaa0bfc", null ],
    [ "capacity", "structcircular__buffer.html#ad5c5dea841ec0edc761c997bd88f59ba", null ],
    [ "count", "structcircular__buffer.html#abf3ee1a580f2f8550005445b950b48bc", null ],
    [ "head", "structcircular__buffer.html#ade4bce1de6b27191328108fad382a19a", null ],
    [ "sz", "structcircular__buffer.html#a4e412a3634fda5e8632814efa52df825", null ],
    [ "tail", "structcircular__buffer.html#ab306ee6f2a6dd1819d3df09f6c04e95b", null ]
];