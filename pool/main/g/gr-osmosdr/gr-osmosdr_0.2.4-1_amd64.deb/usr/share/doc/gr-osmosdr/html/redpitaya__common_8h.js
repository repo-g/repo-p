var redpitaya__common_8h =
[
    [ "INVSOC", "redpitaya__common_8h.html#aa48790fa24c3c85eecced25163f15404", null ],
    [ "SOCKET", "redpitaya__common_8h.html#aff55fe551a9992a54ec54621c524d0a4", null ],
    [ "redpitaya_send_command", "redpitaya__common_8h.html#a71824667981e13653d5ecc4d653a3936", null ]
];