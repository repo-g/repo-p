var ranges_8h =
[
    [ "osmosdr::range_t", "classosmosdr_1_1range__t.html", "classosmosdr_1_1range__t" ],
    [ "osmosdr::meta_range_t", "structosmosdr_1_1meta__range__t.html", "structosmosdr_1_1meta__range__t" ],
    [ "freq_range_t", "ranges_8h.html#a03b9108867000412c7fcef50f8a65c0d", null ],
    [ "gain_range_t", "ranges_8h.html#adfdc6fd5f1a57069c805d86ef890f78d", null ],
    [ "ALL_CHANS", "ranges_8h.html#a8ac04e656ab45f6a6efc611dd4100c5e", null ],
    [ "ALL_MBOARDS", "ranges_8h.html#ac638240239e018da686fa995c124e7b3", null ]
];