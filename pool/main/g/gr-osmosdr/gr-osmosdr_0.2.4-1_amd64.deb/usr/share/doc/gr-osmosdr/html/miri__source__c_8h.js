var miri__source__c_8h =
[
    [ "mirisdr_dev_t", "miri__source__c_8h.html#a3718bdc68f947fe3e512402fd5131c04", null ],
    [ "make_miri_source_c", "miri__source__c_8h.html#a14ae794429a33ac23097a3dd6731d752", null ]
];