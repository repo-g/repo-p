var classfcd__source__c =
[
    [ "dongle_type", "classfcd__source__c.html#abf682ccb6453bddde2b1824536275a66", [
      [ "FUNCUBE_UNKNOWN", "classfcd__source__c.html#abf682ccb6453bddde2b1824536275a66a57984791c907f94f8d2f57dae8bf44ed", null ],
      [ "FUNCUBE_V1", "classfcd__source__c.html#abf682ccb6453bddde2b1824536275a66a9ee175a8b9499f971508067f40de8ff7", null ],
      [ "FUNCUBE_V2", "classfcd__source__c.html#abf682ccb6453bddde2b1824536275a66ac84390ffc1b29e945ebe913c6abd42d5", null ]
    ] ],
    [ "~fcd_source_c", "classfcd__source__c.html#a3cd75180aa0a042e818287a08eafaad8", null ],
    [ "get_antenna", "classfcd__source__c.html#a11036765aa80997522d15bfd97476338", null ],
    [ "get_antennas", "classfcd__source__c.html#a0024f326c44e37d029522617214e99f2", null ],
    [ "get_center_freq", "classfcd__source__c.html#add04a97e3f0494ad86057de42dd3a2c4", null ],
    [ "get_devices", "classfcd__source__c.html#a3146d7052b87c3cf8592d516c0edc3ae", null ],
    [ "get_freq_corr", "classfcd__source__c.html#a7840267b0907748c272efd59eb6596a9", null ],
    [ "get_freq_range", "classfcd__source__c.html#af38c9b19f1082407d87bcaf1cc0481b1", null ],
    [ "get_gain", "classfcd__source__c.html#a72ce9d783e0fd8efb41a2c3bafb793f1", null ],
    [ "get_gain", "classfcd__source__c.html#adb96fbc7aaaf7516d029032f0694f456", null ],
    [ "get_gain_names", "classfcd__source__c.html#adc53eb69337eb2a79ccd33be48bcd416", null ],
    [ "get_gain_range", "classfcd__source__c.html#a7af92ae4287be379c44016f47e9bc243", null ],
    [ "get_gain_range", "classfcd__source__c.html#a40e58a7620c8ea2ea92fa5a63652813a", null ],
    [ "get_num_channels", "classfcd__source__c.html#a153f063007dd8dadaed1f05b62c42f0a", null ],
    [ "get_sample_rate", "classfcd__source__c.html#abd6eb0d27bb9eba1e80eebd90076a793", null ],
    [ "get_sample_rates", "classfcd__source__c.html#ab3596eae3414c8fadc56af44e5424314", null ],
    [ "name", "classfcd__source__c.html#a4378fe90be89f64b4a66001cfa4739dc", null ],
    [ "set_antenna", "classfcd__source__c.html#a1d131453dc5c4bb7f782ecbe5af0e0be", null ],
    [ "set_center_freq", "classfcd__source__c.html#a49153aa680cbc85fe81f896b4e07157a", null ],
    [ "set_freq_corr", "classfcd__source__c.html#a8d932f12f3f4215a3283f53caf341ff7", null ],
    [ "set_gain", "classfcd__source__c.html#a731055cf4c21fb84643582da10c6f88a", null ],
    [ "set_gain", "classfcd__source__c.html#ac281e5bd6765034e7a1ff99625a7f43f", null ],
    [ "set_sample_rate", "classfcd__source__c.html#a4f801f3ccb62d61e3d3bfba87643a82d", null ],
    [ "make_fcd_source_c", "classfcd__source__c.html#a65a3d85eaf1422591064f82560ea8afa", null ]
];