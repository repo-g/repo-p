var time__spec_8h =
[
    [ "osmosdr::time_spec_t", "classosmosdr_1_1time__spec__t.html", "classosmosdr_1_1time__spec__t" ],
    [ "operator<", "time__spec_8h.html#a2d845d8c81e2f88cf4e257c119e5678b", null ],
    [ "operator==", "time__spec_8h.html#ab6d56e10a08245d9dab946fc2673c30e", null ]
];