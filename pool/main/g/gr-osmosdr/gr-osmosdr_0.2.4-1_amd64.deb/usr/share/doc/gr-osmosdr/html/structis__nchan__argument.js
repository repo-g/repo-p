var structis__nchan__argument =
[
    [ "operator()", "structis__nchan__argument.html#a1de3e70c01ab5559c47e7a9fdbadbf58", null ]
];