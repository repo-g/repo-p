var soapy__common_8h =
[
    [ "get_soapy_maker_mutex", "soapy__common_8h.html#ab077c2992892196094de3c52037ca046", null ],
    [ "soapy_range_to_gain_range", "soapy__common_8h.html#abc0896f8b87fdd169831cd6f9ebe2065", null ]
];