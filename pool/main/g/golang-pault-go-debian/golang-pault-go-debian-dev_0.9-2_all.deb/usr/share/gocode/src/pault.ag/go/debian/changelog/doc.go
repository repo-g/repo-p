/*

Parse the Debian changelog format.

*/
package changelog
