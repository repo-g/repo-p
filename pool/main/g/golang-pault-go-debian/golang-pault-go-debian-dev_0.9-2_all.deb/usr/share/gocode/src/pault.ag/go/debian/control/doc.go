/*

Parse the Debian control file format.

*/
package control
