var files_dup =
[
    [ "docs", "dir_49e56c817e5e54854c35e136979f97ca.html", "dir_49e56c817e5e54854c35e136979f97ca" ],
    [ "include", "dir_d44c64559bbebec7f509842c48db8b23.html", "dir_d44c64559bbebec7f509842c48db8b23" ],
    [ "lib", "dir_97aefd0d527b934f1d99a682da8fe6a9.html", "dir_97aefd0d527b934f1d99a682da8fe6a9" ],
    [ "lib", "dir_42de171c5443e58084bb06451d8d7630.html", "dir_42de171c5443e58084bb06451d8d7630" ],
    [ "python", "dir_ca01010b7b3fd2da2e4fa594c9bd2e99.html", "dir_ca01010b7b3fd2da2e4fa594c9bd2e99" ]
];