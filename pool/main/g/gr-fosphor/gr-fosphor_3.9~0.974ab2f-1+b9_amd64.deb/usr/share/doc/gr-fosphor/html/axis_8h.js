var axis_8h =
[
    [ "freq_axis_build", "group__axis.html#gaf2ac794b6be9cbd70b86884b136f2d63", null ],
    [ "freq_axis_render", "group__axis.html#ga1c46e2fc1014ab2dccfffddad8d74aef", null ]
];