var group__cl =
[
    [ "cl.h", "cl_8h.html", null ],
    [ "cl_compat.h", "cl__compat_8h.html", null ],
    [ "fosphor_cl_finish", "group__cl.html#ga3d1a45be2ae8b20cac2c0ba670fec58d", null ],
    [ "fosphor_cl_get_waterfall_position", "group__cl.html#gad0fd81e63be9630c63256b2b59d2318f", null ],
    [ "fosphor_cl_init", "group__cl.html#ga6bd3bb1438724b92fc2161002caef818", null ],
    [ "fosphor_cl_load_fft_window", "group__cl.html#gae695b8d82dbe067036f8e572d71457ed", null ],
    [ "fosphor_cl_process", "group__cl.html#gae4bda54c9a320ae8afe27c810ae64ccf", null ],
    [ "fosphor_cl_release", "group__cl.html#ga8de016a7ee33e06f4c86bd9f4c869d42", null ],
    [ "fosphor_cl_set_histogram_range", "group__cl.html#gaf48107dc4e3b1ddf9710d056147db992", null ]
];