var group__axis =
[
    [ "axis.h", "axis_8h.html", null ],
    [ "freq_axis", "structfreq__axis.html", [
      [ "abs_fmt", "structfreq__axis.html#ad0371204ab5acc009ae1340ef3830686", null ],
      [ "abs_scale", "structfreq__axis.html#a4062f2547598c57668fd4b3cd00ac88e", null ],
      [ "center", "structfreq__axis.html#a37fc44c8014dadbb88a19563cc958ef1", null ],
      [ "mode", "structfreq__axis.html#a0393928c2dd9930dcd54d3026390e22e", null ],
      [ "rel_fmt", "structfreq__axis.html#a1d46d19a8b2926ec68e6727125d832ed", null ],
      [ "rel_step", "structfreq__axis.html#a2c1f838e9690799e49fa810425a2d4bc", null ],
      [ "span", "structfreq__axis.html#a43e0580a7ece6faafb5c126468bd6a18", null ],
      [ "step", "structfreq__axis.html#a5bb6406cbdc9e1b9d9b8492607c36ec5", null ]
    ] ],
    [ "freq_axis_build", "group__axis.html#gaf2ac794b6be9cbd70b86884b136f2d63", null ],
    [ "freq_axis_render", "group__axis.html#ga1c46e2fc1014ab2dccfffddad8d74aef", null ]
];