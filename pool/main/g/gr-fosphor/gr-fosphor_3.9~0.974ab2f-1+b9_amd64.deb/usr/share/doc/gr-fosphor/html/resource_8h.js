var resource_8h =
[
    [ "resource_get", "group__resource.html#gaa62ad1685b525e1fbfb6ea09d16ea30e", null ],
    [ "resource_put", "group__resource.html#ga8e28d6bf1ded21d74f0aa579abde916c", null ]
];