var structresource__pack =
[
    [ "data", "structresource__pack.html#a4faa23de8680029df26ccf657b714216", null ],
    [ "len", "structresource__pack.html#a8bfba72794a61a27dd79ca6aa9c67f7e", null ],
    [ "name", "structresource__pack.html#a2f9740fd20dbd3eb3dd7732fc1126f0b", null ]
];