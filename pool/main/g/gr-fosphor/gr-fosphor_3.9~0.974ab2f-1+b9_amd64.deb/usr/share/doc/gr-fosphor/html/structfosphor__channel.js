var structfosphor__channel =
[
    [ "center", "structfosphor__channel.html#afe5edec5354de60db553836464fc90cf", null ],
    [ "enabled", "structfosphor__channel.html#a964ef46673267914f08355e7ecc531e9", null ],
    [ "width", "structfosphor__channel.html#ad1d24bc70fd501bb821e4ca833860001", null ]
];