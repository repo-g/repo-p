var group__resource =
[
    [ "resource.h", "resource_8h.html", null ],
    [ "lib/fosphor/resource_internal.h", "lib_2fosphor_2resource__internal_8h.html", null ],
    [ "obj-x86_64-linux-gnu/lib/fosphor/resource_internal.h", "obj-x86__64-linux-gnu_2lib_2fosphor_2resource__internal_8h.html", null ],
    [ "resource_pack", "structresource__pack.html", [
      [ "data", "structresource__pack.html#a4faa23de8680029df26ccf657b714216", null ],
      [ "len", "structresource__pack.html#a8bfba72794a61a27dd79ca6aa9c67f7e", null ],
      [ "name", "structresource__pack.html#a2f9740fd20dbd3eb3dd7732fc1126f0b", null ]
    ] ],
    [ "resource_cache", "structresource__cache.html", [
      [ "data", "structresource__cache.html#ac4887321a1e469b695d37cedafe336e7", null ],
      [ "extra", "structresource__cache.html#a52f52649057f4140166ded312b3e0247", null ],
      [ "flags", "structresource__cache.html#a95a5ee83d7e0328e8071c1c8a7b52c5d", null ],
      [ "head", "structresource__cache.html#a94e1c605a59b954de070d8f9c78f64d0", null ],
      [ "len", "structresource__cache.html#a52e30f29428f2361f6d86300ce3388b4", null ],
      [ "name", "structresource__cache.html#a43faa21a2d54e53e0554d3d8e01a07b0", null ],
      [ "refcnt", "structresource__cache.html#a5a8546427cb434726ab92b2ac21df173", null ]
    ] ],
    [ "resource_get", "group__resource.html#gaa62ad1685b525e1fbfb6ea09d16ea30e", null ],
    [ "resource_put", "group__resource.html#ga8e28d6bf1ded21d74f0aa579abde916c", null ]
];