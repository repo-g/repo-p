var annotated_dup =
[
    [ "gr", "namespacegr.html", [
      [ "fosphor", "namespacegr_1_1fosphor.html", [
        [ "base_sink_c", "classgr_1_1fosphor_1_1base__sink__c.html", "classgr_1_1fosphor_1_1base__sink__c" ],
        [ "base_sink_c_impl", "classgr_1_1fosphor_1_1base__sink__c__impl.html", "classgr_1_1fosphor_1_1base__sink__c__impl" ],
        [ "fifo", "classgr_1_1fosphor_1_1fifo.html", "classgr_1_1fosphor_1_1fifo" ],
        [ "glfw_sink_c", "classgr_1_1fosphor_1_1glfw__sink__c.html", "classgr_1_1fosphor_1_1glfw__sink__c" ],
        [ "glfw_sink_c_impl", "classgr_1_1fosphor_1_1glfw__sink__c__impl.html", "classgr_1_1fosphor_1_1glfw__sink__c__impl" ],
        [ "QGLSurface", "classgr_1_1fosphor_1_1QGLSurface.html", "classgr_1_1fosphor_1_1QGLSurface" ],
        [ "qt_sink_c", "classgr_1_1fosphor_1_1qt__sink__c.html", "classgr_1_1fosphor_1_1qt__sink__c" ],
        [ "qt_sink_c_impl", "classgr_1_1fosphor_1_1qt__sink__c__impl.html", "classgr_1_1fosphor_1_1qt__sink__c__impl" ]
      ] ]
    ] ],
    [ "_cl_image_desc", "struct__cl__image__desc.html", "struct__cl__image__desc" ],
    [ "fosphor", "structfosphor.html", "structfosphor" ],
    [ "fosphor_channel", "structfosphor__channel.html", "structfosphor__channel" ],
    [ "fosphor_render", "structfosphor__render.html", "structfosphor__render" ],
    [ "freq_axis", "structfreq__axis.html", "structfreq__axis" ],
    [ "llist_head", "structllist__head.html", "structllist__head" ],
    [ "resource_cache", "structresource__cache.html", "structresource__cache" ],
    [ "resource_pack", "structresource__pack.html", "structresource__pack" ]
];