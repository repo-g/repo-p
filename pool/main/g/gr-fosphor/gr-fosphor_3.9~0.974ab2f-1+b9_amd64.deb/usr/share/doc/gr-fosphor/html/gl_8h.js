var gl_8h =
[
    [ "fosphor_gl_id", "group__gl.html#ga69e22d0e88439b4898263c6471520c84", [
      [ "GL_ID_TEX_WATERFALL", "group__gl.html#gga69e22d0e88439b4898263c6471520c84aa9e57a2edf19f6f5c9e57e4c45f2d61d", null ],
      [ "GL_ID_TEX_HISTOGRAM", "group__gl.html#gga69e22d0e88439b4898263c6471520c84a90b17fe8a5f6238a78512a29d9c16da8", null ],
      [ "GL_ID_VBO_SPECTRUM", "group__gl.html#gga69e22d0e88439b4898263c6471520c84a2bd2590bea3088a731aab7e02efbf11e", null ]
    ] ],
    [ "fosphor_gl_draw", "group__gl.html#gaafca1dd7081a6eb876c05836981b50c1", null ],
    [ "fosphor_gl_get_shared_id", "group__gl.html#gae2bacad5995398a0c15bd3885f2e06e1", null ],
    [ "fosphor_gl_init", "group__gl.html#ga95c02994262c0e426c7ac3a3dd80b201", null ],
    [ "fosphor_gl_refresh", "group__gl.html#gaecd4686ce841cbd6740fa4684b1f2dcd", null ],
    [ "fosphor_gl_release", "group__gl.html#ga492e62827128d897d47b8373ae0f6835", null ]
];