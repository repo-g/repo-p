var gl__cmap_8h =
[
    [ "gl_cmap_gen_func_t", "group__gl.html#gad46e9320ded58598cb6e305c9b915be9", null ],
    [ "fosphor_gl_cmap_mode", "group__gl.html#gad3a0574ba0faa35f7e3b98f2c0cb848e", [
      [ "GL_CMAP_MODE_NEAREST", "group__gl.html#ggad3a0574ba0faa35f7e3b98f2c0cb848eaf97130244cff9f8b001d0da68712cb60", null ],
      [ "GL_CMAP_MODE_BILINEAR", "group__gl.html#ggad3a0574ba0faa35f7e3b98f2c0cb848eace0f548561277a764e945a6a133f32ca", null ],
      [ "GL_CMAP_MODE_BICUBIC", "group__gl.html#ggad3a0574ba0faa35f7e3b98f2c0cb848ea0dfa3c194fcd99f88fdb4669f8e6872d", null ]
    ] ],
    [ "fosphor_gl_cmap_disable", "group__gl.html#ga3560cfdfca34c6f2c80db5b7ae964a76", null ],
    [ "fosphor_gl_cmap_draw_scale", "group__gl.html#gaae581028e9ec2167a458008fd4d75fb2", null ],
    [ "fosphor_gl_cmap_enable", "group__gl.html#ga6882c4338845c3c8306b7445fdf12bad", null ],
    [ "fosphor_gl_cmap_generate", "group__gl.html#ga1a843c320898fbba09aef378aafe6eb9", null ],
    [ "fosphor_gl_cmap_init", "group__gl.html#ga86e659ee64f469c152e31546502e7661", null ],
    [ "fosphor_gl_cmap_release", "group__gl.html#ga709725662dcd8e8c5997732692004e00", null ]
];