var classgr_1_1fosphor_1_1glfw__sink__c =
[
    [ "sptr", "classgr_1_1fosphor_1_1glfw__sink__c.html#ad4a71bc810065c2fc5d055c31649f877", null ],
    [ "make", "classgr_1_1fosphor_1_1glfw__sink__c.html#a1c648337ab2b335befd0afeaccc1cd44", null ]
];