var structresource__cache =
[
    [ "data", "structresource__cache.html#ac4887321a1e469b695d37cedafe336e7", null ],
    [ "extra", "structresource__cache.html#a52f52649057f4140166ded312b3e0247", null ],
    [ "flags", "structresource__cache.html#a95a5ee83d7e0328e8071c1c8a7b52c5d", null ],
    [ "head", "structresource__cache.html#a94e1c605a59b954de070d8f9c78f64d0", null ],
    [ "len", "structresource__cache.html#a52e30f29428f2361f6d86300ce3388b4", null ],
    [ "name", "structresource__cache.html#a43faa21a2d54e53e0554d3d8e01a07b0", null ],
    [ "refcnt", "structresource__cache.html#a5a8546427cb434726ab92b2ac21df173", null ]
];