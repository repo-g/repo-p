/* All Rights reserved */

#include <AppKit/AppKit.h>

#include <InterfaceBuilder/InterfaceBuilder.h>

@interface GormNSSplitViewInspector : IBInspector
{
  id orientation;
}
@end
