/* All Rights reserved */

#include <AppKit/AppKit.h>

@interface WinController : NSObject
{
  id window;
}
@end
