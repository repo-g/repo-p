/* All rights reserved */

#include <AppKit/AppKit.h>
#include "MyController.h"

@implementation MyController


- (void) buttonPressed: (id)sender
{
  [value setStringValue: @"Hello"];
}

@end
