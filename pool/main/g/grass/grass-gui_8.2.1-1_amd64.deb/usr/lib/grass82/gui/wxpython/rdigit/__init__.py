all = [
    "controller",
    "toolbars",
    "dialogs",
    "g.gui.rdigit",
]
