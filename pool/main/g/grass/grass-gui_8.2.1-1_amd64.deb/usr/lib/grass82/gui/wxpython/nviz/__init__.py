all = [
    "preferences",
    "main",
    "mapwindow",
    "tools",
    "wxnviz",
    "workspace",
    "animation",
]
