all = [
    "overlays",
    "main",
    "statusbar",
    "mapwindow",
    "toolbars",
    "frame",
    "gprint",
]
