all = [
    "widgets",
    "cap_interface",
    "dialogs",
]
