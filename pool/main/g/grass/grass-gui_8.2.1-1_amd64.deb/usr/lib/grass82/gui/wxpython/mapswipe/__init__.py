all = [
    "g.gui.mapswipe",
    "dialogs",
    "mapwindow",
    "toolbars",
    "frame",
]
