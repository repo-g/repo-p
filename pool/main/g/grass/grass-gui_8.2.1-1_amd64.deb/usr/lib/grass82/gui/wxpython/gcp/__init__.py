all = [
    "manager",
    "mapdisplay",
    "toolbars",
]
