#ifndef GRASS_SYMBOLDEFS_H
#define GRASS_SYMBOLDEFS_H

SYMBOL *S_read(const char *sname);
void S_stroke(SYMBOL * symb, double size, double rotation, int tolerance);

#endif
