#ifndef GRASS_ORTHO_H
#define GRASS_ORTHO_H

#include <grass/defs/ortholib.h>

#endif
