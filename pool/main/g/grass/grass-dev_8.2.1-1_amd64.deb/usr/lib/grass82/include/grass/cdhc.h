#ifndef CDHC_H
#define CDHC_H

#include <grass/defs/cdhc.h>

#endif /* CDHC_H */
