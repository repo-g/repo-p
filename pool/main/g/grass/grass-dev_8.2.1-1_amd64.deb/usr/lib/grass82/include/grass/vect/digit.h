#include "dig_defines.h"	/* #define's */
#include "dig_macros.h"		/* #define Macros */
#include "dig_structs.h"	/* system structs */
#include "dig_externs.h"	/* function return value definitions */
