/* include/grass/config.h.  Generated from config.h.in by configure.  */
/* include/grass/config.h.in.  Generated from configure.ac by autoheader.  */

/* Define to 1 if you have the <ad2.h> header file. */
/* #undef HAVE_AD2_H */

/* Define to 1 if you have the `asprintf' function. */
#define HAVE_ASPRINTF 1

/* Define to 1 if you have the <bzlib.h> header file. */
#define HAVE_BZLIB_H 1

/* Define to 1 if you have the <cairo.h> header file. */
#define HAVE_CAIRO_H 1

/* Define to 1 if you have the <cblas.h> header file. */
#define HAVE_CBLAS_H 1

/* Define to 1 if you have the <clapack.h> header file. */
/* #undef HAVE_CLAPACK_H */

/* Define to 1 if you have the <CL/cl.h> header file. */
/* #undef HAVE_CL_CL_H */

/* Define to 1 if you have the <dfftw.h> header file. */
/* #undef HAVE_DFFTW_H */

/* Define to 1 if you have the `drand48' function. */
#define HAVE_DRAND48 1

/* Define to 1 if you have the <f2c.h> header file. */
/* #undef HAVE_F2C_H */

/* Define to 1 if you have the <fftw3.h> header file. */
#define HAVE_FFTW3_H 1

/* Define to 1 if you have the <fftw.h> header file. */
/* #undef HAVE_FFTW_H */

/* Define if fseeko (and presumably ftello) exists and is declared. */
#define HAVE_FSEEKO 1

/* Define to 1 if you have the <ft2build.h> header file. */
#define HAVE_FT2BUILD_H 1

/* Define to 1 if you have the `ftime' function. */
#define HAVE_FTIME 1

/* Define to 1 if you have the <g2c.h> header file. */
/* #undef HAVE_G2C_H */

/* define if GDAL is to be used */
#define HAVE_GDAL 1

/* define if GEOS is to be used */
#define HAVE_GEOS 1

/* Define to 1 if you have the <geos_c.h> header file. */
#define HAVE_GEOS_C_H 1

/* Define to 1 if you have the `gethostname' function. */
#define HAVE_GETHOSTNAME 1

/* Define to 1 if you have the `gettimeofday' function. */
#define HAVE_GETTIMEOFDAY 1

/* Define to 1 if you have the <GL/glu.h> header file. */
#define HAVE_GL_GLU_H 1

/* Define to 1 if you have the <GL/gl.h> header file. */
#define HAVE_GL_GL_H 1

/* Define to 1 if you have the <iconv.h> header file. */
#define HAVE_ICONV_H 1

/* define if "int64_t" is available */
#define HAVE_INT64_T 1

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* Define to 1 if you have the <langinfo.h> header file. */
#define HAVE_LANGINFO_H 1

/* define if we have LFS */
#define HAVE_LARGEFILES 1

/* define if ATLAS exists */
/* #undef HAVE_LIBATLAS */

/* define if BLAS exists */
#define HAVE_LIBBLAS 1

/* Define to 1 if you have the <libintl.h> header file. */
#define HAVE_LIBINTL_H 1

/* define if LAPACK exists */
#define HAVE_LIBLAPACK 1

/* define if liblas exists */
/* #undef HAVE_LIBLAS */

/* Define to 1 if you have the <liblas/capi/liblas.h> header file. */
/* #undef HAVE_LIBLAS_CAPI_LIBLAS_H */

/* Define to 1 if you have the <libpq-fe.h> header file. */
#define HAVE_LIBPQ_FE_H 1

/* Define to 1 if you have the <limits.h> header file. */
#define HAVE_LIMITS_H 1

/* define if "long long int" is available */
#define HAVE_LONG_LONG_INT 1

/* Define to 1 if you have the `lseek' function. */
#define HAVE_LSEEK 1

/* Define to 1 if you have the <mysql.h> header file. */
#define HAVE_MYSQL_H 1

/* Define to 1 if you have the `nanosleep' function. */
#define HAVE_NANOSLEEP 1

/* define if NetCDF exists */
#define HAVE_NETCDF 1

/* Define to 1 if you have the `nice' function. */
#define HAVE_NICE 1

/* define if OGR is to be used */
#define HAVE_OGR 1

/* Define to 1 if you have the <omp.h> header file. */
#define HAVE_OMP_H 1

/* Define to 1 if you have the <OpenCL/opencl.h> header file. */
/* #undef HAVE_OPENCL_OPENCL_H */

/* Define to 1 if you have the <OpenGL/glu.h> header file. */
/* #undef HAVE_OPENGL_GLU_H */

/* Define to 1 if you have the <OpenGL/gl.h> header file. */
/* #undef HAVE_OPENGL_GL_H */

/* define if glXCreatePbuffer exists */
#define HAVE_PBUFFERS 1

/* define if PDAL exists */
/* #undef HAVE_PDAL */

/* define if glXCreateGLXPixmap exists */
#define HAVE_PIXMAPS 1

/* Define to 1 if you have the <png.h> header file. */
#define HAVE_PNG_H 1

/* define if PostgreSQL is to be used */
#define HAVE_POSTGRES 1

/* define if PQcmdTuples in lpq */
#define HAVE_PQCMDTUPLES 1

/* Define to 1 if you have the <proj_api.h> header file. */
/* #undef HAVE_PROJ_API_H */

/* Define to 1 if you have the <proj.h> header file. */
#define HAVE_PROJ_H 1

/* Define to 1 if you have the <pthread.h> header file. */
/* #undef HAVE_PTHREAD_H */

/* Define to 1 if you have the `putenv' function. */
#define HAVE_PUTENV 1

/* Define to 1 if you have the <readline/history.h> header file. */
#define HAVE_READLINE_HISTORY_H 1

/* Define to 1 if you have the <readline/readline.h> header file. */
#define HAVE_READLINE_READLINE_H 1

/* Define to 1 if you have the <regex.h> header file. */
#define HAVE_REGEX_H 1

/* Define to 1 if you have the `setenv' function. */
#define HAVE_SETENV 1

/* Define to 1 if you have the `seteuid' function. */
#define HAVE_SETEUID 1

/* Define to 1 if you have the `setpriority' function. */
#define HAVE_SETPRIORITY 1

/* Define to 1 if you have the `setreuid' function. */
#define HAVE_SETREUID 1

/* Define to 1 if you have the `setruid' function. */
/* #undef HAVE_SETRUID */

/* define if socket() exists */
#define HAVE_SOCKET 1

/* define if SQLite is to be used */
#define HAVE_SQLITE 1

/* Define to 1 if you have the <sqlite3.h> header file. */
#define HAVE_SQLITE3_H 1

/* Define to 1 if you have the <sql.h> header file. */
#define HAVE_SQL_H 1

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdio.h> header file. */
#define HAVE_STDIO_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the <sys/ioctl.h> header file. */
#define HAVE_SYS_IOCTL_H 1

/* Define to 1 if you have the <sys/mtio.h> header file. */
#define HAVE_SYS_MTIO_H 1

/* Define to 1 if you have the <sys/resource.h> header file. */
#define HAVE_SYS_RESOURCE_H 1

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/timeb.h> header file. */
#define HAVE_SYS_TIMEB_H 1

/* Define to 1 if you have the <sys/time.h> header file. */
#define HAVE_SYS_TIME_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define to 1 if you have the <sys/utsname.h> header file. */
#define HAVE_SYS_UTSNAME_H 1

/* Define to 1 if you have the <termios.h> header file. */
#define HAVE_TERMIOS_H 1

/* Define to 1 if you have the <termio.h> header file. */
#define HAVE_TERMIO_H 1

/* Define to 1 if you have the <tiffio.h> header file. */
#define HAVE_TIFFIO_H 1

/* Define to 1 if you have the `time' function. */
#define HAVE_TIME 1

/* Define to 1 if you have the `uname' function. */
#define HAVE_UNAME 1

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* Define to 1 if you have the <values.h> header file. */
#define HAVE_VALUES_H 1

/* Define to 1 if you have the <windows.h> header file. */
/* #undef HAVE_WINDOWS_H */

/* Define to 1 if you have the <zlib.h> header file. */
#define HAVE_ZLIB_H 1

/* Define to 1 if you have the <zstd.h> header file. */
#define HAVE_ZSTD_H 1

/* define if OpenGL uses Aqua (MacOS X) */
/* #undef OPENGL_AQUA */

/* define if OpenGL uses Windows */
/* #undef OPENGL_WINDOWS */

/* define if OpenGL uses X11 */
#define OPENGL_X11 1

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT ""

/* Define to the full name of this package. */
#define PACKAGE_NAME ""

/* Define to the full name and version of this package. */
#define PACKAGE_STRING ""

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME ""

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION ""

/* Define to 1 if the `setpgrp' function requires zero arguments. */
#define SETPGRP_VOID 1

/* define for Windows static build */
/* #undef STATIC_BUILD */

/* Define to 1 if all of the C90 standard headers exist (not just the ones
   required in a freestanding environment). This macro is provided for
   backward compatibility; new code need not use it. */
#define STDC_HEADERS 1

/* Define to 1 if you can safely include both <sys/time.h> and <time.h>. This
   macro is obsolete. */
#define TIME_WITH_SYS_TIME 1

/* define if NLS requested */
#define USE_NLS 1

/* define if using old PROJ version 4 API */
/* #undef USE_PROJ4API */

/* Define to 1 if the X Window System is missing or not being used. */
/* #undef X_DISPLAY_MISSING */

/* Define to 1 if `lex' declares `yytext' as a `char *' by default, not a
   `char[]'. */
#define YYTEXT_POINTER 1

/* Number of bits in a file offset, on hosts where this is settable. */
/* #undef _FILE_OFFSET_BITS */

/* Define to make fseeko visible on some hosts (e.g. glibc 2.2). */
/* #undef _LARGEFILE_SOURCE */

/* Define for large files, on AIX-style hosts. */
/* #undef _LARGE_FILES */

/* enable threading extensions on Solaris */
/* #undef _POSIX_PTHREAD_SEMANTICS */

/* define _REENTRANT flag (for SunOS) */
/* #undef _REENTRANT */

/* Define to `int' if <sys/types.h> doesn't define. */
/* #undef gid_t */

/* Define to `long int' if <sys/types.h> does not define. */
/* #undef off_t */

/* Define to `int' if <sys/types.h> doesn't define. */
/* #undef uid_t */
