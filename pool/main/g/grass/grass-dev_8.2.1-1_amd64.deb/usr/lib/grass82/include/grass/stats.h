#ifndef GRASS_STATS_H
#define GRASS_STATS_H

#include <grass/gis.h>
#include <grass/raster.h>

#include <grass/defs/stats.h>

#endif
