var searchData=
[
  ['ftp_20operation_20attributes_588',['FTP Operation Attributes',['../group__globus__ftp__client__operationattr.html',1,'']]],
  ['ftp_20operations_589',['FTP Operations',['../group__globus__ftp__client__operations.html',1,'']]]
];
