var searchData=
[
  ['handle_478',['handle',['../structglobus__i__ftp__client__handle__t.html#a1ecca11b0271c44a81a03e561b7c751f',1,'globus_i_ftp_client_handle_t']]]
];
