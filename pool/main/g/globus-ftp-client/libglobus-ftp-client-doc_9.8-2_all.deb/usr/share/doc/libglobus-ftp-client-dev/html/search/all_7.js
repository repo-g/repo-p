var searchData=
[
  ['handle_256',['handle',['../structglobus__i__ftp__client__handle__t.html#a1ecca11b0271c44a81a03e561b7c751f',1,'globus_i_ftp_client_handle_t']]],
  ['handle_20attributes_257',['Handle Attributes',['../group__globus__ftp__client__handleattr.html',1,'']]],
  ['handle_20management_258',['Handle Management',['../group__globus__ftp__client__handle.html',1,'']]]
];
