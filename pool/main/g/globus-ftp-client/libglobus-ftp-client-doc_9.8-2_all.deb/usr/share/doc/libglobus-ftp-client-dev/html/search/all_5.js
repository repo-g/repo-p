var searchData=
[
  ['features_23',['features',['../structglobus__i__ftp__client__target__s.html#aa47278b4dbb4605edb75f62decb9f480',1,'globus_i_ftp_client_target_s']]],
  ['features_5fpointer_24',['features_pointer',['../structglobus__i__ftp__client__handle__t.html#a9620b4feb326150b0eee7b03f403dd80',1,'globus_i_ftp_client_handle_t']]],
  ['ftp_20operation_20attributes_25',['FTP Operation Attributes',['../group__globus__ftp__client__operationattr.html',1,'']]],
  ['ftp_20operations_26',['FTP Operations',['../group__globus__ftp__client__operations.html',1,'']]]
];
