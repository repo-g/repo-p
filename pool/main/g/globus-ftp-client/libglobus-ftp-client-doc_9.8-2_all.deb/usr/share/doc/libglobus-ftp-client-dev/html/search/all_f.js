var searchData=
[
  ['url_298',['url',['../structglobus__i__ftp__client__target__s.html#afade59fadea866a1327605e224b92294',1,'globus_i_ftp_client_target_s::url()'],['../structglobus__i__ftp__client__cache__entry__t.html#a6290735d5d060ee3b283271f89ce21f6',1,'globus_i_ftp_client_cache_entry_t::url()']]],
  ['url_5fcache_299',['url_cache',['../structglobus__i__ftp__client__handleattr__t.html#aaceded1b6d5e876ed91a2ae85bae4be0',1,'globus_i_ftp_client_handleattr_t']]],
  ['url_5fstring_300',['url_string',['../structglobus__i__ftp__client__target__s.html#a9312ceb80f2dde7e7abc7218a7124859',1,'globus_i_ftp_client_target_s']]],
  ['user_5fpointer_301',['user_pointer',['../structglobus__i__ftp__client__handle__t.html#aab3fe44c90f71f5639d78a317355d2e2',1,'globus_i_ftp_client_handle_t']]],
  ['utime_5ftime_302',['utime_time',['../structglobus__i__ftp__client__handle__t.html#a0fe72848e773fde5de9574fbf35e8220',1,'globus_i_ftp_client_handle_t']]]
];
