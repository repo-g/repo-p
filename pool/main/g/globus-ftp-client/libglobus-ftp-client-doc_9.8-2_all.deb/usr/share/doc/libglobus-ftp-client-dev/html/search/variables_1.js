var searchData=
[
  ['base_5foffset_456',['base_offset',['../structglobus__i__ftp__client__handle__t.html#a47138bdfa0fbb934325cf1160e1156d2',1,'globus_i_ftp_client_handle_t']]]
];
