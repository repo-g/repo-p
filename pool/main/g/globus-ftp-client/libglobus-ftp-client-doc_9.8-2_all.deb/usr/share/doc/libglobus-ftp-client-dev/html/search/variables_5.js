var searchData=
[
  ['features_474',['features',['../structglobus__i__ftp__client__target__s.html#aa47278b4dbb4605edb75f62decb9f480',1,'globus_i_ftp_client_target_s']]],
  ['features_5fpointer_475',['features_pointer',['../structglobus__i__ftp__client__handle__t.html#a9620b4feb326150b0eee7b03f403dd80',1,'globus_i_ftp_client_handle_t']]]
];
