var searchData=
[
  ['end_5foffset_21',['end_offset',['../structglobus__i__ftp__client__range__t.html#a6b34fab897a09cf7e5daef01946221ec',1,'globus_i_ftp_client_range_t']]],
  ['err_22',['err',['../structglobus__i__ftp__client__handle__t.html#aae5d35036f29727b211e1129b21667c7',1,'globus_i_ftp_client_handle_t']]]
];
