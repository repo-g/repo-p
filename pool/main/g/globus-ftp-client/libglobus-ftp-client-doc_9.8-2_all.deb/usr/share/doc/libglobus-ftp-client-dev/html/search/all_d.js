var searchData=
[
  ['size_5fpointer_289',['size_pointer',['../structglobus__i__ftp__client__handle__t.html#ad17b0c64fe1cac134b958c3b45ac6e1d',1,'globus_i_ftp_client_handle_t']]],
  ['source_290',['source',['../structglobus__i__ftp__client__data__target__t.html#a302393cc0a11786d42a007a1cea81f2f',1,'globus_i_ftp_client_data_target_t::source()'],['../structglobus__i__ftp__client__handle__t.html#a03af2879a3413d49f8a88c01fbf47658',1,'globus_i_ftp_client_handle_t::source()']]],
  ['source_5fsize_291',['source_size',['../structglobus__i__ftp__client__handle__t.html#aa17d0fd7070ae4c6613b7d564948a229',1,'globus_i_ftp_client_handle_t']]],
  ['source_5furl_292',['source_url',['../structglobus__i__ftp__client__handle__t.html#a0685a667ac4c896ef293c5e7024653d1',1,'globus_i_ftp_client_handle_t']]],
  ['src_5fop_5fqueue_293',['src_op_queue',['../structglobus__i__ftp__client__handle__t.html#a8d469e154e980681fb8b9b6238c3e7ca',1,'globus_i_ftp_client_handle_t']]],
  ['stalled_5fblocks_294',['stalled_blocks',['../structglobus__i__ftp__client__handle__t.html#a6e17c9d4514f2e09a8bdb219e38a0944',1,'globus_i_ftp_client_handle_t']]],
  ['state_295',['state',['../structglobus__i__ftp__client__handle__t.html#ab7a726fa3d0bc01dcf6ed2e44901e085',1,'globus_i_ftp_client_handle_t::state()'],['../structglobus__i__ftp__client__target__s.html#a53fadb205d7a391927a8b7d4e792f353',1,'globus_i_ftp_client_target_s::state()']]]
];
