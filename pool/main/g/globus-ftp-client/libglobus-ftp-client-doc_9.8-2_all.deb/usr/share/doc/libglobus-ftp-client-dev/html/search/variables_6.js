var searchData=
[
  ['globus_5fi_5fftp_5fclient_5fmodule_476',['globus_i_ftp_client_module',['../globus__ftp__client_8h.html#a68cd0c2cfa54d06003ebc378494d0089',1,'globus_ftp_client.c']]],
  ['gridftp2_477',['gridftp2',['../structglobus__i__ftp__client__handleattr__t.html#a8535aad3e0dda00654774bab25d9ef47',1,'globus_i_ftp_client_handleattr_t']]]
];
