var searchData=
[
  ['handle_20attributes_591',['Handle Attributes',['../group__globus__ftp__client__handleattr.html',1,'']]],
  ['handle_20management_592',['Handle Management',['../group__globus__ftp__client__handle.html',1,'']]]
];
