var searchData=
[
  ['globus_5fftp_5fclient_5ferror_5ft_572',['globus_ftp_client_error_t',['../globus__ftp__client_8h.html#af3624b97dcfb95217544b658d7a19d81',1,'globus_ftp_client.h']]],
  ['globus_5fftp_5fclient_5fplugin_5fcommand_5fmask_5ft_573',['globus_ftp_client_plugin_command_mask_t',['../group__globus__ftp__client__plugins.html#ga3a2339a2213742216f3ebb3b1a38c219',1,'globus_ftp_client_plugin.h']]],
  ['globus_5fftp_5fclient_5fprobed_5ffeature_5ft_574',['globus_ftp_client_probed_feature_t',['../group__globus__ftp__client__operations.html#ga51ebf6e3cc1c40e87193b8416cbf19dc',1,'globus_ftp_client.h']]],
  ['globus_5fftp_5fclient_5frestart_5ftype_5ft_575',['globus_ftp_client_restart_type_t',['../globus__ftp__client_8h.html#abdf8c772a129e1cb05d8253040ef24d4',1,'globus_ftp_client.h']]],
  ['globus_5fftp_5fclient_5ftristate_5ft_576',['globus_ftp_client_tristate_t',['../group__globus__ftp__client__operations.html#gae52d1000b926bae6436d61aeeaf68803',1,'globus_ftp_client.h']]]
];
