var searchData=
[
  ['netlogger_20throughput_20plugin_264',['Netlogger Throughput Plugin',['../group__globus__ftp__client__throughput__nl__plugin.html',1,'']]],
  ['notify_5fin_5fprogress_265',['notify_in_progress',['../structglobus__i__ftp__client__handle__t.html#a70dccf8ff254fe321f42629a889c5cb7',1,'globus_i_ftp_client_handle_t']]],
  ['num_5factive_5fblocks_266',['num_active_blocks',['../structglobus__i__ftp__client__handle__t.html#ab2b29f8709cc40f1e22adc7408ba3dc7',1,'globus_i_ftp_client_handle_t']]],
  ['num_5fpasv_5faddresses_267',['num_pasv_addresses',['../structglobus__i__ftp__client__handle__t.html#a9d69b8e7d5efa3be5755782243b17277',1,'globus_i_ftp_client_handle_t']]]
];
