var searchData=
[
  ['offset_487',['offset',['../structglobus__i__ftp__client__range__t.html#a7a5ee21a7a1cc9b9ddc23a7e0744db9d',1,'globus_i_ftp_client_range_t']]],
  ['op_488',['op',['../structglobus__i__ftp__client__handle__t.html#a718ddf4a57c66a9325e5d9e90b227556',1,'globus_i_ftp_client_handle_t']]],
  ['operation_489',['operation',['../structglobus__i__ftp__client__data__target__t.html#a26b29abec36fa33d7a300724ff32d5bd',1,'globus_i_ftp_client_data_target_t']]],
  ['owner_490',['owner',['../structglobus__i__ftp__client__target__s.html#ac28d6e88bb549636defec3377e4832e4',1,'globus_i_ftp_client_target_s']]]
];
