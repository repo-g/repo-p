var searchData=
[
  ['magic_479',['magic',['../structglobus__i__ftp__client__handle__t.html#a30f3145277a66f2d5b70501e7402ceff',1,'globus_i_ftp_client_handle_t']]],
  ['mask_480',['mask',['../structglobus__i__ftp__client__target__s.html#a8d9f89e71f6d1f1c9c2d15faa0061eb4',1,'globus_i_ftp_client_target_s']]],
  ['mlst_5fbuffer_5fpointer_481',['mlst_buffer_pointer',['../structglobus__i__ftp__client__handle__t.html#a0458d46b7187ecddc67db7af8a6d214b',1,'globus_i_ftp_client_handle_t']]],
  ['modification_5ftime_5fpointer_482',['modification_time_pointer',['../structglobus__i__ftp__client__handle__t.html#a6151620e1c5dbf3ef8dc1741682bc480',1,'globus_i_ftp_client_handle_t']]],
  ['mutex_483',['mutex',['../structglobus__i__ftp__client__handle__t.html#a1f1153e5ef040139bc06e3a68d4605a6',1,'globus_i_ftp_client_handle_t']]]
];
