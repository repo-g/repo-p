var searchData=
[
  ['cache_5fall_457',['cache_all',['../structglobus__i__ftp__client__handleattr__t.html#ad9fc12327178a3e18b6e6d741ec8024a',1,'globus_i_ftp_client_handleattr_t']]],
  ['cached_5fdata_5fconn_458',['cached_data_conn',['../structglobus__i__ftp__client__target__s.html#a8e6abb059a3ee07729c54413b4285049',1,'globus_i_ftp_client_target_s']]],
  ['callback_459',['callback',['../structglobus__i__ftp__client__handle__t.html#a955392aefe01266e12e6a81b77733438',1,'globus_i_ftp_client_handle_t']]],
  ['callback_5farg_460',['callback_arg',['../structglobus__i__ftp__client__handle__t.html#a64a5c55cff6ffa2793fae8993fc8ed4d',1,'globus_i_ftp_client_handle_t']]],
  ['checksum_461',['checksum',['../structglobus__i__ftp__client__handle__t.html#af41007822c45d6b1e90e0fb72226cb4a',1,'globus_i_ftp_client_handle_t']]],
  ['checksum_5foffset_462',['checksum_offset',['../structglobus__i__ftp__client__handle__t.html#ad4891f307726db4783fefba08c05ed51',1,'globus_i_ftp_client_handle_t']]],
  ['chgrp_5fgroup_463',['chgrp_group',['../structglobus__i__ftp__client__handle__t.html#aac86982604204bb9e8bed014eabdf358',1,'globus_i_ftp_client_handle_t']]],
  ['chmod_5ffile_5fmode_464',['chmod_file_mode',['../structglobus__i__ftp__client__handle__t.html#a103769962e056d4042db54f0e26d3e2c',1,'globus_i_ftp_client_handle_t']]],
  ['command_5fmask_465',['command_mask',['../structglobus__i__ftp__client__plugin__t.html#a7ce6f2c212986133eb3a7fec648bd514',1,'globus_i_ftp_client_plugin_t']]],
  ['control_5fhandle_466',['control_handle',['../structglobus__i__ftp__client__target__s.html#a5be124a2bc8a3a9417dd24779d0b6a03',1,'globus_i_ftp_client_target_s']]],
  ['copy_5ffunc_467',['copy_func',['../structglobus__i__ftp__client__plugin__t.html#a4dd0370ba4afcf5cd56209e7fc00652e',1,'globus_i_ftp_client_plugin_t']]]
];
