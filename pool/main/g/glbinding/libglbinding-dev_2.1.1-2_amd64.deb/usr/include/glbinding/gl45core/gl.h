#pragma once

#include <glbinding/nogl.h>

#include <glbinding/gl/extension.h>
#include <glbinding/gl45core/types.h>
#include <glbinding/gl45core/boolean.h>
#include <glbinding/gl45core/values.h>
#include <glbinding/gl45core/bitfield.h>
#include <glbinding/gl45core/enum.h>
#include <glbinding/gl45core/functions.h>
