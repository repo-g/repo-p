#warning __scm.h is gone, instead include <libguile.h>
