#warning validate.h is gone, instead include <libguile.h>
