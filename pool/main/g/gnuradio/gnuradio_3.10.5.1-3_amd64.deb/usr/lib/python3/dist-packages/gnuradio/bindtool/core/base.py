

class BindTool(object):

    target_bindings = 'pybind11'

    def __init__(self):
        pass
