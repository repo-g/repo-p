
#pragma once

#include <globjects/base/baselogging.h>

#include <globjects/glbindinglogging.h>
#include <globjects/glmlogging.h>

#include <globjects/objectlogging.h>
