var searchData=
[
  ['warning',['Warning',['../namespaceglobjects.html#a620b5a1e325880385c1fa89be8dca5f1a0eaadb4fcb48a0a0ed7bc9868be9fbaa',1,'globjects']]]
];
