var searchData=
[
  ['query',['Query',['../classglobjects_1_1_query.html',1,'globjects']]]
];
