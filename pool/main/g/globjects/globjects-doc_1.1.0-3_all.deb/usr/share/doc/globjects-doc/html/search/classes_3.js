var searchData=
[
  ['debugmessage',['DebugMessage',['../classglobjects_1_1_debug_message.html',1,'globjects']]]
];
