var searchData=
[
  ['critical',['Critical',['../namespaceglobjects.html#a620b5a1e325880385c1fa89be8dca5f1a278d01e5af56273bae1bb99a98b370cd',1,'globjects']]]
];
