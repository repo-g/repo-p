/**
 * \namespace globjects
 *
 * \brief Contains all the classes that wrap OpenGL functionality.
 *
 * TODO: Detailed documentation for globjects here.
 */
 