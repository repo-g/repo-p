var searchData=
[
  ['namedstring',['NamedString',['../classglobjects_1_1_named_string.html',1,'globjects']]]
];
