var searchData=
[
  ['query',['Query',['../classglobjects_1_1_query.html#a23d5e76595c296194f5b333ba404e8b3',1,'globjects::Query::Query()'],['../classglobjects_1_1_query.html#a111e010de48b32e69b1bd4038fb177d8',1,'globjects::Query::Query(IDResource *resource)']]]
];
