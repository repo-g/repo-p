var searchData=
[
  ['nameimplementation',['NameImplementation',['../classglobjects_1_1_object.html#ab11d1886a0f5cbc4ba4bd9c44d677abf',1,'globjects::Object']]]
];
