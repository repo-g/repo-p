var searchData=
[
  ['buffer',['Buffer',['../classglobjects_1_1_buffer.html',1,'globjects']]]
];
