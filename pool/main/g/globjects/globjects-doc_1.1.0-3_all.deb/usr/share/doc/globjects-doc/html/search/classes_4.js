var searchData=
[
  ['error',['Error',['../classglobjects_1_1_error.html',1,'globjects']]]
];
