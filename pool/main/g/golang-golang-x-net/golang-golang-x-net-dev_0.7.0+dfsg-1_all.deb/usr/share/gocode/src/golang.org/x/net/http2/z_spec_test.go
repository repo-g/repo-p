package http2
func covers(string, string) {}