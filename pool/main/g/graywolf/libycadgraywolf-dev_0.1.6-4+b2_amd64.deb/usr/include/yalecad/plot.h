#ifndef INC_PLOT_H
#define INC_PLOT_H

void Yplot_flush( char *gName );

#endif /* INC_PLOT_H */

