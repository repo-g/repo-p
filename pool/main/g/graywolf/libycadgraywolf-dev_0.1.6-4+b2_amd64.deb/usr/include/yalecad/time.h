#ifndef INC_TIME_H
#define INC_TIME_H

char *YcurTime( INT *time_in_sec );

#endif /* INC_TIME_H */

