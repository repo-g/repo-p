"""\
galileo.py Utility to synchronize a fitbit tracker with the fitbit server.
"""

__version__ = '0.5.1'
