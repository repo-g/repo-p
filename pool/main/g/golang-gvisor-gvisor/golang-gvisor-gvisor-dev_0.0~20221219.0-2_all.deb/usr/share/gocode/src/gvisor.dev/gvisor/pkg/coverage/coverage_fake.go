package coverage

import "io"

func Available() bool                          { return false }
func ClearCoverageData()                       {}
func ConsumeCoverageData(w io.Writer) int      { return 0 }
func EnableReport(w io.WriteCloser)            {}
func InitCoverageData()                        {}
func KcovSupported() bool                      { return false }
func Report() error                            { return nil }
func Symbolize(out io.Writer, pc uint64) error { return nil }
func WriteAllBlocks(out io.Writer) error       { return nil }
