/* Generated automatically by the program `genconfig'
   from the machine description file `md'.  */

#ifndef GCC_INSN_CONFIG_H
#define GCC_INSN_CONFIG_H

#define MAX_RECOG_OPERANDS 30
#define MAX_DUP_OPERANDS 4
#ifndef MAX_INSNS_PER_SPLIT
#define MAX_INSNS_PER_SPLIT 6
#endif
#define HAVE_cc0 0
#define CC0_P(X) ((X) ? 0 : 0)
#define HAVE_conditional_move 1
#define HAVE_conditional_execution 0
#define HAVE_lo_sum 0
#define HAVE_rotate 1
#define HAVE_peephole 0
#define HAVE_peephole2 1
#define MAX_INSNS_PER_PEEP2 2

#endif /* GCC_INSN_CONFIG_H */
