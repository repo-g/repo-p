#ifndef __DEMO_COMMON_H__
#define __DEMO_COMMON_H__

#include <string>

std::string demo_find_file(const std::string& base);

#endif /* __DEMO_COMMON_H__ */
