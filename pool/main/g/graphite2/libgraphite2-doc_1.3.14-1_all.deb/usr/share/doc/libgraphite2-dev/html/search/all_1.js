var searchData=
[
  ['extra_5fascent_1',['extra_ascent',['../structgr__faceinfo.html#ae25e5414284fd27cdb668f9c291cc23a',1,'gr_faceinfo']]],
  ['extra_5fdescent_2',['extra_descent',['../structgr__faceinfo.html#a3e478e33b992005022734b9586945283',1,'gr_faceinfo']]]
];
