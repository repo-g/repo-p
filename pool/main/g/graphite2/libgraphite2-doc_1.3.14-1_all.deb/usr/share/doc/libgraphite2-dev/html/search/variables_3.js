var searchData=
[
  ['justifies_299',['justifies',['../structgr__faceinfo.html#a88e5a717cba1b46733c18eabf4b102e6',1,'gr_faceinfo']]]
];
