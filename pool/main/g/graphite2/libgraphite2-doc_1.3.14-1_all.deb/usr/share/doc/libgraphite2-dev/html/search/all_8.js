var searchData=
[
  ['segment_2eh_210',['Segment.h',['../Segment_8h.html',1,'']]],
  ['size_211',['size',['../structgr__face__ops.html#a854352f53b148adc24983a58a1866d66',1,'gr_face_ops::size()'],['../structgr__font__ops.html#a854352f53b148adc24983a58a1866d66',1,'gr_font_ops::size()']]],
  ['space_5fcontextuals_212',['space_contextuals',['../structgr__faceinfo.html#a32aa2357ccaef0719f50ccd5e07c0806',1,'gr_faceinfo']]]
];
