var searchData=
[
  ['has_5fbidi_5fpass_205',['has_bidi_pass',['../structgr__faceinfo.html#a727f5658f7cae3677afd480e0449200e',1,'gr_faceinfo']]]
];
