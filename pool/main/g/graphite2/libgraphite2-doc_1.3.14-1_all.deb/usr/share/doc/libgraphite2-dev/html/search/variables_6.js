var searchData=
[
  ['size_302',['size',['../structgr__face__ops.html#a854352f53b148adc24983a58a1866d66',1,'gr_face_ops::size()'],['../structgr__font__ops.html#a854352f53b148adc24983a58a1866d66',1,'gr_font_ops::size()']]],
  ['space_5fcontextuals_303',['space_contextuals',['../structgr__faceinfo.html#a32aa2357ccaef0719f50ccd5e07c0806',1,'gr_faceinfo']]]
];
