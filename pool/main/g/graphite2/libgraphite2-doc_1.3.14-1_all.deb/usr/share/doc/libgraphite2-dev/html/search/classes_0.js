var searchData=
[
  ['gr_5fface_5fops_215',['gr_face_ops',['../structgr__face__ops.html',1,'']]],
  ['gr_5ffaceinfo_216',['gr_faceinfo',['../structgr__faceinfo.html',1,'']]],
  ['gr_5ffont_5fops_217',['gr_font_ops',['../structgr__font__ops.html',1,'']]]
];
