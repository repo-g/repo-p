/*

This module is experimental and incomplete. Please be careful.

The archive module provides a few `pault.ag/go/debian` compatable bindings
to read and write Debian apt archives.

*/
package archive
