package internal

import "time"

const RetryBackoff = 250 * time.Millisecond
