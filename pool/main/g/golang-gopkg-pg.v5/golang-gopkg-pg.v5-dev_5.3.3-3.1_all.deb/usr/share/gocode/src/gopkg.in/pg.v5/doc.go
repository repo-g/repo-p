/*
Package gopkg.in/pg.v5 implements a PostgreSQL client.
*/
package pg
