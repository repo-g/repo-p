// Copyright (c) 2018, Daniel Martí <mvdan@mvdan.cc>
// See LICENSE for licensing information

// Package expand contains code to perform various shell expansions.
package expand
