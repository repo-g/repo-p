var searchData=
[
  ['job_5fcontact_93',['job_contact',['../structglobus__gram__client__job__info__s.html#a376beb71ba0fd7c1a2cd113204de7bb3',1,'globus_gram_client_job_info_s']]],
  ['job_5fstate_94',['job_state',['../structglobus__gram__client__job__info__s.html#ac2d43ce5d2a6ee34fc24fde1f47b0bfe',1,'globus_gram_client_job_info_s']]]
];
