var searchData=
[
  ['globus_5fgram_5fclient_5fjob_5finfo_5fs_53',['globus_gram_client_job_info_s',['../structglobus__gram__client__job__info__s.html',1,'']]]
];
