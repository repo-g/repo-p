var searchData=
[
  ['protocol_5ferror_5fcode_52',['protocol_error_code',['../structglobus__gram__client__job__info__s.html#a52fc39d5063819bdc7e0b64b7cd8bf29',1,'globus_gram_client_job_info_s']]]
];
