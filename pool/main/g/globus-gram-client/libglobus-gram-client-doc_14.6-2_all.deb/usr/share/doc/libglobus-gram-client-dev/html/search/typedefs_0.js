var searchData=
[
  ['globus_5fgram_5fclient_5fattr_5ft_96',['globus_gram_client_attr_t',['../group__globus__gram__client__attr.html#gab906c3d70b18b429bac1b0ae8a7304da',1,'globus_gram_client.h']]],
  ['globus_5fgram_5fclient_5fcallback_5ffunc_5ft_97',['globus_gram_client_callback_func_t',['../group__globus__gram__client__callback.html#gab98145211b4bc74c47c37e08cc143308',1,'globus_gram_client.h']]],
  ['globus_5fgram_5fclient_5finfo_5fcallback_5ffunc_5ft_98',['globus_gram_client_info_callback_func_t',['../group__globus__gram__client__callback.html#ga3c8a32d5eb43971b589ed72bd8234cee',1,'globus_gram_client.h']]],
  ['globus_5fgram_5fclient_5fjob_5finfo_5ft_99',['globus_gram_client_job_info_t',['../group__globus__gram__client__callback.html#gae6f1a6411e476e044752e0059dc65328',1,'globus_gram_client.h']]],
  ['globus_5fgram_5fclient_5fnonblocking_5ffunc_5ft_100',['globus_gram_client_nonblocking_func_t',['../group__globus__gram__client__callback.html#gab9167cca69cc778556b39b50d800886f',1,'globus_gram_client.h']]]
];
