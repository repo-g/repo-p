var searchData=
[
  ['job_20state_20callbacks_49',['Job state callbacks',['../group__globus__gram__client__callback.html',1,'']]],
  ['job_5fcontact_50',['job_contact',['../structglobus__gram__client__job__info__s.html#a376beb71ba0fd7c1a2cd113204de7bb3',1,'globus_gram_client_job_info_s']]],
  ['job_5fstate_51',['job_state',['../structglobus__gram__client__job__info__s.html#ac2d43ce5d2a6ee34fc24fde1f47b0bfe',1,'globus_gram_client_job_info_s']]]
];
