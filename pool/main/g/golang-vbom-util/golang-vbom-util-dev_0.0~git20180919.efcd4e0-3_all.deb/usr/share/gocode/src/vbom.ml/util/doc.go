// Package util includes various small pieces of code.
package util // import "vbom.ml/util"
