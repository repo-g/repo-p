# Example that Shows how to Export an Answer Set to Excel

This example exports each predicate to different sheet in the file
`excel.xlsx`. To run the program, you need a clingo build with Python support
and the Python modules: `pandas`, `xlsxwriter`, `openpyxl`

## Example calls

    clingo excel-py.lp example.lp
