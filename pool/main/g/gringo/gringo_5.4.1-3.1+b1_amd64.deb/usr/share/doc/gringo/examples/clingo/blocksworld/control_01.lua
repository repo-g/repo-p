setdebugg(true)
-- setdebugs(false)
for i = 1, 4 do
  parts = {}
  addblock(0)
  incsolve()
end
addblock(1)
incsolve()
addblock(0)
incsolve()
