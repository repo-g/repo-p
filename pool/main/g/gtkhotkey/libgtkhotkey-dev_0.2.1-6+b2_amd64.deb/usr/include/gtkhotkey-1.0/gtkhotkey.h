
#ifndef __GTK_HOTKEY_H__
#define __GTK_HOTKEY_H__

#include <gtk-hotkey-info.h>
#include <gtk-hotkey-registry.h>
#include <gtk-hotkey-key-file-registry.h>
#include <gtk-hotkey-listener.h>
#include <gtk-hotkey-x11-listener.h>
#include <gtk-hotkey-error.h>

#endif /* __GTK_HOTKEY_H__ */
