var searchData=
[
  ['net_20manager_152',['Net Manager',['../group__globus__net__manager.html',1,'']]],
  ['net_20manager_20data_20types_153',['Net Manager Data Types',['../group__globus__net__manager__types.html',1,'']]]
];
