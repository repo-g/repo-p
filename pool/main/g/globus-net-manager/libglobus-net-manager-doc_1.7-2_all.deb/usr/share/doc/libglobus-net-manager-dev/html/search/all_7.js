var searchData=
[
  ['name_56',['name',['../structglobus__net__manager__attr__s.html#ac46eafc624f40f9b937131ec9c8fe863',1,'globus_net_manager_attr_s::name()'],['../structglobus__net__manager__s.html#a6ee3b71ed08496467b6c81ca64068d5c',1,'globus_net_manager_s::name()']]],
  ['net_20manager_57',['Net Manager',['../group__globus__net__manager.html',1,'']]],
  ['net_20manager_20data_20types_58',['Net Manager Data Types',['../group__globus__net__manager__types.html',1,'']]]
];
