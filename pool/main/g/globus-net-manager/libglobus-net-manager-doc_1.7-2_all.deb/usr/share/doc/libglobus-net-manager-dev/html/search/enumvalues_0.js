var searchData=
[
  ['globus_5fxio_5fnet_5fmanager_5fget_5ftask_5fid_146',['GLOBUS_XIO_NET_MANAGER_GET_TASK_ID',['../group__globus__xio__net__manager__driver.html#gga491e7f7eb8f1fab81eaa224b8b295c8fa1035e97bb7311355f5d6f731b544ef42',1,'globus_xio_net_manager_driver.h']]],
  ['globus_5fxio_5fnet_5fmanager_5fset_5ftask_5fid_147',['GLOBUS_XIO_NET_MANAGER_SET_TASK_ID',['../group__globus__xio__net__manager__driver.html#gga491e7f7eb8f1fab81eaa224b8b295c8fa66b5577d0d2951d4a693982bfecae84a',1,'globus_xio_net_manager_driver.h']]]
];
