var searchData=
[
  ['globus_5fnet_5fmanager_5fattr_5fs_79',['globus_net_manager_attr_s',['../structglobus__net__manager__attr__s.html',1,'']]],
  ['globus_5fnet_5fmanager_5fs_80',['globus_net_manager_s',['../structglobus__net__manager__s.html',1,'']]]
];
