var searchData=
[
  ['destroy_2ec_84',['destroy.c',['../attr_2destroy_8c.html',1,'(Global Namespace)'],['../context_2destroy_8c.html',1,'(Global Namespace)']]]
];
