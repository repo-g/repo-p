var searchData=
[
  ['destroy_2ec_5',['destroy.c',['../attr_2destroy_8c.html',1,'(Global Namespace)'],['../context_2destroy_8c.html',1,'(Global Namespace)']]]
];
