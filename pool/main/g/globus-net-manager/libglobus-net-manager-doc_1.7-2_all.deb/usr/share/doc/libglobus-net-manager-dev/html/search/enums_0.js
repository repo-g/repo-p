var searchData=
[
  ['globus_5fxio_5fnet_5fmanager_5fcntl_5ft_145',['globus_xio_net_manager_cntl_t',['../group__globus__xio__net__manager__driver.html#ga491e7f7eb8f1fab81eaa224b8b295c8f',1,'globus_xio_net_manager_driver.h']]]
];
