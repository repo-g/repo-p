var searchData=
[
  ['name_122',['name',['../structglobus__net__manager__attr__s.html#ac46eafc624f40f9b937131ec9c8fe863',1,'globus_net_manager_attr_s::name()'],['../structglobus__net__manager__s.html#a6ee3b71ed08496467b6c81ca64068d5c',1,'globus_net_manager_s::name()']]]
];
