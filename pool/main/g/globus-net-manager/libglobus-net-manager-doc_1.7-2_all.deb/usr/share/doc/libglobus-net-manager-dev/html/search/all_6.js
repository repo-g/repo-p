var searchData=
[
  ['init_2ec_55',['init.c',['../attr_2init_8c.html',1,'(Global Namespace)'],['../context_2init_8c.html',1,'(Global Namespace)']]]
];
