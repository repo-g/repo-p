
#=====================================================================
# $Log: __init__.py,v $
# Revision 1.1  2004-02-25 09:30:13  ncq
# - moved here from python-common
#
