#ifndef _SRC_GMM_GMM_ARCH_CONFIG_H
#define _SRC_GMM_GMM_ARCH_CONFIG_H 1
 
/* src/gmm/gmm_arch_config.h. Generated automatically at end of configure. */
/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.ac by autoheader.  */

/* Define to dummy `main' function (if any) required to link to the Fortran
   libraries. */
/* #undef GMM_FC_DUMMY_MAIN */

/* Define if F77 and FC dummy `main' functions are identical. */
/* #undef GMM_FC_DUMMY_MAIN_EQ_F77 */

/* enable openblas to be multithreaded */
#ifndef GMM_FORCE_SINGLE_THREAD_BLAS 
#define GMM_FORCE_SINGLE_THREAD_BLAS  1 
#endif

/* glibc backtrace function */
#ifndef GMM_HAVE_BACKTRACE 
#define GMM_HAVE_BACKTRACE  1 
#endif

/* Define to 1 if you have the <cmumps_c.h> header file. */
#ifndef GMM_HAVE_CMUMPS_C_H 
#define GMM_HAVE_CMUMPS_C_H  1 
#endif

/* Define to 1 if you have the <cxxabi.h> header file. */
#ifndef GMM_HAVE_CXXABI_H 
#define GMM_HAVE_CXXABI_H  1 
#endif

/* Define to 1 if you have the <dlfcn.h> header file. */
#ifndef GMM_HAVE_DLFCN_H 
#define GMM_HAVE_DLFCN_H  1 
#endif

/* Define to 1 if you have the <dmumps_c.h> header file. */
#ifndef GMM_HAVE_DMUMPS_C_H 
#define GMM_HAVE_DMUMPS_C_H  1 
#endif

/* glibc floating point exceptions control */
#ifndef GMM_HAVE_FEENABLEEXCEPT 
#define GMM_HAVE_FEENABLEEXCEPT  1 
#endif

/* Define to 1 if you have the <inttypes.h> header file. */
#ifndef GMM_HAVE_INTTYPES_H 
#define GMM_HAVE_INTTYPES_H  1 
#endif

/* Define to 1 if you have the `mpi_cxx' library (-lmpi_cxx). */
/* #undef GMM_HAVE_LIBMPI_CXX */

/* Define to 1 if you have the <libqhull/qhull_a.h> header file. */
#ifndef GMM_HAVE_LIBQHULL_QHULL_A_H 
#define GMM_HAVE_LIBQHULL_QHULL_A_H  1 
#endif

/* Define to 1 if you have the `superlu' library (-lsuperlu). */
#ifndef GMM_HAVE_LIBSUPERLU 
#define GMM_HAVE_LIBSUPERLU  1 
#endif

/* defined if the Metis library was found and is working */
/* #undef GMM_HAVE_METIS */

/* Define to 1 if you have the <metis.h> header file. */
/* #undef GMM_HAVE_METIS_H */

/* defined if the Metis library found is older than version 4 */
/* #undef GMM_HAVE_METIS_OLD_API */

/* Define if you have the MPI library. */
/* #undef GMM_HAVE_MPI */

/* gcc style __PRETTY_FUNCTION__ macro */
#ifndef GMM_HAVE_PRETTY_FUNCTION 
#define GMM_HAVE_PRETTY_FUNCTION  1 
#endif

/* defined if the qd library was found and is working */
/* #undef GMM_HAVE_QDLIB */

/* Define to 1 if you have the <smumps_c.h> header file. */
#ifndef GMM_HAVE_SMUMPS_C_H 
#define GMM_HAVE_SMUMPS_C_H  1 
#endif

/* Define to 1 if you have the <stdint.h> header file. */
#ifndef GMM_HAVE_STDINT_H 
#define GMM_HAVE_STDINT_H  1 
#endif

/* Define to 1 if you have the <stdio.h> header file. */
#ifndef GMM_HAVE_STDIO_H 
#define GMM_HAVE_STDIO_H  1 
#endif

/* Define to 1 if you have the <stdlib.h> header file. */
#ifndef GMM_HAVE_STDLIB_H 
#define GMM_HAVE_STDLIB_H  1 
#endif

/* Define to 1 if you have the <strings.h> header file. */
#ifndef GMM_HAVE_STRINGS_H 
#define GMM_HAVE_STRINGS_H  1 
#endif

/* Define to 1 if you have the <string.h> header file. */
#ifndef GMM_HAVE_STRING_H 
#define GMM_HAVE_STRING_H  1 
#endif

/* Define to 1 if you have the <superlu/colamd.h> header file. */
/* #undef GMM_HAVE_SUPERLU_COLAMD_H */

/* Define to 1 if you have the <superlu/slu_cdefs.h> header file. */
#ifndef GMM_HAVE_SUPERLU_SLU_CDEFS_H 
#define GMM_HAVE_SUPERLU_SLU_CDEFS_H  1 
#endif

/* Define to 1 if you have the <superlu/slu_Cnames.h> header file. */
#ifndef GMM_HAVE_SUPERLU_SLU_CNAMES_H 
#define GMM_HAVE_SUPERLU_SLU_CNAMES_H  1 
#endif

/* Define to 1 if you have the <superlu/slu_dcomplex.h> header file. */
#ifndef GMM_HAVE_SUPERLU_SLU_DCOMPLEX_H 
#define GMM_HAVE_SUPERLU_SLU_DCOMPLEX_H  1 
#endif

/* Define to 1 if you have the <superlu/slu_ddefs.h> header file. */
#ifndef GMM_HAVE_SUPERLU_SLU_DDEFS_H 
#define GMM_HAVE_SUPERLU_SLU_DDEFS_H  1 
#endif

/* Define to 1 if you have the <superlu/slu_scomplex.h> header file. */
#ifndef GMM_HAVE_SUPERLU_SLU_SCOMPLEX_H 
#define GMM_HAVE_SUPERLU_SLU_SCOMPLEX_H  1 
#endif

/* Define to 1 if you have the <superlu/slu_sdefs.h> header file. */
#ifndef GMM_HAVE_SUPERLU_SLU_SDEFS_H 
#define GMM_HAVE_SUPERLU_SLU_SDEFS_H  1 
#endif

/* Define to 1 if you have the <superlu/slu_zdefs.h> header file. */
#ifndef GMM_HAVE_SUPERLU_SLU_ZDEFS_H 
#define GMM_HAVE_SUPERLU_SLU_ZDEFS_H  1 
#endif

/* Define to 1 if you have the <sys/stat.h> header file. */
#ifndef GMM_HAVE_SYS_STAT_H 
#define GMM_HAVE_SYS_STAT_H  1 
#endif

/* Define to 1 if you have the <sys/times.h> header file. */
#ifndef GMM_HAVE_SYS_TIMES_H 
#define GMM_HAVE_SYS_TIMES_H  1 
#endif

/* Define to 1 if you have the <sys/types.h> header file. */
#ifndef GMM_HAVE_SYS_TYPES_H 
#define GMM_HAVE_SYS_TYPES_H  1 
#endif

/* Define to 1 if you have the <unistd.h> header file. */
#ifndef GMM_HAVE_UNISTD_H 
#define GMM_HAVE_UNISTD_H  1 
#endif

/* Define to 1 if you have the <zmumps_c.h> header file. */
#ifndef GMM_HAVE_ZMUMPS_C_H 
#define GMM_HAVE_ZMUMPS_C_H  1 
#endif

/* Define to the sub-directory where libtool stores uninstalled libraries. */
#ifndef GMM_LT_OBJDIR 
#define GMM_LT_OBJDIR  ".libs/" 
#endif

/* Major version number */
#ifndef GMM_MAJOR_VERSION 
#define GMM_MAJOR_VERSION  5 
#endif

/* Minor version number */
#ifndef GMM_MINOR_VERSION 
#define GMM_MINOR_VERSION  4 
#endif

/* Name of package */
#ifndef GMM_PACKAGE 
#define GMM_PACKAGE  "getfem" 
#endif

/* Define to the address where bug reports for this package should be sent. */
#ifndef GMM_PACKAGE_BUGREPORT 
#define GMM_PACKAGE_BUGREPORT  "" 
#endif

/* Define to the full name of this package. */
#ifndef GMM_PACKAGE_NAME 
#define GMM_PACKAGE_NAME  "getfem" 
#endif

/* Define to the full name and version of this package. */
#ifndef GMM_PACKAGE_STRING 
#define GMM_PACKAGE_STRING  "getfem 5.4.2" 
#endif

/* Define to the one symbol short name of this package. */
#ifndef GMM_PACKAGE_TARNAME 
#define GMM_PACKAGE_TARNAME  "getfem" 
#endif

/* Define to the home page for this package. */
#ifndef GMM_PACKAGE_URL 
#define GMM_PACKAGE_URL  "" 
#endif

/* Define to the version of this package. */
#ifndef GMM_PACKAGE_VERSION 
#define GMM_PACKAGE_VERSION  "5.4.2" 
#endif

/* Patch version number */
#ifndef GMM_PATCH_VERSION 
#define GMM_PATCH_VERSION  2 
#endif

/* defined if quad-doubles are to be used instead of double-double */
/* #undef GMM_QDLIB_USE_QUAD */

/* Define to 1 if all of the C90 standard headers exist (not just the ones
   required in a freestanding environment). This macro is provided for
   backward compatibility; new code need not use it. */
#ifndef GMM_STDC_HEADERS 
#define GMM_STDC_HEADERS  1 
#endif

/* Use blas with 64 bits integers */
/* #undef GMM_USE_BLAS64_INTERFACE */

/* Use rpc for getfem communication with matlab */
/* #undef GMM_USE_RPC */

/* Version number of package */
#ifndef GMM_VERSION 
#define GMM_VERSION  "5.4.2" 
#endif
 
/* once: _SRC_GMM_GMM_ARCH_CONFIG_H */
#endif
