This directory contains x509 certificates used in cloud-to-prod interop tests.
For tests within gRPC-Go repo, please use the files in testsdata/x509
directory.
