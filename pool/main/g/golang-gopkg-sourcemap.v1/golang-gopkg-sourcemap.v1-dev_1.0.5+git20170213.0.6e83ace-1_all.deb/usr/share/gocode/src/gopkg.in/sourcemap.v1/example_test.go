package sourcemap_test

import (
	"fmt"
	"io/ioutil"
	"net/http"

	"gopkg.in/sourcemap.v1"
)

func ExampleParse() {
	mapURL := "file:///usr/share/javascript/jquery/jquery.min.map"

	trans := &http.Transport{}
	trans.RegisterProtocol("file", http.NewFileTransport(http.Dir("/")))

	cli := &http.Client{Transport: trans}
	resp, err := cli.Get(mapURL)
	if err != nil {
		panic(err)
	}
	defer resp.Body.Close()

	b, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		panic(err)
	}

	smap, err := sourcemap.Parse(mapURL, b)
	if err != nil {
		panic(err)
	}

	line, column := 5, 6789
	file, fn, line, col, ok := smap.Source(line, column)
	fmt.Println(file, fn, line, col, ok)
}
