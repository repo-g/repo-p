//go:build !windows
// +build !windows

package ui

func setConsoleMode() {}

func resetConsoleMode() {}
