alternative configuration files for some commands, contributed by mrsmith

