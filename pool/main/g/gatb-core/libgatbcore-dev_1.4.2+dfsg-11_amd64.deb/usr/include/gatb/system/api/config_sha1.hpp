#define STR_GIT_SHA1 "notset"
