#include <string>
namespace gatb { namespace core { namespace debruijn { namespace impl  {

extern bool bcalm_logging;
extern unsigned long logging(std::string message);
}}}}
