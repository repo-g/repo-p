module Gem2Deb
  VERSION = '2.1'
end
