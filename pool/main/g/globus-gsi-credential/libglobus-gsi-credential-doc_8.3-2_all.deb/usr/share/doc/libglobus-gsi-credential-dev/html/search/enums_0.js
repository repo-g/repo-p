var searchData=
[
  ['globus_5fgsi_5fcred_5ferror_5ft_127',['globus_gsi_cred_error_t',['../group__globus__gsi__credential__constants.html#ga55de6d05cb3a23df694f225b1e2f1b98',1,'globus_gsi_cred_constants.h']]],
  ['globus_5fgsi_5fcred_5ftype_5ft_128',['globus_gsi_cred_type_t',['../group__globus__gsi__credential__constants.html#ga4c604d5349ee485ab8d3a81d8da89241',1,'globus_gsi_cred_constants.h']]]
];
