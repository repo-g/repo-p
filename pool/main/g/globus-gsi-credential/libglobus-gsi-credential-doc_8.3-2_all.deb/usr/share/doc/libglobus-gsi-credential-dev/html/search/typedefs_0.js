var searchData=
[
  ['globus_5fgsi_5fcred_5fhandle_5fattrs_5ft_125',['globus_gsi_cred_handle_attrs_t',['../group__globus__gsi__cred__handle__attrs.html#gac3a90cdd8e00d9890f4696a4ade91233',1,'globus_gsi_credential.h']]],
  ['globus_5fgsi_5fcred_5fhandle_5ft_126',['globus_gsi_cred_handle_t',['../group__globus__gsi__cred__handle.html#gab2702f6c6cea4d59ecea6835f184477b',1,'globus_gsi_credential.h']]]
];
