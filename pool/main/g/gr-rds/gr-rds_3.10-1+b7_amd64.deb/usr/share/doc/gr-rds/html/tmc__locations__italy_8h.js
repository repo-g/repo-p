var tmc__locations__italy_8h =
[
    [ "TMC_LOCATIONS_ITALIAN", "tmc__locations__italy_8h.html#a32e0080b52b121e70979ccb16e67eaf5", null ],
    [ "tmc_location_names_italian", "tmc__locations__italy_8h.html#acf3c349a54e3198a7db1fb65b387937d", null ]
];