var tmc__events_8h =
[
    [ "TMC_EVENT_LIST_LINES", "tmc__events_8h.html#a79a783b459c05c5cb1cdabd0124ce0c6", null ],
    [ "TMC_EVENTS", "tmc__events_8h.html#a7071f347d9d5c278abb542403321c44a", null ],
    [ "quantifier_types", "tmc__events_8h.html#a8ca46201db29bc3bb93227bfda4148af", null ],
    [ "tmc_event_code_index", "tmc__events_8h.html#a0de1e4883a0c9b7d1be2f8466f586d0f", null ],
    [ "tmc_events", "tmc__events_8h.html#a1ce175aa23f599d98e2aca968ea903af", null ]
];