from .anti_spam import AntiSpamPlugin  # type: ignore
