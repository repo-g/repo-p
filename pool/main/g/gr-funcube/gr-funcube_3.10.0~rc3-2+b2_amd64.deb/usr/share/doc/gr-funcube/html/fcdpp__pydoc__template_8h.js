var fcdpp__pydoc__template_8h =
[
    [ "D", "fcdpp__pydoc__template_8h.html#a74021f021dcdfbb22891787b79c5529d", null ],
    [ "__doc_gr_funcube_fcdpp", "fcdpp__pydoc__template_8h.html#a665c53b2a0bbced85ded8636cce46319", null ],
    [ "__doc_gr_funcube_fcdpp_fcdpp_0", "fcdpp__pydoc__template_8h.html#acbfc71748472a77add1562a30fc074fb", null ],
    [ "__doc_gr_funcube_fcdpp_fcdpp_1", "fcdpp__pydoc__template_8h.html#add5062c8c89412f50a1ec4d54e0c196f", null ],
    [ "__doc_gr_funcube_fcdpp_make", "fcdpp__pydoc__template_8h.html#ad65a87555627aee761aacada34f8a3c5", null ],
    [ "__doc_gr_funcube_fcdpp_set_freq", "fcdpp__pydoc__template_8h.html#a7a9bf8cc26df5024abe7a5b80263c924", null ],
    [ "__doc_gr_funcube_fcdpp_set_freq_corr", "fcdpp__pydoc__template_8h.html#a3d3ab28bbb6ca41e45a9dabe5ec4549a", null ],
    [ "__doc_gr_funcube_fcdpp_set_if_gain", "fcdpp__pydoc__template_8h.html#ae6798b9569f594817884d735daa6a715", null ],
    [ "__doc_gr_funcube_fcdpp_set_lna", "fcdpp__pydoc__template_8h.html#a5241c7240f2abccef90e9121c8a5bbd8", null ],
    [ "__doc_gr_funcube_fcdpp_set_mixer_gain", "fcdpp__pydoc__template_8h.html#ad60cd2eac04cbfdf795e7f50a6dfe6f3", null ]
];