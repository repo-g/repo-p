var classgr_1_1funcube_1_1fcd__control =
[
    [ "sptr", "classgr_1_1funcube_1_1fcd__control.html#a382a9d516cd03a9bf7a149650a45f9e0", null ],
    [ "make", "classgr_1_1funcube_1_1fcd__control.html#af18139e1bbe075a5925345c668c39d1b", null ],
    [ "set_dc_corr", "classgr_1_1funcube_1_1fcd__control.html#aa606bfddf40ccaa7b3c2783a1a113f7b", null ],
    [ "set_freq", "classgr_1_1funcube_1_1fcd__control.html#a3c73b0a2bd3bc9cb5cad19cfe05c3fd6", null ],
    [ "set_iq_corr", "classgr_1_1funcube_1_1fcd__control.html#af552e3773015708e815cbf1719ef8c06", null ],
    [ "set_lna_gain", "classgr_1_1funcube_1_1fcd__control.html#a306248a9e400ce1f99539e3489c490a7", null ],
    [ "set_mixer_gain", "classgr_1_1funcube_1_1fcd__control.html#a9292080022f324f4c3cdd4474f742fe2", null ]
];