var fcd__control__pydoc__template_8h =
[
    [ "D", "fcd__control__pydoc__template_8h.html#a74021f021dcdfbb22891787b79c5529d", null ],
    [ "__doc_gr_funcube_fcd_control", "fcd__control__pydoc__template_8h.html#a293ce3c0ad7291de722065d096f96701", null ],
    [ "__doc_gr_funcube_fcd_control_fcd_control_0", "fcd__control__pydoc__template_8h.html#ac1cb89f7ec15b0d008c7c944bb0b6d72", null ],
    [ "__doc_gr_funcube_fcd_control_fcd_control_1", "fcd__control__pydoc__template_8h.html#aabeb7a9005b7803b614919ab5e7357fa", null ],
    [ "__doc_gr_funcube_fcd_control_make", "fcd__control__pydoc__template_8h.html#ae13c22a97737a2e40d8db092dd0ccac1", null ],
    [ "__doc_gr_funcube_fcd_control_set_dc_corr", "fcd__control__pydoc__template_8h.html#acdbf976a815d9e4c5e410c878cfc9c45", null ],
    [ "__doc_gr_funcube_fcd_control_set_freq", "fcd__control__pydoc__template_8h.html#a344ed6710a3c0182e8c6913b5a96318f", null ],
    [ "__doc_gr_funcube_fcd_control_set_freq_corr", "fcd__control__pydoc__template_8h.html#a8023cdb2f42a0ccb0b89f553cc45634c", null ],
    [ "__doc_gr_funcube_fcd_control_set_iq_corr", "fcd__control__pydoc__template_8h.html#a3a81af469445f426e4dba2986d757972", null ],
    [ "__doc_gr_funcube_fcd_control_set_lna_gain", "fcd__control__pydoc__template_8h.html#abb1e6c65a1c520dff285370568f95d66", null ],
    [ "__doc_gr_funcube_fcd_control_set_mixer_gain", "fcd__control__pydoc__template_8h.html#ad06547fe4433ea7e42bc345a27d9da3d", null ]
];