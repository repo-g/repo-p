var classgr_1_1funcube_1_1fcd__control__impl =
[
    [ "fcd_control_impl", "classgr_1_1funcube_1_1fcd__control__impl.html#a13c32c49bc41f19aa00ef0bd42614223", null ],
    [ "~fcd_control_impl", "classgr_1_1funcube_1_1fcd__control__impl.html#a354f00af90ea614b551d2ae11549ca48", null ],
    [ "set_dc_corr", "classgr_1_1funcube_1_1fcd__control__impl.html#a7afc1714d2cc8cec894e44dd8f8ed33d", null ],
    [ "set_freq", "classgr_1_1funcube_1_1fcd__control__impl.html#a7c8e770df9df08de8b71cd6af5f73381", null ],
    [ "set_frequency_msg", "classgr_1_1funcube_1_1fcd__control__impl.html#ab19b33fe43b781da24069b4c23adc547", null ],
    [ "set_iq_corr", "classgr_1_1funcube_1_1fcd__control__impl.html#acb3355adf5d428d2580783252a8175aa", null ],
    [ "set_lna_gain", "classgr_1_1funcube_1_1fcd__control__impl.html#aa2d32dd055330cb0000fccda82162d78", null ],
    [ "set_mixer_gain", "classgr_1_1funcube_1_1fcd__control__impl.html#a44c4cb311bfae4173d5b236fb33eaea4", null ]
];