var fcd__pydoc__template_8h =
[
    [ "D", "fcd__pydoc__template_8h.html#a74021f021dcdfbb22891787b79c5529d", null ],
    [ "__doc_gr_funcube_fcd", "fcd__pydoc__template_8h.html#a7e4489bca281545af8531c660b06ddf4", null ],
    [ "__doc_gr_funcube_fcd_fcd_0", "fcd__pydoc__template_8h.html#a983985413748aab02d0f405c91160e25", null ],
    [ "__doc_gr_funcube_fcd_fcd_1", "fcd__pydoc__template_8h.html#a82b3c882fcf7bfa57bfc505d71a31701", null ],
    [ "__doc_gr_funcube_fcd_make", "fcd__pydoc__template_8h.html#a6f956829bbcd55772b436e762448aa0d", null ],
    [ "__doc_gr_funcube_fcd_set_dc_corr", "fcd__pydoc__template_8h.html#aab486356a5af5dc35b5f3f9227de40bb", null ],
    [ "__doc_gr_funcube_fcd_set_freq", "fcd__pydoc__template_8h.html#a724824439411c037804c52570206d941", null ],
    [ "__doc_gr_funcube_fcd_set_freq_corr", "fcd__pydoc__template_8h.html#afe2492220c29fe85acb0a7d6687ecacc", null ],
    [ "__doc_gr_funcube_fcd_set_iq_corr", "fcd__pydoc__template_8h.html#a4bbf5def4c3fbe9d6030cb384cf894c1", null ],
    [ "__doc_gr_funcube_fcd_set_lna_gain", "fcd__pydoc__template_8h.html#a1f074996a95b74dd9f7ac80156572980", null ],
    [ "__doc_gr_funcube_fcd_set_mixer_gain", "fcd__pydoc__template_8h.html#a73e85a65a9a90b7beec05104602b03ec", null ]
];