var annotated_dup =
[
    [ "gr", "namespacegr.html", [
      [ "funcube", "namespacegr_1_1funcube.html", [
        [ "fcd", "classgr_1_1funcube_1_1fcd.html", "classgr_1_1funcube_1_1fcd" ],
        [ "fcd_control", "classgr_1_1funcube_1_1fcd__control.html", "classgr_1_1funcube_1_1fcd__control" ],
        [ "fcd_control_impl", "classgr_1_1funcube_1_1fcd__control__impl.html", "classgr_1_1funcube_1_1fcd__control__impl" ],
        [ "fcd_impl", "classgr_1_1funcube_1_1fcd__impl.html", "classgr_1_1funcube_1_1fcd__impl" ],
        [ "fcdpp", "classgr_1_1funcube_1_1fcdpp.html", "classgr_1_1funcube_1_1fcdpp" ],
        [ "fcdpp_control", "classgr_1_1funcube_1_1fcdpp__control.html", "classgr_1_1funcube_1_1fcdpp__control" ],
        [ "fcdpp_control_impl", "classgr_1_1funcube_1_1fcdpp__control__impl.html", "classgr_1_1funcube_1_1fcdpp__control__impl" ],
        [ "fcdpp_impl", "classgr_1_1funcube_1_1fcdpp__impl.html", "classgr_1_1funcube_1_1fcdpp__impl" ]
      ] ]
    ] ]
];