var classgr_1_1funcube_1_1fcdpp__impl =
[
    [ "fcdpp_impl", "classgr_1_1funcube_1_1fcdpp__impl.html#a4b47aaa7e125d726be58a7cd4b3e640f", null ],
    [ "~fcdpp_impl", "classgr_1_1funcube_1_1fcdpp__impl.html#a036b3ed3f97cfeb47322548c942f98d5", null ],
    [ "set_freq", "classgr_1_1funcube_1_1fcdpp__impl.html#a2d617efa9940fc7d002a88b3d44fb569", null ],
    [ "set_freq_corr", "classgr_1_1funcube_1_1fcdpp__impl.html#afa017265e4cb5b35d346ba188f0b803e", null ],
    [ "set_if_gain", "classgr_1_1funcube_1_1fcdpp__impl.html#a663428e7bd7c77660a6587744f668da1", null ],
    [ "set_lna", "classgr_1_1funcube_1_1fcdpp__impl.html#acf3b4e1fd9c19b0476105e5069804287", null ],
    [ "set_mixer_gain", "classgr_1_1funcube_1_1fcdpp__impl.html#a7af1d2d5a5069fb46e8b9c899d95ab0f", null ]
];