var classgr_1_1funcube_1_1fcdpp__control =
[
    [ "sptr", "classgr_1_1funcube_1_1fcdpp__control.html#a631b3acd4fd0032a852ced9eb35341c9", null ],
    [ "make", "classgr_1_1funcube_1_1fcdpp__control.html#aa8c5b50c7aff8f6aa4401ad398505860", null ],
    [ "set_freq", "classgr_1_1funcube_1_1fcdpp__control.html#a8aa2bc79f418ad52792c61e5f19f7b41", null ],
    [ "set_if_gain", "classgr_1_1funcube_1_1fcdpp__control.html#ab0514ffac47aece66d6a061207d706be", null ],
    [ "set_lna", "classgr_1_1funcube_1_1fcdpp__control.html#a15d2a7c78391067f7a49ccef81376783", null ],
    [ "set_mixer_gain", "classgr_1_1funcube_1_1fcdpp__control.html#a91329845d5200192e527a6b9d15a2da4", null ]
];