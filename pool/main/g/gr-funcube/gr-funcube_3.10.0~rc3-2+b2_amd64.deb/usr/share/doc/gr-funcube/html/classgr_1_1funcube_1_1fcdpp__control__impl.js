var classgr_1_1funcube_1_1fcdpp__control__impl =
[
    [ "fcdpp_control_impl", "classgr_1_1funcube_1_1fcdpp__control__impl.html#a9763201b17dfa55de0690a46191efa9d", null ],
    [ "~fcdpp_control_impl", "classgr_1_1funcube_1_1fcdpp__control__impl.html#a4249bd6df759e7f98f39e8e88b4e3a4f", null ],
    [ "set_freq", "classgr_1_1funcube_1_1fcdpp__control__impl.html#a84fedd0aa5444473dc22a19ef9256eea", null ],
    [ "set_frequency_msg", "classgr_1_1funcube_1_1fcdpp__control__impl.html#a27daff237a67d88193eb6fb9485f97cd", null ],
    [ "set_if_gain", "classgr_1_1funcube_1_1fcdpp__control__impl.html#a2d97217cab27b631714e5a50823b8bc0", null ],
    [ "set_lna", "classgr_1_1funcube_1_1fcdpp__control__impl.html#a3ed65b786c208157135f33c736ae644a", null ],
    [ "set_mixer_gain", "classgr_1_1funcube_1_1fcdpp__control__impl.html#a9f765aa2b3a8b817dbd00341a6b2db24", null ]
];