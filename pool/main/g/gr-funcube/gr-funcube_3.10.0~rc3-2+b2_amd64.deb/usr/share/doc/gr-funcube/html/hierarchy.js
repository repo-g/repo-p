var hierarchy =
[
    [ "gr::block", null, [
      [ "gr::funcube::fcd_control", "classgr_1_1funcube_1_1fcd__control.html", [
        [ "gr::funcube::fcd_control_impl", "classgr_1_1funcube_1_1fcd__control__impl.html", null ]
      ] ],
      [ "gr::funcube::fcdpp_control", "classgr_1_1funcube_1_1fcdpp__control.html", [
        [ "gr::funcube::fcdpp_control_impl", "classgr_1_1funcube_1_1fcdpp__control__impl.html", null ]
      ] ]
    ] ],
    [ "gr::hier_block2", null, [
      [ "gr::funcube::fcd", "classgr_1_1funcube_1_1fcd.html", [
        [ "gr::funcube::fcd_impl", "classgr_1_1funcube_1_1fcd__impl.html", null ]
      ] ],
      [ "gr::funcube::fcdpp", "classgr_1_1funcube_1_1fcdpp.html", [
        [ "gr::funcube::fcdpp_impl", "classgr_1_1funcube_1_1fcdpp__impl.html", null ]
      ] ]
    ] ]
];