var classgr_1_1funcube_1_1fcd =
[
    [ "sptr", "classgr_1_1funcube_1_1fcd.html#a30a347cd4596270d4a6e91059b514bc0", null ],
    [ "make", "classgr_1_1funcube_1_1fcd.html#a1369adc40d1804a67cf51344601cb5c9", null ],
    [ "set_dc_corr", "classgr_1_1funcube_1_1fcd.html#ad9358acfa0132ef2cdb2ad1d143a9426", null ],
    [ "set_freq", "classgr_1_1funcube_1_1fcd.html#a26e41351ab08726370b0704db663f2b2", null ],
    [ "set_freq_corr", "classgr_1_1funcube_1_1fcd.html#a2feb133887449d4a3c5dc3cb409c8b27", null ],
    [ "set_iq_corr", "classgr_1_1funcube_1_1fcd.html#a9201ac48274faca67dd11073f6ad43c7", null ],
    [ "set_lna_gain", "classgr_1_1funcube_1_1fcd.html#ab607449d1e8bf2e02e6609432e847096", null ],
    [ "set_mixer_gain", "classgr_1_1funcube_1_1fcd.html#ad08fd4f427263323946a09c7eb24d252", null ]
];