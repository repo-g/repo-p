var fcdpp__control__pydoc__template_8h =
[
    [ "D", "fcdpp__control__pydoc__template_8h.html#a74021f021dcdfbb22891787b79c5529d", null ],
    [ "__doc_gr_funcube_fcdpp_control", "fcdpp__control__pydoc__template_8h.html#a2e2a6f639d0e4ef0303f061458613e44", null ],
    [ "__doc_gr_funcube_fcdpp_control_fcdpp_control_0", "fcdpp__control__pydoc__template_8h.html#a248e2949db83f814f006a7198c04a60f", null ],
    [ "__doc_gr_funcube_fcdpp_control_fcdpp_control_1", "fcdpp__control__pydoc__template_8h.html#af39923ba2877e201aa15cb47669876eb", null ],
    [ "__doc_gr_funcube_fcdpp_control_make", "fcdpp__control__pydoc__template_8h.html#aa5b2bc938bfceca6e9fdd4781b1174f3", null ],
    [ "__doc_gr_funcube_fcdpp_control_set_freq", "fcdpp__control__pydoc__template_8h.html#a1da63fab3450ec627ad85dda859fa2c3", null ],
    [ "__doc_gr_funcube_fcdpp_control_set_if_gain", "fcdpp__control__pydoc__template_8h.html#a3d0d1816831d851f6d84d9056cefaf2b", null ],
    [ "__doc_gr_funcube_fcdpp_control_set_lna", "fcdpp__control__pydoc__template_8h.html#a307ab8e5f6f21c82ac7eb2fb9c6e73d3", null ],
    [ "__doc_gr_funcube_fcdpp_control_set_mixer_gain", "fcdpp__control__pydoc__template_8h.html#ad1e5cebbd83a0c51651448b87585dea2", null ]
];