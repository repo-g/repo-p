var classgr_1_1funcube_1_1fcd__impl =
[
    [ "fcd_impl", "classgr_1_1funcube_1_1fcd__impl.html#a4bdd4d64d0a03ae9234f755b91bf3208", null ],
    [ "~fcd_impl", "classgr_1_1funcube_1_1fcd__impl.html#a57d66130b56a22a25ee03f07a2a2ebb7", null ],
    [ "set_dc_corr", "classgr_1_1funcube_1_1fcd__impl.html#a2fffafe988c2c8914c0ed6892a4f603a", null ],
    [ "set_freq", "classgr_1_1funcube_1_1fcd__impl.html#a58879e22292de8c4a5e732fb73134270", null ],
    [ "set_freq_corr", "classgr_1_1funcube_1_1fcd__impl.html#a791a0c6252a8913e9cfa3fd09e79cfae", null ],
    [ "set_iq_corr", "classgr_1_1funcube_1_1fcd__impl.html#ad4f4aa52592b1e05abe595e92795fb07", null ],
    [ "set_lna_gain", "classgr_1_1funcube_1_1fcd__impl.html#ab84081782537ab5f348d25fbc0019e68", null ],
    [ "set_mixer_gain", "classgr_1_1funcube_1_1fcd__impl.html#a0f11771952d9852baf56bcf321edce5e", null ]
];