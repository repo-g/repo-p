var classgr_1_1funcube_1_1fcdpp =
[
    [ "sptr", "classgr_1_1funcube_1_1fcdpp.html#a194eab90a9d379c45448aab82a4bb68d", null ],
    [ "make", "classgr_1_1funcube_1_1fcdpp.html#a7d3e52cf7d0320e10d00906375c93ddb", null ],
    [ "set_freq", "classgr_1_1funcube_1_1fcdpp.html#ac57c7fb255caad82578a3da50aa212fc", null ],
    [ "set_freq_corr", "classgr_1_1funcube_1_1fcdpp.html#ac605fed28dcd3459ea146ae053242780", null ],
    [ "set_if_gain", "classgr_1_1funcube_1_1fcdpp.html#a6775abc3f9eefc097e3b836b55b80f3b", null ],
    [ "set_lna", "classgr_1_1funcube_1_1fcdpp.html#add01fd273c37524bb401050d28e46dad", null ],
    [ "set_mixer_gain", "classgr_1_1funcube_1_1fcdpp.html#ab03c61a7be9bf421422e2ca1c9813d22", null ]
];