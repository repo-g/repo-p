#ifndef INC_SemanticWalker_hpp_
#define INC_SemanticWalker_hpp_

#include <antlr/config.hpp>
#include "SemanticWalkerTokenTypes.hpp"
/* $ANTLR 2.7.7 (20190904): "semantic.g" -> "SemanticWalker.hpp"$ */
#include <antlr/TreeParser.hpp>


  #include "GPTDisplay.hpp"
  #include "PortugolAST.hpp"
  #include "SemanticEval.hpp"
  #include "SymbolTable.hpp"

  #include <list>
  
  using namespace std;

class CUSTOM_API SemanticWalker : public ANTLR_USE_NAMESPACE(antlr)TreeParser, public SemanticWalkerTokenTypes
{

  public:
    SemanticWalker(SymbolTable& st)
      : evaluator(st) {
    }

  private:
    SemanticEval evaluator;
public:
#if 0
// constructor creation turned of with 'noConstructor' option
	SemanticWalker();
#endif
	static void initializeASTFactory( ANTLR_USE_NAMESPACE(antlr)ASTFactory& factory );
	int getNumTokens() const
	{
		return SemanticWalker::NUM_TOKENS;
	}
	const char* getTokenName( int type ) const
	{
		if( type > getNumTokens() ) return 0;
		return SemanticWalker::tokenNames[type];
	}
	const char* const* getTokenNames() const
	{
		return SemanticWalker::tokenNames;
	}
	public: void algoritmo(RefPortugolAST _t);
	public: void variaveis(RefPortugolAST _t);
	public: void func_proto(RefPortugolAST _t);
	public: void inicio(RefPortugolAST _t);
	public: void func_decl(RefPortugolAST _t);
	public: pair<int, list<RefPortugolAST> >   primitivo(RefPortugolAST _t);
	public: pair< pair<int, list<int> >, list<RefPortugolAST> >  matriz(RefPortugolAST _t);
	public: int  tipo_prim(RefPortugolAST _t);
	public: pair<int, list<int> >  tipo_matriz(RefPortugolAST _t);
	public: void stm(RefPortugolAST _t);
	public: void stm_attr(RefPortugolAST _t);
	public: ExpressionValue  fcall(RefPortugolAST _t);
	public: void stm_ret(RefPortugolAST _t);
	public: void stm_se(RefPortugolAST _t);
	public: void stm_enquanto(RefPortugolAST _t);
	public: void stm_repita(RefPortugolAST _t);
	public: void stm_para(RefPortugolAST _t);
	public: ExpressionValue  lvalue(RefPortugolAST _t);
	public: ExpressionValue  expr(RefPortugolAST _t);
	public: void passo(RefPortugolAST _t);
	public: ExpressionValue  element(RefPortugolAST _t);
	public: ExpressionValue  literal(RefPortugolAST _t);
	public: void ret_type(RefPortugolAST _t,
		Funcao& f
	);
public:
	ANTLR_USE_NAMESPACE(antlr)RefAST getAST()
	{
		return ANTLR_USE_NAMESPACE(antlr)RefAST(returnAST);
	}
	
protected:
	RefPortugolAST returnAST;
	RefPortugolAST _retTree;
private:
	static const char* tokenNames[];
#ifndef NO_STATIC_CONSTS
	static const int NUM_TOKENS = 91;
#else
	enum {
		NUM_TOKENS = 91
	};
#endif
	
	static const unsigned long _tokenSet_0_data_[];
	static const ANTLR_USE_NAMESPACE(antlr)BitSet _tokenSet_0;
	static const unsigned long _tokenSet_1_data_[];
	static const ANTLR_USE_NAMESPACE(antlr)BitSet _tokenSet_1;
};

#endif /*INC_SemanticWalker_hpp_*/
