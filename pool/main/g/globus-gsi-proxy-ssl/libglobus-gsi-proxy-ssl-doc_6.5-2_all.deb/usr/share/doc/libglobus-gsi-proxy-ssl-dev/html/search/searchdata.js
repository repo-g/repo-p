var indexSectionsWithContent =
{
  0: "gp",
  1: "p",
  2: "p",
  3: "gp",
  4: "g"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "groups",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Modules",
  4: "Pages"
};

