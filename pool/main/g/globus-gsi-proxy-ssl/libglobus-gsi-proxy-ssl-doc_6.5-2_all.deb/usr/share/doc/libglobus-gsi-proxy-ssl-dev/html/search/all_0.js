var searchData=
[
  ['globus_20gsi_20proxy_20ssl_20api_0',['Globus GSI Proxy SSL API',['../group__globus__gsi__proxy__ssl__api.html',1,'(Global Namespace)'],['../index.html',1,'(Global Namespace)']]]
];
