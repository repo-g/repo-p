/*
 *  lgl-str.h
 *  Copyright (C) 2007-2010  Jim Evins <evins@snaught.com>.
 *
 *  This file is part of libglabels.
 *
 *  libglabels is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  libglabels is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with libglabels.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef __LGL_STR_H__
#define __LGL_STR_H__

#include <glib.h>

G_BEGIN_DECLS

gint   lgl_str_utf8_casecmp    (const gchar *s1,
                                const gchar *s2);

gint   lgl_str_part_name_cmp   (const gchar *s1,
                                const gchar *s2);

gchar *lgl_str_format_fraction (gdouble      x);

G_END_DECLS


#endif /* __LGL_STR_H__ */



/*
 * Local Variables:       -- emacs
 * mode: C                -- emacs
 * c-basic-offset: 8      -- emacs
 * tab-width: 8           -- emacs
 * indent-tabs-mode: nil  -- emacs
 * End:                   -- emacs
 */
