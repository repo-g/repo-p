package pkg

func fn() {} //@ used("fn", false), used_test("fn", true)
