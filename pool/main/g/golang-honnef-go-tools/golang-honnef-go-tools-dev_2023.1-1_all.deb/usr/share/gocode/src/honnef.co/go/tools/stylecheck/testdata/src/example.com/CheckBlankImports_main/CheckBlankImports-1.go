// Package pkg ...
package main

import _ "fmt"
