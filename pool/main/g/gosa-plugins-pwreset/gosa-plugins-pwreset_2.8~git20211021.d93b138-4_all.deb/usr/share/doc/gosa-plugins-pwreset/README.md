# Password Management Add-On for GOsa²

Password management and reset tool for GOsa². Administratively
mass-reset user passwords based on various approaches. New
passwords can be auto-generated or uploaded in CSV format.

GOsa² is a combination of system-administrator and end-user web
interface, designed to handle LDAP based setups.

The  GOsa² Password Management Add-On is licensed under GPL-2+,
for details see the AUTHORS.txt and COPYING files.
