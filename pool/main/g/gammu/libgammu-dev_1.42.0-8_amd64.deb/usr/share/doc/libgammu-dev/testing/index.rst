.. _testing:

Testing Gammu
=============

.. toctree::
    :maxdepth: 2

    testsuite
    dummy-driver

