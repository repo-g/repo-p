<?
## to make everything work, you must schedule this file to run periodically
## I crontabbed this sript to run every 30 secs
require('config.php');
$teste = $gammu->processnew();
?>