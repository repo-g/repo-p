var searchData=
[
  ['globus_5fgsi_5fauthz_5fcallout_5fauthz_5fcallout_5ferror_14',['GLOBUS_GSI_AUTHZ_CALLOUT_AUTHZ_CALLOUT_ERROR',['../group__globus__gsi__authz__callout__error.html#ggaa749cbe5e481b6a767ad80b55832ab98a6e1b31c002372e10ae65b812e70be9b1',1,'globus_gsi_authz_callout_error.h']]],
  ['globus_5fgsi_5fauthz_5fcallout_5fauthz_5fdenied_5fby_5fcallout_15',['GLOBUS_GSI_AUTHZ_CALLOUT_AUTHZ_DENIED_BY_CALLOUT',['../group__globus__gsi__authz__callout__error.html#ggaa749cbe5e481b6a767ad80b55832ab98a2a80ea1c4288d1f8d636fc68a7e90a6d',1,'globus_gsi_authz_callout_error.h']]],
  ['globus_5fgsi_5fauthz_5fcallout_5fbad_5fargument_5ferror_16',['GLOBUS_GSI_AUTHZ_CALLOUT_BAD_ARGUMENT_ERROR',['../group__globus__gsi__authz__callout__error.html#ggaa749cbe5e481b6a767ad80b55832ab98af8795a413edb79028f83f6dd25496d13',1,'globus_gsi_authz_callout_error.h']]],
  ['globus_5fgsi_5fauthz_5fcallout_5fconfiguration_5ferror_17',['GLOBUS_GSI_AUTHZ_CALLOUT_CONFIGURATION_ERROR',['../group__globus__gsi__authz__callout__error.html#ggaa749cbe5e481b6a767ad80b55832ab98adb3b14d7910fbbe80f75da50cd76f8a1',1,'globus_gsi_authz_callout_error.h']]],
  ['globus_5fgsi_5fauthz_5fcallout_5fcredential_5ferror_18',['GLOBUS_GSI_AUTHZ_CALLOUT_CREDENTIAL_ERROR',['../group__globus__gsi__authz__callout__error.html#ggaa749cbe5e481b6a767ad80b55832ab98a8e1b5163928021e52c9fd63e6e1ff083',1,'globus_gsi_authz_callout_error.h']]],
  ['globus_5fgsi_5fauthz_5fcallout_5fsystem_5ferror_19',['GLOBUS_GSI_AUTHZ_CALLOUT_SYSTEM_ERROR',['../group__globus__gsi__authz__callout__error.html#ggaa749cbe5e481b6a767ad80b55832ab98a7e363d6ec9beb90fc8baab27ac099480',1,'globus_gsi_authz_callout_error.h']]]
];
