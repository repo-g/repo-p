var searchData=
[
  ['globus_5fgsi_5fauthz_5fcallout_5ferror_5ft_13',['globus_gsi_authz_callout_error_t',['../group__globus__gsi__authz__callout__error.html#gaa749cbe5e481b6a767ad80b55832ab98',1,'globus_gsi_authz_callout_error.h']]]
];
