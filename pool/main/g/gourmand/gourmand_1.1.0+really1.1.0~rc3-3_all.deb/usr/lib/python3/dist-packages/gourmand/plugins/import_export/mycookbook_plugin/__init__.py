from . import mycookbook_exporter_plugin, mycookbook_importer_plugin

plugins = [mycookbook_exporter_plugin.MCBExporterPlugin,
           mycookbook_importer_plugin.MCBPlugin
           ]
