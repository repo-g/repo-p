from . import shopping_key_editor_plugin

plugins = [shopping_key_editor_plugin.KeyEditorPlugin]
