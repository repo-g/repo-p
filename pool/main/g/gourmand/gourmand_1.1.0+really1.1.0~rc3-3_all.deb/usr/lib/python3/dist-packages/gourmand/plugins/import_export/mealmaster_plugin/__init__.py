from . import mealmaster_exporter_plugin, mealmaster_importer_plugin

plugins = [mealmaster_exporter_plugin.MealmasterExporterPlugin,
           mealmaster_importer_plugin.MealmasterImporterPlugin
           ]
