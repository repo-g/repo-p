from gi import require_version

require_version("Gdk", "3.0")
require_version("Gst", "1.0")
require_version("Gtk", "3.0")
require_version("Pango", "1.0")
