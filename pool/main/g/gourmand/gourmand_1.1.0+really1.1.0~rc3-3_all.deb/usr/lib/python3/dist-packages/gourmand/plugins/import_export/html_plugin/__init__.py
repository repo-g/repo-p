from . import html_exporter_plugin

plugins = [html_exporter_plugin.HtmlExporterPlugin]
