if __name__ == '__main__':
    from gourmand.main import launch_app
    launch_app()
