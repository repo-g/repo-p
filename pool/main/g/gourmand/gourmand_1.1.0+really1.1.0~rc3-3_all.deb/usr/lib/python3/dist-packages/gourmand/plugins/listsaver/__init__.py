from . import shoppingSaverPlugin

plugins = [shoppingSaverPlugin.ShoppingListSaver]
