from . import krecipe_importer_plugin

plugins = [krecipe_importer_plugin.KrecipeImporterPlugin]
