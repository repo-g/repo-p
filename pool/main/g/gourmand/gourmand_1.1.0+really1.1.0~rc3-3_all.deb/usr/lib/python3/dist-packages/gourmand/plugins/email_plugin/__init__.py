from . import emailer_plugin

plugins = [emailer_plugin.EmailRecipePlugin]
