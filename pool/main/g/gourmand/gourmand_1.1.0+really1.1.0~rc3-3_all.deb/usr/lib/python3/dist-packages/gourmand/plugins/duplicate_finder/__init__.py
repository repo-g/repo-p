from . import recipeMergerPlugin

plugins = [
    recipeMergerPlugin.RecipeMergerPlugin,
    recipeMergerPlugin.RecipeMergerImportManagerPlugin
    ]
