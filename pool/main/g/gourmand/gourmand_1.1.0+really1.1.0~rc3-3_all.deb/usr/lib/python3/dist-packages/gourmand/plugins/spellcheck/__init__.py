from . import reccard_spellcheck_plugin

plugins = [reccard_spellcheck_plugin.SpellPlugin]
