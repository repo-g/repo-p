from . import epub_exporter_plugin

plugins = [epub_exporter_plugin.EpubExporterPlugin]
