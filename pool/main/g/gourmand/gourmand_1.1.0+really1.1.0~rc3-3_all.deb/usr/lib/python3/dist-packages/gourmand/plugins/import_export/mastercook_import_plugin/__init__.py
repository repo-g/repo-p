from . import mastercook_importer_plugin

plugins = [mastercook_importer_plugin.MastercookImporterPlugin,
           mastercook_importer_plugin.MastercookTextImporterPlugin,
           ]
