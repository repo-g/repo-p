from . import pdf_exporter_plugin, print_plugin

plugins = [pdf_exporter_plugin.PdfExporterPlugin,
           print_plugin.PDFPrintPlugin]
