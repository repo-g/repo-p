# This code is automatically generated at build time.
# Do not modify manually.

"""Automatically generated RPC client wrappers.

"""

from ganeti import rpc_defs

# Definitions from 'lib/rpc_defs.py'

class RpcClientBootstrap(object):
  # E1101: Non-existent members
  # R0904: Too many public methods
  # pylint: disable=E1101,R0904
  _CALLS = rpc_defs.CALLS['RpcClientBootstrap']

  def call_master_node_name(self, node_list,
    _def=_CALLS['master_node_name']):
    """Wrapper for RPC call 'master_node_name'

    Returns the master node name

    @note: This is a multi-node call with a timeout of 1m 0s
    @type node_list: list of string
    @param node_list: List of node names

    """
    return (self._Call(_def, node_list, []))

  def call_node_activate_master_ip(self, node, master_params,
    use_external_mip_script, _def=_CALLS['node_activate_master_ip']):
    """Wrapper for RPC call 'node_activate_master_ip'

    Activates master IP on a node

    @note: This is a single-node call with a timeout of 5m 0s
    @type node: string
    @param node: Node name
    @param master_params: Network parameters of the master
    @param use_external_mip_script: Whether to use the user-provided
      master IP address setup script

    """
    return (self._Call(_def, [node], [master_params,
      use_external_mip_script])[node])

  def call_node_change_master_netmask(self, node, old_netmask, netmask,
    master_ip, master_netdev,
    _def=_CALLS['node_change_master_netmask']):
    """Wrapper for RPC call 'node_change_master_netmask'

    Change master IP netmask

    @note: This is a single-node call with a timeout of 5m 0s
    @type node: string
    @param node: Node name
    @param old_netmask: The old value of the netmask
    @param netmask: The new value of the netmask
    @param master_ip: The master IP
    @param master_netdev: The master network device

    """
    return (self._Call(_def, [node], [old_netmask, netmask, master_ip,
      master_netdev])[node])

  def call_node_deactivate_master_ip(self, node, master_params,
    use_external_mip_script, _def=_CALLS['node_deactivate_master_ip']):
    """Wrapper for RPC call 'node_deactivate_master_ip'

    Deactivates master IP on a node

    @note: This is a single-node call with a timeout of 5m 0s
    @type node: string
    @param node: Node name
    @param master_params: Network parameters of the master
    @param use_external_mip_script: Whether to use the user-provided
      master IP address setup script

    """
    return (self._Call(_def, [node], [master_params,
      use_external_mip_script])[node])

  def call_node_leave_cluster(self, node, modify_ssh_setup,
    _def=_CALLS['node_leave_cluster']):
    """Wrapper for RPC call 'node_leave_cluster'

    Requests a node to clean the cluster information it has

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name

    """
    return (self._Call(_def, [node], [modify_ssh_setup])[node])

  def call_node_start_master_daemons(self, node, no_voting,
    _def=_CALLS['node_start_master_daemons']):
    """Wrapper for RPC call 'node_start_master_daemons'

    Starts master daemons on a node

    @note: This is a single-node call with a timeout of 5m 0s
    @type node: string
    @param node: Node name

    """
    return (self._Call(_def, [node], [no_voting])[node])

  def call_node_stop_master(self, node,
    _def=_CALLS['node_stop_master']):
    """Wrapper for RPC call 'node_stop_master'

    Deactivates master IP and stops master daemons on a node

    @note: This is a single-node call with a timeout of 5m 0s
    @type node: string
    @param node: Node name

    """
    return (self._Call(_def, [node], [])[node])


class RpcClientConfig(object):
  # E1101: Non-existent members
  # R0904: Too many public methods
  # pylint: disable=E1101,R0904
  _CALLS = rpc_defs.CALLS['RpcClientConfig']

  def call_upload_file(self, node_list, file_name,
    _def=_CALLS['upload_file']):
    """Wrapper for RPC call 'upload_file'

    Upload files

    @note: This is a multi-node call with a timeout of 15m 0s
    @type node_list: list of string
    @param node_list: List of node names

    """
    return (self._Call(_def, node_list, [file_name]))

  def call_upload_file_single(self, node_list, file_name, content, mode,
    uid, gid, atime, mtime, _def=_CALLS['upload_file_single']):
    """Wrapper for RPC call 'upload_file_single'

    Upload files

    @note: This is a multi-node call with a timeout of 15m 0s
    @type node_list: list of string
    @param node_list: List of node names
    @param file_name: The name of the file
    @param content: The data to be uploaded
    @param mode: The mode of the file or None
    @param uid: The owner of the file
    @param gid: The group of the file
    @param atime: The file's last access time
    @param mtime: The file's last modification time

    """
    return (self._Call(_def, node_list, [file_name, content, mode, uid,
      gid, atime, mtime]))

  def call_write_ssconf_files(self, node_list, values,
    _def=_CALLS['write_ssconf_files']):
    """Wrapper for RPC call 'write_ssconf_files'

    Write ssconf files

    @note: This is a multi-node call with a timeout of 15m 0s
    @type node_list: list of string
    @param node_list: List of node names

    """
    return (self._Call(_def, node_list, [values]))


class RpcClientDefault(object):
  # E1101: Non-existent members
  # R0904: Too many public methods
  # pylint: disable=E1101,R0904
  _CALLS = rpc_defs.CALLS['RpcClientDefault']

  def call_accept_instance(self, node, instance, info, target,
    _def=_CALLS['accept_instance']):
    """Wrapper for RPC call 'accept_instance'

    Prepare a node to accept an instance

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name
    @param instance: Instance object
    @param info: Result for the call_migration_info call
    @param target: Target hostname (usually an IP address)

    """
    return (self._Call(_def, [node], [instance, info, target])[node])

  def call_all_instances_info(self, node_list, hypervisor_list,
    all_hvparams, _def=_CALLS['all_instances_info']):
    """Wrapper for RPC call 'all_instances_info'

    Returns information about all instances on the given nodes

    @note: This is a multi-node call with a timeout of 1m 0s
    @type node_list: list of string
    @param node_list: List of node names
    @param hypervisor_list: Hypervisors to query for instances
    @param all_hvparams: Dictionary mapping hypervisor names to hvparams

    """
    return (self._Call(_def, node_list, [hypervisor_list, all_hvparams]))

  def call_bdev_sizes(self, node_list, devices,
    _def=_CALLS['bdev_sizes']):
    """Wrapper for RPC call 'bdev_sizes'

    Gets the sizes of requested block devices present on a node

    @note: This is a multi-node call with a timeout of 1m 0s
    @type node_list: list of string
    @param node_list: List of node names

    """
    return (self._Call(_def, node_list, [devices]))

  def call_blockdev_addchildren(self, node, bdev, ndevs,
    _def=_CALLS['blockdev_addchildren']):
    """Wrapper for RPC call 'blockdev_addchildren'

    Request adding a list of children to a (mirroring) device

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name

    """
    return (self._Call(_def, [node], [bdev, ndevs])[node])

  def call_blockdev_assemble(self, node, disk, instance, on_primary,
    idx, _def=_CALLS['blockdev_assemble']):
    """Wrapper for RPC call 'blockdev_assemble'

    Request assembling of a given block device

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name

    """
    return (self._Call(_def, [node], [disk, instance, on_primary,
      idx])[node])

  def call_blockdev_close(self, node, instance_name, disks,
    _def=_CALLS['blockdev_close']):
    """Wrapper for RPC call 'blockdev_close'

    Closes the given block devices

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name

    """
    return (self._Call(_def, [node], [instance_name, disks])[node])

  def call_blockdev_convert(self, node, bdev_src, bdev_dest,
    _def=_CALLS['blockdev_convert']):
    """Wrapper for RPC call 'blockdev_convert'

    Request the copy of the source block device to the destination one

    @note: This is a single-node call with a timeout of 1h 0m 0s
    @type node: string
    @param node: Node name

    """
    return (self._Call(_def, [node], [bdev_src, bdev_dest])[node])

  def call_blockdev_create(self, node, bdev, size, owner, on_primary,
    info, exclusive_storage, _def=_CALLS['blockdev_create']):
    """Wrapper for RPC call 'blockdev_create'

    Request creation of a given block device

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name

    """
    return (self._Call(_def, [node], [bdev, size, owner, on_primary, info,
      exclusive_storage])[node])

  def call_blockdev_find(self, node, disk,
    _def=_CALLS['blockdev_find']):
    """Wrapper for RPC call 'blockdev_find'

    Request identification of a given block device

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name

    """
    return (self._Call(_def, [node], [disk])[node])

  def call_blockdev_getdimensions(self, node, disks,
    _def=_CALLS['blockdev_getdimensions']):
    """Wrapper for RPC call 'blockdev_getdimensions'

    Returns size and spindles of the given disks

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name

    """
    return (self._Call(_def, [node], [disks])[node])

  def call_blockdev_getmirrorstatus(self, node, disks,
    _def=_CALLS['blockdev_getmirrorstatus']):
    """Wrapper for RPC call 'blockdev_getmirrorstatus'

    Request status of a (mirroring) device

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name

    """
    return (self._Call(_def, [node], [disks])[node])

  def call_blockdev_getmirrorstatus_multi(self, node_list, node_disks,
    _def=_CALLS['blockdev_getmirrorstatus_multi']):
    """Wrapper for RPC call 'blockdev_getmirrorstatus_multi'

    Request status of (mirroring) devices from multiple nodes

    @note: This is a multi-node call with a timeout of 15m 0s
    @type node_list: list of string
    @param node_list: List of node names

    """
    return (self._Call(_def, node_list, [node_disks]))

  def call_blockdev_grow(self, node, cf_bdev, amount, dryrun,
    backingstore, es_flag, _def=_CALLS['blockdev_grow']):
    """Wrapper for RPC call 'blockdev_grow'

    Request growing of the given block device by a given amount

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name

    """
    return (self._Call(_def, [node], [cf_bdev, amount, dryrun,
      backingstore, es_flag])[node])

  def call_blockdev_image(self, node, bdev, image, size,
    _def=_CALLS['blockdev_image']):
    """Wrapper for RPC call 'blockdev_image'

    Request to dump an image with given size onto a block device

    @note: This is a single-node call with a timeout of 1h 0m 0s
    @type node: string
    @param node: Node name

    """
    return (self._Call(_def, [node], [bdev, image, size])[node])

  def call_blockdev_open(self, node, instance_name, disks, exclusive,
    _def=_CALLS['blockdev_open']):
    """Wrapper for RPC call 'blockdev_open'

    Opens the given block devices in required mode

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name

    """
    return (self._Call(_def, [node], [instance_name, disks,
      exclusive])[node])

  def call_blockdev_pause_resume_sync(self, node, disks, pause,
    _def=_CALLS['blockdev_pause_resume_sync']):
    """Wrapper for RPC call 'blockdev_pause_resume_sync'

    Request a pause/resume of given block device

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name

    """
    return (self._Call(_def, [node], [disks, pause])[node])

  def call_blockdev_remove(self, node, bdev,
    _def=_CALLS['blockdev_remove']):
    """Wrapper for RPC call 'blockdev_remove'

    Request removal of a given block device

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name

    """
    return (self._Call(_def, [node], [bdev])[node])

  def call_blockdev_removechildren(self, node, bdev, ndevs,
    _def=_CALLS['blockdev_removechildren']):
    """Wrapper for RPC call 'blockdev_removechildren'

    Request removing a list of children from a (mirroring) device

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name

    """
    return (self._Call(_def, [node], [bdev, ndevs])[node])

  def call_blockdev_rename(self, node, devlist,
    _def=_CALLS['blockdev_rename']):
    """Wrapper for RPC call 'blockdev_rename'

    Request rename of the given block devices

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name

    """
    return (self._Call(_def, [node], [devlist])[node])

  def call_blockdev_setinfo(self, node, disk, info,
    _def=_CALLS['blockdev_setinfo']):
    """Wrapper for RPC call 'blockdev_setinfo'

    Sets metadata information on a given block device

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name

    """
    return (self._Call(_def, [node], [disk, info])[node])

  def call_blockdev_shutdown(self, node, disk,
    _def=_CALLS['blockdev_shutdown']):
    """Wrapper for RPC call 'blockdev_shutdown'

    Request shutdown of a given block device

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name

    """
    return (self._Call(_def, [node], [disk])[node])

  def call_blockdev_snapshot(self, node, cf_bdev, snap_name, snap_size,
    _def=_CALLS['blockdev_snapshot']):
    """Wrapper for RPC call 'blockdev_snapshot'

    Export a given disk to another node

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name

    """
    return (self._Call(_def, [node], [cf_bdev, snap_name,
      snap_size])[node])

  def call_blockdev_wipe(self, node, bdev, offset, size,
    _def=_CALLS['blockdev_wipe']):
    """Wrapper for RPC call 'blockdev_wipe'

    Request wipe at given offset with given size of a block device

    @note: This is a single-node call with a timeout of 1h 0m 0s
    @type node: string
    @param node: Node name

    """
    return (self._Call(_def, [node], [bdev, offset, size])[node])

  def call_bridges_exist(self, node, bridges_list,
    _def=_CALLS['bridges_exist']):
    """Wrapper for RPC call 'bridges_exist'

    Checks if a node has all the bridges given

    @note: This is a single-node call with a timeout of 1m 0s
    @type node: string
    @param node: Node name
    @param bridges_list: Bridges which must be present on remote node

    """
    return (self._Call(_def, [node], [bridges_list])[node])

  def call_drbd_attach_net(self, node_list, disks, multimaster,
    _def=_CALLS['drbd_attach_net']):
    """Wrapper for RPC call 'drbd_attach_net'

    Connects the given DRBD devices

    @note: This is a multi-node call with a timeout of 15m 0s
    @type node_list: list of string
    @param node_list: List of node names

    """
    return (self._Call(_def, node_list, [disks, multimaster]))

  def call_drbd_disconnect_net(self, node_list, disks,
    _def=_CALLS['drbd_disconnect_net']):
    """Wrapper for RPC call 'drbd_disconnect_net'

    Disconnects the network of the given drbd devices

    @note: This is a multi-node call with a timeout of 15m 0s
    @type node_list: list of string
    @param node_list: List of node names

    """
    return (self._Call(_def, node_list, [disks]))

  def call_drbd_helper(self, node_list, _def=_CALLS['drbd_helper']):
    """Wrapper for RPC call 'drbd_helper'

    Gets DRBD helper

    @note: This is a multi-node call with a timeout of 1m 0s
    @type node_list: list of string
    @param node_list: List of node names

    """
    return (self._Call(_def, node_list, []))

  def call_drbd_needs_activation(self, node, disks,
    _def=_CALLS['drbd_needs_activation']):
    """Wrapper for RPC call 'drbd_needs_activation'

    Returns the drbd disks which need activation

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name

    """
    return (self._Call(_def, [node], [disks])[node])

  def call_drbd_wait_sync(self, node_list, disks,
    _def=_CALLS['drbd_wait_sync']):
    """Wrapper for RPC call 'drbd_wait_sync'

    Waits for the synchronization of drbd devices is complete

    @note: This is a multi-node call with a timeout of 1h 0m 0s
    @type node_list: list of string
    @param node_list: List of node names

    """
    return (self._Call(_def, node_list, [disks]))

  def call_etc_hosts_modify(self, node, mode, name, ip,
    _def=_CALLS['etc_hosts_modify']):
    """Wrapper for RPC call 'etc_hosts_modify'

    Modify hosts file with name

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name
    @param mode: Mode to operate; currently L{constants.ETC_HOSTS_ADD} or
      L{constants.ETC_HOSTS_REMOVE}
    @param name: Hostname to be modified
    @param ip: IP address (L{constants.ETC_HOSTS_ADD} only)

    """
    return (self._Call(_def, [node], [mode, name, ip])[node])

  def call_export_info(self, node, path, _def=_CALLS['export_info']):
    """Wrapper for RPC call 'export_info'

    Queries the export information in a given path

    @note: This is a single-node call with a timeout of 5m 0s
    @type node: string
    @param node: Node name

    """
    return (self._Call(_def, [node], [path])[node])

  def call_export_list(self, node_list, _def=_CALLS['export_list']):
    """Wrapper for RPC call 'export_list'

    Gets the stored exports list

    @note: This is a multi-node call with a timeout of 5m 0s
    @type node_list: list of string
    @param node_list: List of node names

    """
    return (self._Call(_def, node_list, []))

  def call_export_remove(self, node, export,
    _def=_CALLS['export_remove']):
    """Wrapper for RPC call 'export_remove'

    Requests removal of a given export

    @note: This is a single-node call with a timeout of 5m 0s
    @type node: string
    @param node: Node name

    """
    return (self._Call(_def, [node], [export])[node])

  def call_export_start(self, node, opts, host, port, instance,
    component, source, _def=_CALLS['export_start']):
    """Wrapper for RPC call 'export_start'

    Starts an export daemon

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name
    @param source: Export source

    """
    return (self._Call(_def, [node], [opts, host, port, instance,
      component, source])[node])

  def call_extstorage_diagnose(self, node_list,
    _def=_CALLS['extstorage_diagnose']):
    """Wrapper for RPC call 'extstorage_diagnose'

    Request a diagnose of ExtStorage Providers

    @note: This is a multi-node call with a timeout of 5m 0s
    @type node_list: list of string
    @param node_list: List of node names

    """
    return (self._Call(_def, node_list, []))

  def call_file_storage_dir_create(self, node, file_storage_dir,
    _def=_CALLS['file_storage_dir_create']):
    """Wrapper for RPC call 'file_storage_dir_create'

    Create the given file storage directory

    @note: This is a single-node call with a timeout of 5m 0s
    @type node: string
    @param node: Node name
    @param file_storage_dir: File storage directory

    """
    return (self._Call(_def, [node], [file_storage_dir])[node])

  def call_file_storage_dir_remove(self, node, file_storage_dir,
    _def=_CALLS['file_storage_dir_remove']):
    """Wrapper for RPC call 'file_storage_dir_remove'

    Remove the given file storage directory

    @note: This is a single-node call with a timeout of 5m 0s
    @type node: string
    @param node: Node name
    @param file_storage_dir: File storage directory

    """
    return (self._Call(_def, [node], [file_storage_dir])[node])

  def call_file_storage_dir_rename(self, node, old_file_storage_dir,
    new_file_storage_dir, _def=_CALLS['file_storage_dir_rename']):
    """Wrapper for RPC call 'file_storage_dir_rename'

    Rename file storage directory

    @note: This is a single-node call with a timeout of 5m 0s
    @type node: string
    @param node: Node name
    @param old_file_storage_dir: Old name
    @param new_file_storage_dir: New name

    """
    return (self._Call(_def, [node], [old_file_storage_dir,
      new_file_storage_dir])[node])

  def call_finalize_export(self, node, instance, snap_disks,
    _def=_CALLS['finalize_export']):
    """Wrapper for RPC call 'finalize_export'

    Request the completion of an export operation

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name

    """
    return (self._Call(_def, [node], [instance, snap_disks])[node])

  def call_get_file_info(self, node, file_path,
    _def=_CALLS['get_file_info']):
    """Wrapper for RPC call 'get_file_info'

    Checks if a file exists and reports on it

    @note: This is a single-node call with a timeout of 5m 0s
    @type node: string
    @param node: Node name

    """
    return (self._Call(_def, [node], [file_path])[node])

  def call_get_watcher_pause(self, node,
    _def=_CALLS['get_watcher_pause']):
    """Wrapper for RPC call 'get_watcher_pause'

    Get watcher pause end

    @note: This is a single-node call with a timeout of 1m 0s
    @type node: string
    @param node: Node name

    """
    return (self._Call(_def, [node], [])[node])

  def call_hooks_runner(self, node_list, hpath, phase, env,
    _def=_CALLS['hooks_runner']):
    """Wrapper for RPC call 'hooks_runner'

    Call the hooks runner

    @note: This is a multi-node call with a timeout of 15m 0s
    @type node_list: list of string
    @param node_list: List of node names

    """
    return (self._Call(_def, node_list, [hpath, phase, env]))

  def call_hotplug_device(self, node, instance, action, dev_type,
    device, extra, seq, _def=_CALLS['hotplug_device']):
    """Wrapper for RPC call 'hotplug_device'

    Hoplug a device to a running instance

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name
    @param instance: Instance object
    @param action: Hotplug Action
    @param dev_type: Device type
    @param device: Device dict
    @param extra: Extra info for device (dev_path for disk)
    @param seq: Device seq

    """
    return (self._Call(_def, [node], [instance, action, dev_type, device,
      extra, seq])[node])

  def call_hotplug_supported(self, node, instance,
    _def=_CALLS['hotplug_supported']):
    """Wrapper for RPC call 'hotplug_supported'

    Check if hotplug is supported

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name
    @param instance: Instance object

    """
    return (self._Call(_def, [node], [instance])[node])

  def call_hypervisor_validate_params(self, node_list, hvname, hvfull,
    _def=_CALLS['hypervisor_validate_params']):
    """Wrapper for RPC call 'hypervisor_validate_params'

    Validate hypervisor params

    @note: This is a multi-node call with a timeout of 15m 0s
    @type node_list: list of string
    @param node_list: List of node names
    @param hvname: Hypervisor name
    @param hvfull: Parameters to be validated

    """
    return (self._Call(_def, node_list, [hvname, hvfull]))

  def call_iallocator_runner(self, node, name, idata,
    default_iallocator_params, _def=_CALLS['iallocator_runner']):
    """Wrapper for RPC call 'iallocator_runner'

    Call an iallocator on a remote node

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name
    @param name: Iallocator name
    @param idata: JSON-encoded input string
    @param default_iallocator_params: Additional iallocator parameters

    """
    return (self._Call(_def, [node], [name, idata,
      default_iallocator_params])[node])

  def call_impexp_abort(self, node, name, _def=_CALLS['impexp_abort']):
    """Wrapper for RPC call 'impexp_abort'

    Aborts an import or export

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name
    @param name: Import/export name

    """
    return (self._Call(_def, [node], [name])[node])

  def call_impexp_cleanup(self, node, name,
    _def=_CALLS['impexp_cleanup']):
    """Wrapper for RPC call 'impexp_cleanup'

    Cleans up after an import or export

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name
    @param name: Import/export name

    """
    return (self._Call(_def, [node], [name])[node])

  def call_impexp_status(self, node, names,
    _def=_CALLS['impexp_status']):
    """Wrapper for RPC call 'impexp_status'

    Gets the status of an import or export

    @note: This is a single-node call with a timeout of 5m 0s
    @type node: string
    @param node: Node name
    @param names: Import/export names

    """
    return (self._Call(_def, [node], [names])[node])

  def call_import_start(self, node, opts, instance, component, dest,
    _def=_CALLS['import_start']):
    """Wrapper for RPC call 'import_start'

    Starts an import daemon

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name
    @param dest: Import destination

    """
    return (self._Call(_def, [node], [opts, instance, component,
      dest])[node])

  def call_instance_balloon_memory(self, node, instance, memory,
    _def=_CALLS['instance_balloon_memory']):
    """Wrapper for RPC call 'instance_balloon_memory'

    Modify the amount of an instance's runtime memory

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name
    @param instance: Instance object

    """
    return (self._Call(_def, [node], [instance, memory])[node])

  def call_instance_finalize_migration_dst(self, node, instance, info,
    success, _def=_CALLS['instance_finalize_migration_dst']):
    """Wrapper for RPC call 'instance_finalize_migration_dst'

    Finalize any target-node migration specific operation

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name
    @param instance: Instance object
    @param info: Result for the call_migration_info call
    @param success: Whether the migration was a success or failure

    """
    return (self._Call(_def, [node], [instance, info, success])[node])

  def call_instance_finalize_migration_src(self, node, instance,
    success, live, _def=_CALLS['instance_finalize_migration_src']):
    """Wrapper for RPC call 'instance_finalize_migration_src'

    Finalize the instance migration on the source node

    @note: This is a single-node call with a timeout of 1h 0m 0s
    @type node: string
    @param node: Node name
    @param instance: Instance object
    @param success: Whether the migration succeeded or not
    @param live: Whether the user requested a live migration or not

    """
    return (self._Call(_def, [node], [instance, success, live])[node])

  def call_instance_get_migration_status(self, node, instance,
    _def=_CALLS['instance_get_migration_status']):
    """Wrapper for RPC call 'instance_get_migration_status'

    Report migration status

    @note: This is a single-node call with a timeout of 1h 0m 0s
    @type node: string
    @param node: Node name
    @param instance: Instance object

    """
    return (self._Call(_def, [node], [instance])[node])

  def call_instance_info(self, node, instance, hname, hvparams,
    _def=_CALLS['instance_info']):
    """Wrapper for RPC call 'instance_info'

    Returns information about a single instance

    @note: This is a single-node call with a timeout of 1m 0s
    @type node: string
    @param node: Node name
    @param instance: Instance name
    @param hname: Hypervisor type
    @param hvparams: Hypervisor parameters

    """
    return (self._Call(_def, [node], [instance, hname, hvparams])[node])

  def call_instance_list(self, node_list, hypervisor_list, hvparams,
    _def=_CALLS['instance_list']):
    """Wrapper for RPC call 'instance_list'

    Returns the list of running instances on the given nodes

    @note: This is a multi-node call with a timeout of 1m 0s
    @type node_list: list of string
    @param node_list: List of node names
    @param hypervisor_list: Hypervisors to query for instances
    @param hvparams: Hvparams of all hypervisors

    """
    return (self._Call(_def, node_list, [hypervisor_list, hvparams]))

  def call_instance_metadata_modify(self, node, instance,
    _def=_CALLS['instance_metadata_modify']):
    """Wrapper for RPC call 'instance_metadata_modify'

    Modify instance metadata

    @note: This is a single-node call with a timeout of 1m 0s
    @type node: string
    @param node: Node name
    @param instance: Instance object

    """
    return (self._Call(_def, [node], [instance])[node])

  def call_instance_migratable(self, node, instance,
    _def=_CALLS['instance_migratable']):
    """Wrapper for RPC call 'instance_migratable'

    Checks whether the given instance can be migrated

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name
    @param instance: Instance object

    """
    return (self._Call(_def, [node], [instance])[node])

  def call_instance_migrate(self, node, cluster_name, instance, target,
    live, _def=_CALLS['instance_migrate']):
    """Wrapper for RPC call 'instance_migrate'

    Migrate an instance

    @note: This is a single-node call with a timeout of 1h 0m 0s
    @type node: string
    @param node: Node name
    @param cluster_name: Cluster name
    @param instance: Instance object
    @param target: Target node name
    @param live: Whether the migration should be done live or not

    """
    return (self._Call(_def, [node], [cluster_name, instance, target,
      live])[node])

  def call_instance_os_add(self, node, instance_osp, reinstall, debug,
    _def=_CALLS['instance_os_add']):
    """Wrapper for RPC call 'instance_os_add'

    Installs an operative system onto an instance

    @note: This is a single-node call with a timeout of 1d 0h 0m 0s
    @type node: string
    @param node: Node name
    @param instance_osp: Tuple: (target instance, temporary OS parameters
      overriding configuration)
    @param reinstall: Whether the instance is being reinstalled
    @param debug: Debug level for the OS install script to use

    """
    return (self._Call(_def, [node], [instance_osp, reinstall,
      debug])[node])

  def call_instance_reboot(self, node, inst, reboot_type,
    shutdown_timeout, reason, _def=_CALLS['instance_reboot']):
    """Wrapper for RPC call 'instance_reboot'

    Returns the list of running instances on the given nodes

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name
    @param inst: Instance object
    @param reason: The reason for the reboot

    """
    return (self._Call(_def, [node], [inst, reboot_type, shutdown_timeout,
      reason])[node])

  def call_instance_run_rename(self, node, instance, old_name, debug,
    _def=_CALLS['instance_run_rename']):
    """Wrapper for RPC call 'instance_run_rename'

    Run the OS rename script for an instance

    @note: This is a single-node call with a timeout of 1h 0m 0s
    @type node: string
    @param node: Node name
    @param instance: Instance object

    """
    return (self._Call(_def, [node], [instance, old_name, debug])[node])

  def call_instance_shutdown(self, node, instance, timeout, reason,
    _def=_CALLS['instance_shutdown']):
    """Wrapper for RPC call 'instance_shutdown'

    Stops an instance

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name
    @param instance: Instance object
    @param reason: The reason for the shutdown

    """
    return (self._Call(_def, [node], [instance, timeout, reason])[node])

  def call_instance_start(self, node, instance_hvp_bep, startup_paused,
    reason, _def=_CALLS['instance_start']):
    """Wrapper for RPC call 'instance_start'

    Starts an instance

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name
    @param reason: The reason for the startup

    """
    return (self._Call(_def, [node], [instance_hvp_bep, startup_paused,
      reason])[node])

  def call_lv_list(self, node_list, vg_name, _def=_CALLS['lv_list']):
    """Wrapper for RPC call 'lv_list'

    Gets the logical volumes present in a given volume group

    @note: This is a multi-node call with a timeout of 1m 0s
    @type node_list: list of string
    @param node_list: List of node names

    """
    return (self._Call(_def, node_list, [vg_name]))

  def call_migration_info(self, node, instance,
    _def=_CALLS['migration_info']):
    """Wrapper for RPC call 'migration_info'

    Gather the information necessary to prepare an instance migration

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name
    @param instance: Instance object

    """
    return (self._Call(_def, [node], [instance])[node])

  def call_node_configure_ovs(self, node, ovs_name, ovs_link,
    _def=_CALLS['node_configure_ovs']):
    """Wrapper for RPC call 'node_configure_ovs'

    This will create and setup the OpenvSwitch

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name
    @param ovs_name: Name of the OpenvSwitch to create
    @param ovs_link: Link of the OpenvSwitch to the outside

    """
    return (self._Call(_def, [node], [ovs_name, ovs_link])[node])

  def call_node_crypto_tokens(self, node, token_request,
    _def=_CALLS['node_crypto_tokens']):
    """Wrapper for RPC call 'node_crypto_tokens'

    Handle crypto tokens of the node.

    @note: This is a single-node call with a timeout of 1h 0m 0s
    @type node: string
    @param node: Node name
    @param token_request: List of tuples of requested crypto token types,
      actions

    """
    return (self._Call(_def, [node], [token_request])[node])

  def call_node_demote_from_mc(self, node,
    _def=_CALLS['node_demote_from_mc']):
    """Wrapper for RPC call 'node_demote_from_mc'

    Demote a node from the master candidate role

    @note: This is a single-node call with a timeout of 5m 0s
    @type node: string
    @param node: Node name

    """
    return (self._Call(_def, [node], [])[node])

  def call_node_ensure_daemon(self, node_list, daemon, run,
    _def=_CALLS['node_ensure_daemon']):
    """Wrapper for RPC call 'node_ensure_daemon'

    Ensure daemon is running on the node.

    @note: This is a multi-node call with a timeout of 1m 0s
    @type node_list: list of string
    @param node_list: List of node names
    @param daemon: Daemon name
    @param run: Whether the daemon should be running or stopped

    """
    return (self._Call(_def, node_list, [daemon, run]))

  def call_node_has_ip_address(self, node, address,
    _def=_CALLS['node_has_ip_address']):
    """Wrapper for RPC call 'node_has_ip_address'

    Checks if a node has the given IP address

    @note: This is a single-node call with a timeout of 5m 0s
    @type node: string
    @param node: Node name
    @param address: IP address

    """
    return (self._Call(_def, [node], [address])[node])

  def call_node_info(self, node_list, storage_units, hv_specs,
    _def=_CALLS['node_info']):
    """Wrapper for RPC call 'node_info'

    Return node information

    @note: This is a multi-node call with a timeout of 1m 0s
    @type node_list: list of string
    @param node_list: List of node names
    @param storage_units: List of tuples '<storage_type>,<key>,[<param>]'
      to ask for disk space information; the parameter list varies
      depending on the storage_type
    @param hv_specs: List of hypervisor specification (name, hvparams) to
      ask for node information

    """
    return (self._Call(_def, node_list, [storage_units, hv_specs]))

  def call_node_powercycle(self, node, hypervisor, hvparams,
    _def=_CALLS['node_powercycle']):
    """Wrapper for RPC call 'node_powercycle'

    Tries to powercycle a node

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name
    @param hypervisor: Hypervisor type
    @param hvparams: Hypervisor parameters

    """
    return (self._Call(_def, [node], [hypervisor, hvparams])[node])

  def call_node_ssh_key_add(self, node_list, node_uuid, node_name,
    potential_master_candidates, to_authorized_keys, to_public_keys,
    get_public_keys, _def=_CALLS['node_ssh_key_add']):
    """Wrapper for RPC call 'node_ssh_key_add'

    Distribute a new node's public SSH key on the cluster.

    @note: This is a multi-node call with a timeout of 5m 0s
    @type node_list: list of string
    @param node_list: List of node names
    @param node_uuid: UUID of the node whose key is distributed
    @param node_name: Name of the node whose key is distributed
    @param potential_master_candidates: Potential master candidates
    @param to_authorized_keys: Whether the node's key should be added to
      all nodes' 'authorized_keys' file
    @param to_public_keys: Whether the node's key should be added to all
      nodes' public key file
    @param get_public_keys: Whether the node should get the other nodes'
      public keys

    """
    return (self._Call(_def, node_list, [node_uuid, node_name,
      potential_master_candidates, to_authorized_keys, to_public_keys,
      get_public_keys]))

  def call_node_ssh_key_remove(self, node_list, node_uuid, node_name,
    master_candidate_uuids, potential_master_candidates,
    from_authorized_keys, from_public_keys, clear_authorized_keys,
    clear_public_keys, readd, _def=_CALLS['node_ssh_key_remove']):
    """Wrapper for RPC call 'node_ssh_key_remove'

    Remove a node's SSH key from the other nodes' key files.

    @note: This is a multi-node call with a timeout of 5m 0s
    @type node_list: list of string
    @param node_list: List of node names
    @param node_uuid: UUID of the node whose key is removed
    @param node_name: Name of the node whose key is removed
    @param master_candidate_uuids: List of UUIDs of master candidates.
    @param potential_master_candidates: Potential master candidates
    @param from_authorized_keys: If the key should be removed from the
      'authorized_keys' file.
    @param from_public_keys: If the key should be removed from the public
      key file.
    @param clear_authorized_keys: If the 'authorized_keys' file of the
      node should be cleared.
    @param clear_public_keys: If the 'ganeti_pub_keys' file of the node
      should be cleared.
    @param readd: Whether this is a readd operation.

    """
    return (self._Call(_def, node_list, [node_uuid, node_name,
      master_candidate_uuids, potential_master_candidates,
      from_authorized_keys, from_public_keys, clear_authorized_keys,
      clear_public_keys, readd]))

  def call_node_ssh_keys_renew(self, node_list, node_uuids, node_names,
    master_candidate_uuids, potential_master_candidates, old_key_type,
    new_key_type, new_key_bits, _def=_CALLS['node_ssh_keys_renew']):
    """Wrapper for RPC call 'node_ssh_keys_renew'

    Renew all SSH key pairs of all nodes nodes.

    @note: This is a multi-node call with a timeout of 4h 0m 0s
    @type node_list: list of string
    @param node_list: List of node names
    @param node_uuids: UUIDs of the nodes whose key is renewed
    @param node_names: Names of the nodes whose key is renewed
    @param master_candidate_uuids: List of UUIDs of master candidates.
    @param potential_master_candidates: Potential master candidates
    @param old_key_type: The type of key previously used
    @param new_key_type: The type of key to generate
    @param new_key_bits: The length of the key to generate

    """
    return (self._Call(_def, node_list, [node_uuids, node_names,
      master_candidate_uuids, potential_master_candidates, old_key_type,
      new_key_type, new_key_bits]))

  def call_node_verify(self, node_list, checkdict, cluster_name,
    all_hvparams, _def=_CALLS['node_verify']):
    """Wrapper for RPC call 'node_verify'

    Request verification of given parameters

    @note: This is a multi-node call with a timeout of 15m 0s
    @type node_list: list of string
    @param node_list: List of node names
    @param checkdict: What to verify
    @param cluster_name: Cluster name
    @param all_hvparams: Dictionary mapping hypervisor names to hvparams

    """
    return (self._Call(_def, node_list, [checkdict, cluster_name,
      all_hvparams]))

  def call_node_volumes(self, node_list, _def=_CALLS['node_volumes']):
    """Wrapper for RPC call 'node_volumes'

    Gets all volumes on node(s)

    @note: This is a multi-node call with a timeout of 5m 0s
    @type node_list: list of string
    @param node_list: List of node names

    """
    return (self._Call(_def, node_list, []))

  def call_os_diagnose(self, node_list, _def=_CALLS['os_diagnose']):
    """Wrapper for RPC call 'os_diagnose'

    Request a diagnose of OS definitions

    @note: This is a multi-node call with a timeout of 5m 0s
    @type node_list: list of string
    @param node_list: List of node names

    """
    return (self._Call(_def, node_list, []))

  def call_os_export(self, node, instance, override_env,
    _def=_CALLS['os_export']):
    """Wrapper for RPC call 'os_export'

    Export an OS for a given instance

    @note: This is a single-node call with a timeout of 5m 0s
    @type node: string
    @param node: Node name

    """
    return (self._Call(_def, [node], [instance, override_env])[node])

  def call_os_validate(self, node_list, required, name, checks, params,
    force_variant, _def=_CALLS['os_validate']):
    """Wrapper for RPC call 'os_validate'

    Run a validation routine for a given OS

    @note: This is a multi-node call with a timeout of 5m 0s
    @type node_list: list of string
    @param node_list: List of node names

    """
    return (self._Call(_def, node_list, [required, name, checks, params,
      force_variant]))

  def call_restricted_command(self, node_list, cmd,
    _def=_CALLS['restricted_command']):
    """Wrapper for RPC call 'restricted_command'

    Runs restricted command

    @note: This is a multi-node call with a timeout of 1h 0m 0s
    @type node_list: list of string
    @param node_list: List of node names
    @param cmd: Command name

    """
    return (self._Call(_def, node_list, [cmd]))

  def call_run_oob(self, node, oob_program, command, remote_node,
    timeout, _def=_CALLS['run_oob']):
    """Wrapper for RPC call 'run_oob'

    Runs out-of-band command

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name

    """
    return (self._Call(_def, [node], [oob_program, command, remote_node,
      timeout])[node])

  def call_set_watcher_pause(self, node_list, until,
    _def=_CALLS['set_watcher_pause']):
    """Wrapper for RPC call 'set_watcher_pause'

    Set watcher pause end

    @note: This is a multi-node call with a timeout of 1m 0s
    @type node_list: list of string
    @param node_list: List of node names

    """
    return (self._Call(_def, node_list, [until]))

  def call_storage_execute(self, node, su_name, su_args, name, op,
    _def=_CALLS['storage_execute']):
    """Wrapper for RPC call 'storage_execute'

    Executes an operation on a storage unit

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name

    """
    return (self._Call(_def, [node], [su_name, su_args, name, op])[node])

  def call_storage_list(self, node_list, su_name, su_args, name, fields,
    _def=_CALLS['storage_list']):
    """Wrapper for RPC call 'storage_list'

    Get list of storage units

    @note: This is a multi-node call with a timeout of 15m 0s
    @type node_list: list of string
    @param node_list: List of node names

    """
    return (self._Call(_def, node_list, [su_name, su_args, name, fields]))

  def call_storage_modify(self, node, su_name, su_args, name, changes,
    _def=_CALLS['storage_modify']):
    """Wrapper for RPC call 'storage_modify'

    Modify a storage unit

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name

    """
    return (self._Call(_def, [node], [su_name, su_args, name,
      changes])[node])

  def call_test_delay(self, node_list, duration,
    _def=_CALLS['test_delay']):
    """Wrapper for RPC call 'test_delay'

    Sleep for a fixed time on given node(s)

    @note: This is a multi-node call
    @type node_list: list of string
    @param node_list: List of node names

    """
    return (self._Call(_def, node_list, [duration]))

  def call_vg_list(self, node_list, _def=_CALLS['vg_list']):
    """Wrapper for RPC call 'vg_list'

    Gets the volume group list

    @note: This is a multi-node call with a timeout of 1m 0s
    @type node_list: list of string
    @param node_list: List of node names

    """
    return (self._Call(_def, node_list, []))

  def call_x509_cert_create(self, node, validity,
    _def=_CALLS['x509_cert_create']):
    """Wrapper for RPC call 'x509_cert_create'

    Creates a new X509 certificate for SSL/TLS

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name
    @param validity: Validity in seconds

    """
    return (self._Call(_def, [node], [validity])[node])

  def call_x509_cert_remove(self, node, name,
    _def=_CALLS['x509_cert_remove']):
    """Wrapper for RPC call 'x509_cert_remove'

    Removes a X509 certificate

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name
    @param name: Certificate name

    """
    return (self._Call(_def, [node], [name])[node])


class RpcClientDnsOnly(object):
  # E1101: Non-existent members
  # R0904: Too many public methods
  # pylint: disable=E1101,R0904
  _CALLS = rpc_defs.CALLS['RpcClientDnsOnly']

  def call_node_verify_light(self, node_list, checkdict, cluster_name,
    hvparams, _def=_CALLS['node_verify_light']):
    """Wrapper for RPC call 'node_verify_light'

    Request verification of given parameters

    @note: This is a multi-node call with a timeout of 15m 0s
    @type node_list: list of string
    @param node_list: List of node names
    @param checkdict: What to verify
    @param cluster_name: Cluster name
    @param hvparams: Dictionary mapping hypervisor names to hvparams

    """
    return (self._Call(_def, node_list, [checkdict, cluster_name,
      hvparams]))

  def call_version(self, node_list, _def=_CALLS['version']):
    """Wrapper for RPC call 'version'

    Query node version

    @note: This is a multi-node call with a timeout of 1m 0s
    @type node_list: list of string
    @param node_list: List of node names

    """
    return (self._Call(_def, node_list, []))


class RpcClientJobQueue(object):
  # E1101: Non-existent members
  # R0904: Too many public methods
  # pylint: disable=E1101,R0904
  _CALLS = rpc_defs.CALLS['RpcClientJobQueue']

  def call_jobqueue_purge(self, node, _def=_CALLS['jobqueue_purge']):
    """Wrapper for RPC call 'jobqueue_purge'

    Purge job queue

    @note: This is a single-node call with a timeout of 15m 0s
    @type node: string
    @param node: Node name

    """
    return (self._Call(_def, [node], [])[node])

  def call_jobqueue_rename(self, node_list, rename,
    _def=_CALLS['jobqueue_rename']):
    """Wrapper for RPC call 'jobqueue_rename'

    Rename job queue file

    @note: This is a multi-node call with a timeout of 1m 0s
    @type node_list: list of string
    @param node_list: List of node names

    """
    return (self._Call(_def, node_list, [rename]))

  def call_jobqueue_set_drain_flag(self, node_list, flag,
    _def=_CALLS['jobqueue_set_drain_flag']):
    """Wrapper for RPC call 'jobqueue_set_drain_flag'

    Set job queue drain flag

    @note: This is a multi-node call with a timeout of 1m 0s
    @type node_list: list of string
    @param node_list: List of node names

    """
    return (self._Call(_def, node_list, [flag]))

  def call_jobqueue_update(self, node_list, file_name, content,
    _def=_CALLS['jobqueue_update']):
    """Wrapper for RPC call 'jobqueue_update'

    Update job queue file

    @note: This is a multi-node call with a timeout of 1m 0s
    @type node_list: list of string
    @param node_list: List of node names

    """
    return (self._Call(_def, node_list, [file_name, content]))
