package encoding

import (
	// Import gocheck so that flag are setup (but unused)
	_ "gopkg.in/check.v1"
)
