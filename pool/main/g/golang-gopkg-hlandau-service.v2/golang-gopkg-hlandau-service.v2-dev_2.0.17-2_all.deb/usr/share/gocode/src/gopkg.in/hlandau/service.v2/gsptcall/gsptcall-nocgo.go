// +build !cgo !unix

package gsptcall

func setProcTitle(title string) {
}
