Gordon
======

#### An open source Flash™ runtime written in pure JavaScript ####

Visit the GitHub Wiki for more information: <http://wiki.github.com/tobeytailor/gordon/>
