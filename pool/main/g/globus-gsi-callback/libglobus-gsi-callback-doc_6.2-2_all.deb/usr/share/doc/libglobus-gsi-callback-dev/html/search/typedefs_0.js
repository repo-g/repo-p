var searchData=
[
  ['globus_5fgsi_5fcallback_5fdata_5ft_94',['globus_gsi_callback_data_t',['../group__globus__gsi__callback__data.html#ga3ae70b8c3f086611aeb22918962f7674',1,'globus_gsi_callback.h']]],
  ['globus_5fgsi_5fextension_5fcallback_5ft_95',['globus_gsi_extension_callback_t',['../group__globus__gsi__callback.html#ga0fecf0a778ad5ddab64a5e558cc5df67',1,'globus_gsi_callback.h']]]
];
