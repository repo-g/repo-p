var searchData=
[
  ['globus_5fgsi_5fcallback_5ferror_5ft_96',['globus_gsi_callback_error_t',['../group__globus__gsi__callback__constants.html#ga2f7ad05d55ce101a57f62842ce0f6f2e',1,'globus_gsi_callback_constants.h']]]
];
