/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or wafsa_.  They are
   private implementation details that can be changed or removed.  */

#ifndef YY_YY_Y_TAB_H_INCLUDED
# define YY_YY_Y_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int wafsadebug;
#endif

/* Token kinds.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum wafsatokentype
  {
    YYEMPTY = -2,
    YYEOF = 0,                     /* "end of file"  */
    YYerror = 256,                 /* error  */
    YYUNDEF = 257,                 /* "invalid token"  */
    FORMAT = 258,                  /* FORMAT  */
    FSA = 259,                     /* FSA  */
    STATES = 260,                  /* STATES  */
    SYMBOLS = 261,                 /* SYMBOLS  */
    BFS = 262,                     /* BFS  */
    MIN = 263,                     /* MIN  */
    VARIABLES = 264,               /* VARIABLES  */
    ALPHABET = 265,                /* ALPHABET  */
    START = 266,                   /* START  */
    ATABLE = 267,                  /* ATABLE  */
    INVERSES = 268,                /* INVERSES  */
    INV = 269,                     /* INV  */
    LEFT_BRACE = 270,              /* LEFT_BRACE  */
    RIGHT_BRACE = 271,             /* RIGHT_BRACE  */
    LEFT_PAREN = 272,              /* LEFT_PAREN  */
    RIGHT_PAREN = 273,             /* RIGHT_PAREN  */
    SEMICOLON = 274,               /* SEMICOLON  */
    PERCENT = 275,                 /* PERCENT  */
    INT = 276,                     /* INT  */
    EQUAL = 277,                   /* EQUAL  */
    STRING = 278,                  /* STRING  */
    REAL = 279                     /* REAL  */
  };
  typedef enum wafsatokentype wafsatoken_kind_t;
#endif
/* Token kinds.  */
#define YYEMPTY -2
#define YYEOF 0
#define YYerror 256
#define YYUNDEF 257
#define FORMAT 258
#define FSA 259
#define STATES 260
#define SYMBOLS 261
#define BFS 262
#define MIN 263
#define VARIABLES 264
#define ALPHABET 265
#define START 266
#define ATABLE 267
#define INVERSES 268
#define INV 269
#define LEFT_BRACE 270
#define RIGHT_BRACE 271
#define LEFT_PAREN 272
#define RIGHT_PAREN 273
#define SEMICOLON 274
#define PERCENT 275
#define INT 276
#define EQUAL 277
#define STRING 278
#define REAL 279

/* Value type.  */


extern YYSTYPE wafsalval;


int wafsaparse (void);


#endif /* !YY_YY_Y_TAB_H_INCLUDED  */
