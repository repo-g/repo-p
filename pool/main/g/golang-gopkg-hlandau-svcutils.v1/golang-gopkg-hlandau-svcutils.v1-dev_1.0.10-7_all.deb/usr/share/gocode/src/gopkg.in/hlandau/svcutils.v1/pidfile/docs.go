// Package pidfile provides functions for the creation and locking of PID
// files.
package pidfile
