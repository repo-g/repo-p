// Package svcutils provides various utilities related to writing services in
// Go.
package svcutils // import "gopkg.in/hlandau/svcutils.v1"
