// +build windows plan9

package dupfd
