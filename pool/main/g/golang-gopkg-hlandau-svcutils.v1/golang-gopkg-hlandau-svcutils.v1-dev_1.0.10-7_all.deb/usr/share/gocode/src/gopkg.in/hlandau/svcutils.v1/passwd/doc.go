// Package passwd provides the resolution of user and group names and
// membership. *NIX only.
package passwd
