var classgx__preset_1_1_units_collector =
[
    [ "empty", "classgx__preset_1_1_units_collector.html#a3db87df4bd1754063981971548ff3b47", null ],
    [ "get_list", "classgx__preset_1_1_units_collector.html#afe52c175ea3e94321454428c02d8eba4", null ],
    [ "set_position", "classgx__preset_1_1_units_collector.html#aa72ee53beeae922261ea01378f3ac843", null ],
    [ "set_pp", "classgx__preset_1_1_units_collector.html#a1ef59f82fd3e1860a631d70a3ff37a50", null ],
    [ "set_show", "classgx__preset_1_1_units_collector.html#a2a8ea79d481c5a31d077a645a20d5f08", null ],
    [ "set_visible", "classgx__preset_1_1_units_collector.html#ab50c6f32ea879348f590fe4c90a8070e", null ],
    [ "m", "classgx__preset_1_1_units_collector.html#a5ae229bafb2326abe967accee5cfc994", null ]
];