var classgx__resample_1_1_simple_resampler =
[
    [ "SimpleResampler", "classgx__resample_1_1_simple_resampler.html#afd40b82f0426a283cbb7f73da8e84d59", null ],
    [ "down", "classgx__resample_1_1_simple_resampler.html#a566c95e3fb0c64495ed7b3f290d8c925", null ],
    [ "setup", "classgx__resample_1_1_simple_resampler.html#a8f18c54168901dbcc872dff9349acc8f", null ],
    [ "up", "classgx__resample_1_1_simple_resampler.html#a2d619f9b51e4ce10f43c1e8ca843e313", null ],
    [ "m_fact", "classgx__resample_1_1_simple_resampler.html#a371b9afe6804a35e6ca1b541bcca83b9", null ],
    [ "r_down", "classgx__resample_1_1_simple_resampler.html#ad243d3d7df3512bfcb35759bd0cf102d", null ],
    [ "r_up", "classgx__resample_1_1_simple_resampler.html#a0db27fbb356321ecb6b05fb198d515ad", null ]
];