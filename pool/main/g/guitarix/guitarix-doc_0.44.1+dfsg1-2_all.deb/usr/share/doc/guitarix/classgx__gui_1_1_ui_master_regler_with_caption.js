var classgx__gui_1_1_ui_master_regler_with_caption =
[
    [ "UiMasterReglerWithCaption", "classgx__gui_1_1_ui_master_regler_with_caption.html#a7ddfd3d310fba56dd31268a236b3e8e2", null ],
    [ "get_regler", "classgx__gui_1_1_ui_master_regler_with_caption.html#a2eb98fe409aec5938a96c0d0ef5cdeea", null ],
    [ "regler", "classgx__gui_1_1_ui_master_regler_with_caption.html#aba6b0802f68bd5f4b95146a7bffc855d", null ]
];