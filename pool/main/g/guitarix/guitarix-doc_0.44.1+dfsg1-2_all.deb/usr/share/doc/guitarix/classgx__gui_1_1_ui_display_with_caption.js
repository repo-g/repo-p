var classgx__gui_1_1_ui_display_with_caption =
[
    [ "UiDisplayWithCaption", "classgx__gui_1_1_ui_display_with_caption.html#ad9d8e4a7b26985afc9f64ff465b62390", null ],
    [ "get_regler", "classgx__gui_1_1_ui_display_with_caption.html#a56b508bc7e85085feb6bbeb315a1e755", null ],
    [ "regler", "classgx__gui_1_1_ui_display_with_caption.html#a92feaedc638371b3a3452acbc0af57eb", null ]
];