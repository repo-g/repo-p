var classgx__gui_1_1_gx_v_box =
[
    [ "GxVBox", "classgx__gui_1_1_gx_v_box.html#a5d1b0b4d62e20319e33e9b98b62bbd0c", null ],
    [ "~GxVBox", "classgx__gui_1_1_gx_v_box.html#a88a6ab816923d574c465cc4f2e2f0c32", null ],
    [ "m_label", "classgx__gui_1_1_gx_v_box.html#a67d71c13afbc19258c7a63a3dc8708b4", null ]
];