var class_gx_logger =
[
    [ "logmsg", "struct_gx_logger_1_1logmsg.html", "struct_gx_logger_1_1logmsg" ],
    [ "msg_signal", "class_gx_logger.html#a5f3ab3a90f477322600ee2bc22316def", null ],
    [ "MsgType", "class_gx_logger.html#a6e49d119ac79d980f5ceb19440097651", [
      [ "kInfo", "class_gx_logger.html#a6e49d119ac79d980f5ceb19440097651a4acda61b3bca76d77441283876bc1bbf", null ],
      [ "kWarning", "class_gx_logger.html#a6e49d119ac79d980f5ceb19440097651a1b5dab23c8538ca8413e4278484e6fd4", null ],
      [ "kError", "class_gx_logger.html#a6e49d119ac79d980f5ceb19440097651a3af9532a81c64abdb917fa24f61a8c15", null ],
      [ "kMessageTypeCount", "class_gx_logger.html#a6e49d119ac79d980f5ceb19440097651abe70d8a43e72e8d8fde115fd148b7d36", null ]
    ] ],
    [ "GxLogger", "class_gx_logger.html#a6dec324347a27b04a0229ef663f6a7ad", null ],
    [ "~GxLogger", "class_gx_logger.html#a1c0e939ea4a1b0bf5b78ba7ca235878d", null ],
    [ "destroy", "class_gx_logger.html#a8f4621690ec26c07c7963a0b63c004a7", null ],
    [ "format", "class_gx_logger.html#a68925415627b66f6d5f17e0b9945768a", null ],
    [ "get_logger", "class_gx_logger.html#a3e59fc3b16bafd6d6cb8d1d45796b9cc", null ],
    [ "print", "class_gx_logger.html#a35fcbf8d61bd03bf928f46d380f9aa35", null ],
    [ "print", "class_gx_logger.html#aef3a25707d64fcd412e458b2746b9d84", null ],
    [ "set_ui_thread", "class_gx_logger.html#a7efefea06e345905cce34e0d3660fb81", null ],
    [ "signal_message", "class_gx_logger.html#a00cba6e651967087685373061c1385cb", null ],
    [ "unplug_queue", "class_gx_logger.html#ace3a445bc41b626ef42ff981ddb9c861", null ],
    [ "write_queued", "class_gx_logger.html#a665208c91122f111f079ab7ce36885ca", null ],
    [ "GxLoggerGuard", "class_gx_logger.html#ae389a7d7c3cb495430423bfe51bf99b6", null ],
    [ "got_new_msg", "class_gx_logger.html#a7297792a1057b418e5784ff042df143b", null ],
    [ "handlers", "class_gx_logger.html#ad26d5c15186c0730172f2d1d7bcd2cb2", null ],
    [ "msglist", "class_gx_logger.html#a69c96e03e0d5c5ff05300b420ad759ab", null ],
    [ "msgmutex", "class_gx_logger.html#aa95cdb1e3da3670a220d2e50b60e1792", null ],
    [ "queue_all_msgs", "class_gx_logger.html#a83e5c7f43bdc5bd67457b0f6e4538dc7", null ],
    [ "ui_thread", "class_gx_logger.html#ae856630093dd35a85131df86583a3c4b", null ]
];