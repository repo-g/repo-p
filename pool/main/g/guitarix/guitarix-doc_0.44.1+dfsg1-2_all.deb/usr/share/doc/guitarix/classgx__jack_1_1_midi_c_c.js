var classgx__jack_1_1_midi_c_c =
[
    [ "MidiCC", "classgx__jack_1_1_midi_c_c.html#aec58dfc0dc62761df669f4f434b64ec5", null ],
    [ "fill", "classgx__jack_1_1_midi_c_c.html#a09d1b20560cd0f4f06a8f9d5ecb8bb84", null ],
    [ "next", "classgx__jack_1_1_midi_c_c.html#a0ef192a66b64d687dab1c37648822c0c", null ],
    [ "send_midi_cc", "classgx__jack_1_1_midi_c_c.html#a37738e02097c9a0553adb0a0a598de9a", null ],
    [ "size", "classgx__jack_1_1_midi_c_c.html#ac4de18aba8956507aa060068b693743d", null ],
    [ "bg_num", "classgx__jack_1_1_midi_c_c.html#ae91f6f6ee3bd852fd06cd3e5509b4336", null ],
    [ "cc_num", "classgx__jack_1_1_midi_c_c.html#ac6a69be9947cd880fc117f486bd122d5", null ],
    [ "engine", "classgx__jack_1_1_midi_c_c.html#aab1deb1a1cb2445cd7ded755148d9230", null ],
    [ "max_midi_cc_cnt", "classgx__jack_1_1_midi_c_c.html#a26ca169c359183f6856a1eadff2f1fae", null ],
    [ "me_num", "classgx__jack_1_1_midi_c_c.html#a1343fe7396bbda7b8e6c65ef69d56897", null ],
    [ "pg_num", "classgx__jack_1_1_midi_c_c.html#a772c84725c1e45a2b5e8a475210f69ed", null ],
    [ "send_cc", "classgx__jack_1_1_midi_c_c.html#a17ceca2988d71fb44db93883d271169a", null ]
];