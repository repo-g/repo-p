var classgx__gui_1_1_cp_master_caption =
[
    [ "CpMasterCaption", "classgx__gui_1_1_cp_master_caption.html#a6ce3dbddebe55994736e716b4efc1913", null ],
    [ "~CpMasterCaption", "classgx__gui_1_1_cp_master_caption.html#acb6da2301a0c67bef86d1e72c0674a46", null ],
    [ "init", "classgx__gui_1_1_cp_master_caption.html#a9b5a2f6577a180d7316fc5e25bae4244", null ],
    [ "set_label", "classgx__gui_1_1_cp_master_caption.html#ac689fc2530630dc9bbcfc2f550fdb957", null ],
    [ "base", "classgx__gui_1_1_cp_master_caption.html#ab4b17543e3b1522ca4b554a6390538b5", null ],
    [ "m_label", "classgx__gui_1_1_cp_master_caption.html#a2f25fbc861a2a27bf91566a6ccc42319", null ]
];