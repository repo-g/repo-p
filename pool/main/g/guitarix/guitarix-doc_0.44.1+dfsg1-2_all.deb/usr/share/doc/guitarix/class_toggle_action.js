var class_toggle_action =
[
    [ "ToggleAction", "class_toggle_action.html#a2065084dd3b545cef419ad67b565fcd1", null ],
    [ "create", "class_toggle_action.html#ad2418c23ed1af5896e03503d9a528ee8", null ],
    [ "get_active", "class_toggle_action.html#aaede2ce9344dae600b01dc534fed2455", null ],
    [ "set_active", "class_toggle_action.html#a128ad493575d366479b9783ae0881a8c", null ],
    [ "signal_toggled", "class_toggle_action.html#a59bed53aa71fe15e9eb531cd688dc934", null ]
];