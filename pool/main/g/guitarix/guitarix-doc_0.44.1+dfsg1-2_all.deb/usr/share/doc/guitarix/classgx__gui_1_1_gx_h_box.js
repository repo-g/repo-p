var classgx__gui_1_1_gx_h_box =
[
    [ "GxHBox", "classgx__gui_1_1_gx_h_box.html#a2048044fee25cf44770aab38a9c1b656", null ],
    [ "~GxHBox", "classgx__gui_1_1_gx_h_box.html#adb45fe68591b17a6822e42800ed5db3b", null ],
    [ "m_label", "classgx__gui_1_1_gx_h_box.html#a3f93f6b283079e76c97b580fbf39bb7a", null ]
];