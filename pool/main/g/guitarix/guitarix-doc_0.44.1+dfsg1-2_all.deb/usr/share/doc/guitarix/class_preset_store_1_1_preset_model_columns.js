var class_preset_store_1_1_preset_model_columns =
[
    [ "PresetModelColumns", "class_preset_store_1_1_preset_model_columns.html#a4d8832dc5eeea8785dae206b29706a8a", null ],
    [ "del_pb", "class_preset_store_1_1_preset_model_columns.html#a3202e7647592c19640f5b6c88c2d4d63", null ],
    [ "edit_pb", "class_preset_store_1_1_preset_model_columns.html#af9cb98bb040328448b9298fbe68ca58e", null ],
    [ "name", "class_preset_store_1_1_preset_model_columns.html#a00f1791957f022162ac666950529db93", null ]
];