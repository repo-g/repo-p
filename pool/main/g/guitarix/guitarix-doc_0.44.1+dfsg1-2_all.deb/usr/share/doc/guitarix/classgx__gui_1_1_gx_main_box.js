var classgx__gui_1_1_gx_main_box =
[
    [ "GxMainBox", "classgx__gui_1_1_gx_main_box.html#aa1b223b99dfc43c630d872498f959a39", null ],
    [ "~GxMainBox", "classgx__gui_1_1_gx_main_box.html#a62a5be8bf998953ab4e88e27966473fe", null ],
    [ "m_eventbox", "classgx__gui_1_1_gx_main_box.html#a0cce5248cd068c3543f13448263f4959", null ],
    [ "m_fbox", "classgx__gui_1_1_gx_main_box.html#a2e005fada5bc39836c6f58558a95b608", null ],
    [ "m_fixedbox", "classgx__gui_1_1_gx_main_box.html#aebdc51b2cf572762860808e7c84c0fdf", null ],
    [ "m_hbox", "classgx__gui_1_1_gx_main_box.html#a38ff72e6b38723d7b8d84bf4315e5f3b", null ],
    [ "m_label", "classgx__gui_1_1_gx_main_box.html#af01a6f104b8ba0057ace41b2f2239340", null ],
    [ "m_paintbox", "classgx__gui_1_1_gx_main_box.html#ae7c9e6c85b283f38282681fb620f66ce", null ],
    [ "m_pbox", "classgx__gui_1_1_gx_main_box.html#a64dee7b8f333afbfa34b1981d4f7c2d3", null ],
    [ "m_tbox", "classgx__gui_1_1_gx_main_box.html#ae3b6a26e65975436d4e55fd6fa00e7c3", null ]
];