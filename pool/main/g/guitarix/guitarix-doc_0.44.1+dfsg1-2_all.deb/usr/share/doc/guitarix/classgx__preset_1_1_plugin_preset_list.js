var classgx__preset_1_1_plugin_preset_list =
[
    [ "PluginPresetList", "classgx__preset_1_1_plugin_preset_list.html#a24af84641f9f6b71ddb9600ce742e308", null ],
    [ "next", "classgx__preset_1_1_plugin_preset_list.html#af0634ee08b55573cd496bccbd0457fd3", null ],
    [ "remove", "classgx__preset_1_1_plugin_preset_list.html#aeabd7608f2e8ae4a3d96f46a4a6b10b8", null ],
    [ "save", "classgx__preset_1_1_plugin_preset_list.html#a02bb75eede640cc17b157d413cfa5774", null ],
    [ "set", "classgx__preset_1_1_plugin_preset_list.html#a4bee6c9088df119d503f7ebb2d35ad3d", null ],
    [ "start", "classgx__preset_1_1_plugin_preset_list.html#a7537b4f20030a612901a5bec0a7334bf", null ],
    [ "write_values", "classgx__preset_1_1_plugin_preset_list.html#a2152ec0a0e9fd524d1de6c9cce54603c", null ],
    [ "filename", "classgx__preset_1_1_plugin_preset_list.html#a237342a865d055f70314261da42ae1cc", null ],
    [ "is", "classgx__preset_1_1_plugin_preset_list.html#ae7e60d0d043da1ae165f1dc9f5cb4134", null ],
    [ "jp", "classgx__preset_1_1_plugin_preset_list.html#a3c5b434dac5ecb45f66f01b39b7f2fbd", null ],
    [ "mctrl", "classgx__preset_1_1_plugin_preset_list.html#afac83964292a7ca4610da3b58c65b5da", null ],
    [ "pmap", "classgx__preset_1_1_plugin_preset_list.html#a65bf75fc7227217816b295ddc7962f52", null ]
];