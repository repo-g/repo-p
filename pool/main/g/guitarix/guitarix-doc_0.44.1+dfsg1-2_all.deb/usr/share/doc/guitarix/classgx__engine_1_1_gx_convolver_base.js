var classgx__engine_1_1_gx_convolver_base =
[
    [ "GxConvolverBase", "classgx__engine_1_1_gx_convolver_base.html#a2aeaf4dd492daab2ef80db7857a045a3", null ],
    [ "~GxConvolverBase", "classgx__engine_1_1_gx_convolver_base.html#a78bddfb67deda11598e3ee101abcc10d", null ],
    [ "adjust_values", "classgx__engine_1_1_gx_convolver_base.html#a8220c41faf55e9751c1eb8f9ca5245be", null ],
    [ "checkstate", "classgx__engine_1_1_gx_convolver_base.html#ad464afedc67242c8de8a7529d23e11a4", null ],
    [ "get_buffersize", "classgx__engine_1_1_gx_convolver_base.html#a423e4b5831a230f35254a477d992413d", null ],
    [ "get_samplerate", "classgx__engine_1_1_gx_convolver_base.html#a20a6c9f607a2c24ecfd7b4f99951a524", null ],
    [ "is_runnable", "classgx__engine_1_1_gx_convolver_base.html#a00dae86576e589b2dfd3de21c88e6b0b", null ],
    [ "set_buffersize", "classgx__engine_1_1_gx_convolver_base.html#af6e1dba4db349a65b17b6e00928a30c8", null ],
    [ "set_not_runnable", "classgx__engine_1_1_gx_convolver_base.html#a2c7992287f610b27f1db22aa08ce0c27", null ],
    [ "set_samplerate", "classgx__engine_1_1_gx_convolver_base.html#a3dc18d647c3dcc79ead440562da08c34", null ],
    [ "set_sync", "classgx__engine_1_1_gx_convolver_base.html#ac4c4796120b090889b61fcb2a68332af", null ],
    [ "start", "classgx__engine_1_1_gx_convolver_base.html#ad77f9b142103c6b050f31a8872706804", null ],
    [ "buffersize", "classgx__engine_1_1_gx_convolver_base.html#a54a29b9ab6b4a90bbe4255fc5457f65c", null ],
    [ "ready", "classgx__engine_1_1_gx_convolver_base.html#a0ce0470ec1b096b51a22adf60a89bfdd", null ],
    [ "samplerate", "classgx__engine_1_1_gx_convolver_base.html#ac25a7f2d18f6dd934940cf61df0d9a48", null ],
    [ "sync", "classgx__engine_1_1_gx_convolver_base.html#a6c8e03fb7d4d2cb5b28ef425adbbb33e", null ]
];