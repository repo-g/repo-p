var classgx__jconv_1_1_i_r_window_1_1_model_columns =
[
    [ "ModelColumns", "classgx__jconv_1_1_i_r_window_1_1_model_columns.html#a30afc9b9aa98f60aad25dbdf261c25aa", null ],
    [ "displayname", "classgx__jconv_1_1_i_r_window_1_1_model_columns.html#a3250d7e9b37a9c97481c3ee440001402", null ],
    [ "filename", "classgx__jconv_1_1_i_r_window_1_1_model_columns.html#a711317cec8d3ff1f97734e78454ee145", null ]
];