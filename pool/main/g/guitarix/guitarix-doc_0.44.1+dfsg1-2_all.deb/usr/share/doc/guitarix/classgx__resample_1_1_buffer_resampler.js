var classgx__resample_1_1_buffer_resampler =
[
    [ "process", "classgx__resample_1_1_buffer_resampler.html#a8cc1e17c540e7134bc94270953da4206", null ]
];