var classgx__engine_1_1_contrast_convolver =
[
    [ "ContrastConvolver", "classgx__engine_1_1_contrast_convolver.html#ad596f054ddd3aca1d2a41e5e90ba1ea0", null ],
    [ "~ContrastConvolver", "classgx__engine_1_1_contrast_convolver.html#a035aa10e70a91c9c896b721659bbdb79", null ],
    [ "check_update", "classgx__engine_1_1_contrast_convolver.html#a3aea323d6dfa5cd33d84a017b83301d0", null ],
    [ "do_update", "classgx__engine_1_1_contrast_convolver.html#ab98ac81e8e53c4bec294477de5aabeba", null ],
    [ "register_con", "classgx__engine_1_1_contrast_convolver.html#a34c2e11a068b5e88bb9a54b45a95ce48", null ],
    [ "run_contrast", "classgx__engine_1_1_contrast_convolver.html#a9bbeb64c186d254ebc15ed1bb7be09c8", null ],
    [ "start", "classgx__engine_1_1_contrast_convolver.html#a70ff9ba7662be10c4de2d167ddd0e2bf", null ],
    [ "sum_changed", "classgx__engine_1_1_contrast_convolver.html#a95d5589b3fe2682b61b040aaf1029fa0", null ],
    [ "update_sum", "classgx__engine_1_1_contrast_convolver.html#a7b35567ce91761d01c678994c47f5324", null ],
    [ "level", "classgx__engine_1_1_contrast_convolver.html#ae5259c8f1be84d5f12eccbf34889f6e4", null ],
    [ "presl", "classgx__engine_1_1_contrast_convolver.html#ae4e793ebe98e3892a16b1a15c1bbee53", null ],
    [ "smp", "classgx__engine_1_1_contrast_convolver.html#a352e9a2984e914ff26429865b7fda242", null ],
    [ "sum", "classgx__engine_1_1_contrast_convolver.html#a62e117338665002836c6c4d9d4f8d82a", null ]
];