var class_text_logging_box =
[
    [ "tab_table", "struct_text_logging_box_1_1tab__table.html", "struct_text_logging_box_1_1tab__table" ],
    [ "TextLoggingBox", "class_text_logging_box.html#a6444fefa39bd5e0985effca43966b0e7", null ],
    [ "~TextLoggingBox", "class_text_logging_box.html#ab972a167d5b9ae38d346bf17a85b971d", null ],
    [ "get_unseen_msg_level", "class_text_logging_box.html#a230704ac1744570f0f2814e300328be1", null ],
    [ "on_hide", "class_text_logging_box.html#a004370ed46c2dc1b110641aad7d773eb", null ],
    [ "on_key_press_event", "class_text_logging_box.html#ad59d8c793f48231c7f03f2f055d71171", null ],
    [ "on_show", "class_text_logging_box.html#ae6bdd2a1864b228a331a9afb0ca226c2", null ],
    [ "reset_msg_level", "class_text_logging_box.html#a257ebb8b1d6055d25e0a04f193b44a15", null ],
    [ "show_msg", "class_text_logging_box.html#a916f10c5ef98efc6e4051735de3526c6", null ],
    [ "signal_msg_level_changed", "class_text_logging_box.html#a213bb75295155f52179e90585183cd8f", null ],
    [ "box", "class_text_logging_box.html#a03483fe7b6ec834cedf8f65141422438", null ],
    [ "buttonbox", "class_text_logging_box.html#a8ef4fd07ce1582d4bda14250004a4498", null ],
    [ "highest_unseen_msg_level", "class_text_logging_box.html#a7fd1b91b00937b752dbcc079d5abd9e7", null ],
    [ "msg_level_changed", "class_text_logging_box.html#a8156148a43ca739048f66d3641ca0da3", null ],
    [ "ok_button", "class_text_logging_box.html#a31237ce7a91f02144cb397a33fa4a18e", null ],
    [ "scrollbox", "class_text_logging_box.html#a4b5eee861c228ce2640c20ed61785e60", null ],
    [ "tagdefs", "class_text_logging_box.html#afd6711b26f2f5b4dcf975c5ed7a3ff27", null ],
    [ "tags", "class_text_logging_box.html#ab13e0a85ead022c91157442bebf2fe33", null ],
    [ "tbox", "class_text_logging_box.html#a3564c3f29b95fb43b8466eb42674ad8b", null ]
];