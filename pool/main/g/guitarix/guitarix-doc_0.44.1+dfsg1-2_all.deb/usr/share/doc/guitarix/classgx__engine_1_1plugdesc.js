var classgx__engine_1_1plugdesc =
[
    [ "plugdesc", "classgx__engine_1_1plugdesc.html#a7932bccb11a1e799c9c06f657e2201a7", null ],
    [ "~plugdesc", "classgx__engine_1_1plugdesc.html#abe2a9cc537ceafc0f6f36f28b77b1ad5", null ],
    [ "readJSON", "classgx__engine_1_1plugdesc.html#a0a234657ffaf360bfd21b5cf13fb5c5b", null ],
    [ "writeJSON", "classgx__engine_1_1plugdesc.html#aa530a4201b07f52ed4995bd597bb2883", null ],
    [ "LadspaLoader", "classgx__engine_1_1plugdesc.html#ae29b88fd44b1115c623723fe5fe9c25e", null ],
    [ "add_wet_dry", "classgx__engine_1_1plugdesc.html#aebb03d89ace8c3e87675caa981a6349f", null ],
    [ "category", "classgx__engine_1_1plugdesc.html#aa767b9cdbb57d17bc118a1221bfac023", null ],
    [ "id_str", "classgx__engine_1_1plugdesc.html#a2c99bbf5182776e3b4079d5bb9b88fda", null ],
    [ "index", "classgx__engine_1_1plugdesc.html#a6106e7fd880952d55108ef8063ad4ff6", null ],
    [ "Label", "classgx__engine_1_1plugdesc.html#a279952936e27f04dffdd629ad17f596c", null ],
    [ "master_idx", "classgx__engine_1_1plugdesc.html#a9e44e4af3f6f1e0352853fce7fcb4df4", null ],
    [ "master_label", "classgx__engine_1_1plugdesc.html#a2be3d1a2ec9ba37cae811796f98a31b5", null ],
    [ "names", "classgx__engine_1_1plugdesc.html#a991c1fdb963355dd999e3fe1a86c183f", null ],
    [ "path", "classgx__engine_1_1plugdesc.html#abc5f71320354ac536183c5896aa80586", null ],
    [ "quirks", "classgx__engine_1_1plugdesc.html#ab5503c687352bede34e4f63c5509bba6", null ],
    [ "shortname", "classgx__engine_1_1plugdesc.html#a8c61dcb1ac47f2029ab1a3162e8a466a", null ],
    [ "stereo_to_mono", "classgx__engine_1_1plugdesc.html#a7a12bb99505cea188dd72847a854c441", null ],
    [ "UniqueID", "classgx__engine_1_1plugdesc.html#a5e6b4ec21bc2eaa2d6ee21318b0cae75", null ]
];