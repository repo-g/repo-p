var classgx__gui_1_1_gx_h_frame =
[
    [ "GxHFrame", "classgx__gui_1_1_gx_h_frame.html#a5dbc8327c6f78cf67e29cdcdc69a6cd0", null ],
    [ "~GxHFrame", "classgx__gui_1_1_gx_h_frame.html#aaca62f96119bc678cdd252b2ae57d5ba", null ],
    [ "m_hbox", "classgx__gui_1_1_gx_h_frame.html#a717f568549abd1d9fcbfebed59e2b218", null ],
    [ "m_label", "classgx__gui_1_1_gx_h_frame.html#a28f050e06777ff3544a737ea3e1f4d72", null ]
];