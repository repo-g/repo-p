var classgx__gui_1_1_gx_notebook_box =
[
    [ "GxNotebookBox", "classgx__gui_1_1_gx_notebook_box.html#a25c9851bb330af87b29660d0585ac7cb", null ]
];