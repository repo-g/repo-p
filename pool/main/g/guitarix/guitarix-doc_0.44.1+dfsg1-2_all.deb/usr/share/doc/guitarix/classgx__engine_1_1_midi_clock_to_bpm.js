var classgx__engine_1_1_midi_clock_to_bpm =
[
    [ "MidiClockToBpm", "classgx__engine_1_1_midi_clock_to_bpm.html#a64a8aecc95edf57fcb84df8e7680775e", null ],
    [ "~MidiClockToBpm", "classgx__engine_1_1_midi_clock_to_bpm.html#ac76e6036fdae655fae5925fa9e829c43", null ],
    [ "rounded", "classgx__engine_1_1_midi_clock_to_bpm.html#a28491c47db15d02dad6ae0c74a4f7ec8", null ],
    [ "time_to_bpm", "classgx__engine_1_1_midi_clock_to_bpm.html#ae0eed43241867f3a9a8aeb6fbf4b034e", null ],
    [ "bpm", "classgx__engine_1_1_midi_clock_to_bpm.html#a0642132ea052763fc67e9806b6df124a", null ],
    [ "bpm_new", "classgx__engine_1_1_midi_clock_to_bpm.html#a807234717848bee64387a521ffa84efb", null ],
    [ "collect", "classgx__engine_1_1_midi_clock_to_bpm.html#aba90acc0647b828fe8d0604d7471c23f", null ],
    [ "collect_", "classgx__engine_1_1_midi_clock_to_bpm.html#aafcf6c4414f4dce74858c22b96da186d", null ],
    [ "ret", "classgx__engine_1_1_midi_clock_to_bpm.html#a1f12a73b321768ca57eaa86c0eafb048", null ],
    [ "time1", "classgx__engine_1_1_midi_clock_to_bpm.html#a28475416bd633007b809441ac18283ce", null ],
    [ "time_diff", "classgx__engine_1_1_midi_clock_to_bpm.html#a1bd2a80e5087564f93c4d814ea507fe1", null ]
];