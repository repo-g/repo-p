var classgx__gui_1_1_ui_v_switch_with_caption =
[
    [ "UiVSwitchWithCaption", "classgx__gui_1_1_ui_v_switch_with_caption.html#a90eb30d6a9683c6a181024b6759520ea", null ],
    [ "get_regler", "classgx__gui_1_1_ui_v_switch_with_caption.html#ad62dd041bb5df3fea3cd2f2df825b711", null ],
    [ "set_rack_label_inverse", "classgx__gui_1_1_ui_v_switch_with_caption.html#aa33a5e28c3fd66f6f51dfe0509cd10d1", null ],
    [ "m_hbox", "classgx__gui_1_1_ui_v_switch_with_caption.html#a6517dcdb7b94444cb9d18e6bc2c8a5c9", null ],
    [ "m_hbox1", "classgx__gui_1_1_ui_v_switch_with_caption.html#afb0d5fc860774900a13f0fb5af036336", null ],
    [ "m_hbox2", "classgx__gui_1_1_ui_v_switch_with_caption.html#aaa67e08b1be4feb0a31b3984502141ec", null ],
    [ "m_label", "classgx__gui_1_1_ui_v_switch_with_caption.html#af4e40237b307c75a1e4d75cfbed216f5", null ],
    [ "m_switch", "classgx__gui_1_1_ui_v_switch_with_caption.html#a088fdc1e9e85af4ad4aebe62a03f4e9c", null ]
];