var classgx__seq_1_1_u_preset_list_store_1_1_u_preset_list_columns =
[
    [ "UPresetListColumns", "classgx__seq_1_1_u_preset_list_store_1_1_u_preset_list_columns.html#a52157ec6a1d3b6894c73675732a5fde0", null ],
    [ "name", "classgx__seq_1_1_u_preset_list_store_1_1_u_preset_list_columns.html#a2c15ae904fb7039e6180dcc0e23a446f", null ]
];