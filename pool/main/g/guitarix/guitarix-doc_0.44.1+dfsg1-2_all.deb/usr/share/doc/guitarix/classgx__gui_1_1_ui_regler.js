var classgx__gui_1_1_ui_regler =
[
    [ "UiRegler", "classgx__gui_1_1_ui_regler.html#ad18a8c644c150efcc2f7de6448770e54", null ],
    [ "base", "classgx__gui_1_1_ui_regler.html#a4cf4cebded378b8860e9a8a724aeb4f0", null ]
];