var classgx__gui_1_1_cp_base =
[
    [ "CpBase", "classgx__gui_1_1_cp_base.html#ad99526799d2b5e99e7d68c180f97f13f", null ],
    [ "~CpBase", "classgx__gui_1_1_cp_base.html#a2859a9167ee217024297ee688fbfaa7c", null ],
    [ "init", "classgx__gui_1_1_cp_base.html#a1e7fe168473ec6e16649fe6e62aaa804", null ]
];