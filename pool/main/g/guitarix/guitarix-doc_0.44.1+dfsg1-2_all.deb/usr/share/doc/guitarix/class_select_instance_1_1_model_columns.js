var class_select_instance_1_1_model_columns =
[
    [ "ModelColumns", "class_select_instance_1_1_model_columns.html#ad9dc7ec47c59fe97fdb490ffc3576e8b", null ],
    [ "name", "class_select_instance_1_1_model_columns.html#a37c48df49bc991ea281b26afb073dbe4", null ]
];