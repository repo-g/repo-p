var classgx__preset_1_1_plugin_preset_entry =
[
    [ "PluginPresetEntry", "classgx__preset_1_1_plugin_preset_entry.html#a715e273dd79cf05110b3835dc027277a", null ],
    [ "is_set", "classgx__preset_1_1_plugin_preset_entry.html#a3106cd7b869bf4ad88f68897cbd6fb45", null ],
    [ "name", "classgx__preset_1_1_plugin_preset_entry.html#ae4dd5e1d37fe7884e8791ada2190d9c0", null ]
];