var class_avahi_service =
[
    [ "AvahiService", "class_avahi_service.html#a8ddce72bf541a56ea6f1db71f1fb1e07", null ],
    [ "~AvahiService", "class_avahi_service.html#aa2ca5abb0f95292742a5a792779d0e73", null ],
    [ "register_service", "class_avahi_service.html#a89fd43c3284efc05ef06a578d55a3a89", null ],
    [ "state_changed", "class_avahi_service.html#a9c4b09c7b93cb8a255900efeac2b9a82", null ],
    [ "client", "class_avahi_service.html#af12e45ba2a6af990743c0f928af17e89", null ],
    [ "current_name", "class_avahi_service.html#a57c670654cd43ce52eeec8244c9d3908", null ],
    [ "group", "class_avahi_service.html#a0006e775b816c7970eaf970b379f138f", null ],
    [ "registered_port", "class_avahi_service.html#a3c565817f63828c36d7f972c586a0440", null ]
];