var class_target_model_columns =
[
    [ "TargetModelColumns", "class_target_model_columns.html#a138c8413598831883121a3d3713b9f3f", null ],
    [ "name", "class_target_model_columns.html#acd8159ed64c24b2a0a6c187d395360cc", null ]
];