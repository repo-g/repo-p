var classgx__engine_1_1_oscilloscope_info =
[
    [ "OscilloscopeInfo", "classgx__engine_1_1_oscilloscope_info.html#adbde348dd5a359507c9d43e809f5083a", null ],
    [ "get_buffer", "classgx__engine_1_1_oscilloscope_info.html#ab79839fac9ef8a3554295b62829942d8", null ],
    [ "get_buffer_size", "classgx__engine_1_1_oscilloscope_info.html#a643e7b3030116cb902c64cbd62eb7e9f", null ],
    [ "readJSON", "classgx__engine_1_1_oscilloscope_info.html#ad5aa22f35aa5002f0ace16d139089828", null ],
    [ "signal_size_change", "classgx__engine_1_1_oscilloscope_info.html#a340e70b5c2680967e8e07e5535362fd2", null ],
    [ "update", "classgx__engine_1_1_oscilloscope_info.html#a66995d60e89b969f61fce82dcf9545c5", null ],
    [ "writeJSON", "classgx__engine_1_1_oscilloscope_info.html#a5775364c7aeee1d1c3dfcf926ceeacac", null ],
    [ "OscilloscopeAdapter", "classgx__engine_1_1_oscilloscope_info.html#ae099d23670855fd2c4f8cc64c7473e7c", null ],
    [ "bsize", "classgx__engine_1_1_oscilloscope_info.html#ab0156681c842e8a6bd3c0a8d72c8e4e2", null ],
    [ "buffer", "classgx__engine_1_1_oscilloscope_info.html#adfa4d8ea9afdf25859abb27ac621e2ee", null ],
    [ "buffer_size", "classgx__engine_1_1_oscilloscope_info.html#af87d5d1eaddff78a53043da2a12e7049", null ],
    [ "frames", "classgx__engine_1_1_oscilloscope_info.html#a1e3342c474c7e460307997be4a893212", null ],
    [ "is_rt", "classgx__engine_1_1_oscilloscope_info.html#a6782cd32e161f7fed8dc6f32e8758a7b", null ],
    [ "jack", "classgx__engine_1_1_oscilloscope_info.html#ab45c46568ce71f5982a5778bdf31e4c7", null ],
    [ "load", "classgx__engine_1_1_oscilloscope_info.html#a02edc6e044b37b8a19f8739d808342bc", null ],
    [ "size_change", "classgx__engine_1_1_oscilloscope_info.html#aaae0125e883195d7d9675c7cfd8e44fe", null ]
];