var classgx__gui_1_1_ui_regler_with_caption =
[
    [ "UiReglerWithCaption", "classgx__gui_1_1_ui_regler_with_caption.html#a1544274c3845133d321d95ae89433be6", null ],
    [ "get_regler", "classgx__gui_1_1_ui_regler_with_caption.html#a60aeaeefbe5b92cb196d030984bdd493", null ],
    [ "regler", "classgx__gui_1_1_ui_regler_with_caption.html#a0c6937cbb65124f2b8b101d091fb0e08", null ]
];