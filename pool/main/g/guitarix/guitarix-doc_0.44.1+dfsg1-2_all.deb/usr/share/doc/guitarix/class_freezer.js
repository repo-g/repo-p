var class_freezer =
[
    [ "Freezer", "class_freezer.html#ae83be5e690760c93b65cb4a8fd319475", null ],
    [ "~Freezer", "class_freezer.html#ab215b2c95471b2bcd483867059e00dfc", null ],
    [ "check_thaw", "class_freezer.html#aa15c1fd9fa8caac9015450670bac3e1a", null ],
    [ "do_thaw", "class_freezer.html#a1cf104022775e83652c5a0b302a8eb58", null ],
    [ "freeze", "class_freezer.html#a4acb4de32d685c57d64e4feb3713dfff", null ],
    [ "freeze_and_size_request", "class_freezer.html#a41221117673c60240a9d86de0488d3dd", null ],
    [ "freeze_until_width_update", "class_freezer.html#a38dcd52e1fc150a7d56f4ba97fc55915", null ],
    [ "set_slot", "class_freezer.html#aa185c5b405bf4ae08c4e26aaa7113977", null ],
    [ "thaw", "class_freezer.html#ab146e884f61dbf1e20f79cc69a80d356", null ],
    [ "thaw_timeout", "class_freezer.html#a36947a208a5989349b4493570ff0d661", null ],
    [ "need_thaw", "class_freezer.html#a00f518f0b5f0636c60abb076a73a0435", null ],
    [ "size_x", "class_freezer.html#a94b004a24880467c53f75011faf1bc71", null ],
    [ "size_y", "class_freezer.html#a8fd96c7f2d8a76c514c7703bc3a625b0", null ],
    [ "tag", "class_freezer.html#aa8907f3ad57ed64d76c4b7cec05fd0fe", null ],
    [ "window", "class_freezer.html#a4181bf588487f614603a7bbbe3dc6212", null ],
    [ "work", "class_freezer.html#aa8a831b4b8d14926392ae35895b543ba", null ]
];