var classgx__main__midi_1_1_midi_connect =
[
    [ "MidiConnect", "classgx__main__midi_1_1_midi_connect.html#a7dfdb70a4ad14ea924dc211ee9a94476", null ],
    [ "changed_text_handler", "classgx__main__midi_1_1_midi_connect.html#abad6784a708803b17be5cdfe597a1938", null ],
    [ "check_midi_cb", "classgx__main__midi_1_1_midi_connect.html#ad8832b550e103771832ed441e74b87d3", null ],
    [ "ctl_to_str", "classgx__main__midi_1_1_midi_connect.html#a9088bdd1826849351bd465521745da7d", null ],
    [ "ctr_desc", "classgx__main__midi_1_1_midi_connect.html#ad3821d1ca7086715dc2e06abb56d12bf", null ],
    [ "midi_destroy_cb", "classgx__main__midi_1_1_midi_connect.html#a744dff8e4346f5eda2f0c376ca65d6d1", null ],
    [ "midi_response_cb", "classgx__main__midi_1_1_midi_connect.html#a6ffc6fe2699fe85bc124cf21c984d7fc", null ],
    [ "toggle_behaviours_visibility", "classgx__main__midi_1_1_midi_connect.html#a0aaa80825910b42e0c49151bf3d33685", null ],
    [ "adj_lower", "classgx__main__midi_1_1_midi_connect.html#aea6a2d8d2c5173966e19d94a4f7165c2", null ],
    [ "adj_upper", "classgx__main__midi_1_1_midi_connect.html#a0359924c2dfc7c2c1da8f898055803a5", null ],
    [ "current_control", "classgx__main__midi_1_1_midi_connect.html#a057aba85fdc8b65af89dff8106508020", null ],
    [ "dialog", "classgx__main__midi_1_1_midi_connect.html#a6b90cc2a05628e97ad4e9577f03c8314", null ],
    [ "entry_new", "classgx__main__midi_1_1_midi_connect.html#ab70f617dbf7b3c508d4993e34dd46994", null ],
    [ "label_desc", "classgx__main__midi_1_1_midi_connect.html#a379364f6188d17758a17058752bb5325", null ],
    [ "machine", "classgx__main__midi_1_1_midi_connect.html#aba4a2e6bc42945baff80ed54f7f23d11", null ],
    [ "param", "classgx__main__midi_1_1_midi_connect.html#a7b9db8ad3fd622370eb039c4bb03208f", null ],
    [ "store", "classgx__main__midi_1_1_midi_connect.html#a500273d89e16f2167ffaa8d0477b9763", null ],
    [ "toggle_behaviour_descriptions", "classgx__main__midi_1_1_midi_connect.html#ab7995f12785d28b14869e0592377b402", null ],
    [ "toggle_behaviours", "classgx__main__midi_1_1_midi_connect.html#af079e9b66fe93c3603c6f4762769b67c", null ],
    [ "use_toggle", "classgx__main__midi_1_1_midi_connect.html#af23de07caeb9d22045dc8a21396ef7cd", null ]
];