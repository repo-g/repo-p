var classgx__child__process_1_1_gx_child =
[
    [ "GxChild", "classgx__child__process_1_1_gx_child.html#ad3898c4dec2ff914dd071f89e4dce4e2", null ],
    [ "hasName", "classgx__child__process_1_1_gx_child.html#ab703c4b6f741b6fadf453ebfc9e60d2b", null ],
    [ "hasPid", "classgx__child__process_1_1_gx_child.html#a75a6061951ffb563aefb7be1fc7abf37", null ],
    [ "kill", "classgx__child__process_1_1_gx_child.html#a69645b89d315640da359ad2baa8c8756", null ],
    [ "GxChildProcs", "classgx__child__process_1_1_gx_child.html#a0ccf14aeea8d14588df92439534d9c55", null ],
    [ "m_killsignal", "classgx__child__process_1_1_gx_child.html#a9fe9ee9fce90ab15c54e9df202598cee", null ],
    [ "m_name", "classgx__child__process_1_1_gx_child.html#a8677e69937cd0350d133cf5f7a54435b", null ],
    [ "m_pid", "classgx__child__process_1_1_gx_child.html#ae710fc012fd6aec2947059aa53ef6b04", null ],
    [ "terminated", "classgx__child__process_1_1_gx_child.html#aaeb7a7f006464ce26eb843537de8b559", null ]
];