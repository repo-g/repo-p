var class_bank_model_columns =
[
    [ "BankModelColumns", "class_bank_model_columns.html#aa2504c2aab17620a3d68fffd9f1cd2c2", null ],
    [ "del_pb", "class_bank_model_columns.html#a8dd861843406baf6ae221901f84cf2f4", null ],
    [ "edit_pb", "class_bank_model_columns.html#ae44194d737b1233dab1517f90e7a0499", null ],
    [ "name", "class_bank_model_columns.html#ab763cbf2ca3d877e23472144486aa602", null ],
    [ "tp", "class_bank_model_columns.html#a9884029dc98b2d1d2e21211601f79314", null ],
    [ "type_pb", "class_bank_model_columns.html#aeb542fa7187f94f1371bc0d023cbe757", null ]
];