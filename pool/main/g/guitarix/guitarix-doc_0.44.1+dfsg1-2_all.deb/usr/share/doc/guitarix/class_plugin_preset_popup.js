var class_plugin_preset_popup =
[
    [ "PluginPresetPopup", "class_plugin_preset_popup.html#a0709841af2546cc62589b6d03a2b647e", null ],
    [ "add_plugin_preset_list", "class_plugin_preset_popup.html#abfb27164945ac6010bb9744c986f8314", null ],
    [ "begin", "class_plugin_preset_popup.html#a3e362c9a89816273c7c7de19ea6fca9b", null ],
    [ "end", "class_plugin_preset_popup.html#a911f1f4adb35dce06b768334baf4701a", null ],
    [ "get_machine", "class_plugin_preset_popup.html#aca1ac84d6edc3d161dd5add8a3c40b5c", null ],
    [ "get_pdef", "class_plugin_preset_popup.html#a15a878a922a8e156812a8f0a5c8d63f5", null ],
    [ "on_selection_done", "class_plugin_preset_popup.html#a25dd014d3813016c57004498c90c17c1", null ],
    [ "remove_plugin_preset", "class_plugin_preset_popup.html#a665e668f89e7c111ca156368e037fa91", null ],
    [ "save_plugin_preset", "class_plugin_preset_popup.html#a98b2a2969f2cb72006218d60d12c22d0", null ],
    [ "set_plugin_preset", "class_plugin_preset_popup.html#ae23366a28d81d6861345bc893458c375", null ],
    [ "set_plugin_std_preset", "class_plugin_preset_popup.html#a05cabebd7e6279b748ddcb63810e87ea", null ],
    [ "machine", "class_plugin_preset_popup.html#a5eb72bcb5aa6fd43cb6584b0fcf60ddb", null ],
    [ "pdef", "class_plugin_preset_popup.html#a30b1be782a128537f23ea6d3219e0321", null ],
    [ "presetnames", "class_plugin_preset_popup.html#ad5ae5de57875f4f5896c5e5346c2108b", null ],
    [ "save_name_default", "class_plugin_preset_popup.html#a6126258cdde591e05ba54e7efcaadea7", null ]
];