var classgx__preset_1_1_unit_racks =
[
    [ "UnitRacks", "classgx__preset_1_1_unit_racks.html#a5a3af7274309632a0487dcc881d4b79d", null ],
    [ "mono", "classgx__preset_1_1_unit_racks.html#a6dc507c6c058de718474467c1299f508", null ],
    [ "rack_unit_order_changed", "classgx__preset_1_1_unit_racks.html#a6472db31a7331c2d80880fb978fec2c1", null ],
    [ "stereo", "classgx__preset_1_1_unit_racks.html#ada8a304cee83eca8383864e6b156f6af", null ]
];