var class_gx_exit =
[
    [ "GxExit", "class_gx_exit.html#a9317d231b9d95f6e66900871902cb98d", null ],
    [ "~GxExit", "class_gx_exit.html#ad3a7b7aecb3daa8f9cdf66449238c881", null ],
    [ "exit_program", "class_gx_exit.html#ae32da1ffa201cbc7cafd54e330c39a5d", null ],
    [ "fatal_msg", "class_gx_exit.html#ad76bf3ae409e1771e2823c5fdd777f1e", null ],
    [ "get_instance", "class_gx_exit.html#a5ff837c97f04a01615f9a82a1a2b05ab", null ],
    [ "set_ui_thread", "class_gx_exit.html#abe5e3dce980caa9283fa1ebe87c9854b", null ],
    [ "signal_exit", "class_gx_exit.html#acd13e48377b33c41683de12eb03156a0", null ],
    [ "signal_msg", "class_gx_exit.html#a30d454934c0f10c69507f40679ac26f7", null ],
    [ "exit_sig", "class_gx_exit.html#a683e7bbdae3a746482b7a29b2942b632", null ],
    [ "message", "class_gx_exit.html#ab9e375bc888b29643371f87b0a9b91c8", null ],
    [ "ui_thread", "class_gx_exit.html#a7973cfdfb760324d11d137c409816a7a", null ]
];