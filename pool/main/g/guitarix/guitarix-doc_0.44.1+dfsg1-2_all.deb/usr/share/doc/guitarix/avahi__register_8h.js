var avahi__register_8h =
[
    [ "AvahiService", "class_avahi_service.html", "class_avahi_service" ],
    [ "SRC_HEADERS_AVAHI_REGISTER_H_", "avahi__register_8h.html#aca62ca820bc43da5e63134669a69b9f4", null ]
];