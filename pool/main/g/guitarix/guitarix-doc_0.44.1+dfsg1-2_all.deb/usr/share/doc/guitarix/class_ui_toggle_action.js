var class_ui_toggle_action =
[
    [ "UiToggleAction", "class_ui_toggle_action.html#a09277be0d4cef09659cb718206274e36", null ],
    [ "~UiToggleAction", "class_ui_toggle_action.html#a0250bec8c14c5130998689a428fae232", null ],
    [ "create", "class_ui_toggle_action.html#aaad144aa156b1ea1d148d6703b0fc642", null ],
    [ "on_toggled", "class_ui_toggle_action.html#af6d3caa43d5933c6b6e0c3eaf800dc39", null ],
    [ "id", "class_ui_toggle_action.html#adfdfb74ece0cbed75c3d27562693c932", null ],
    [ "machine", "class_ui_toggle_action.html#a6a2d841a69e333690b25f7dae9747601", null ]
];