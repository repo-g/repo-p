var classgx__engine_1_1_oscilloscope_adapter =
[
    [ "OscilloscopeAdapter", "classgx__engine_1_1_oscilloscope_adapter.html#a3456fdf7b548123b201ee0fad9253c48", null ],
    [ "change_buffersize", "classgx__engine_1_1_oscilloscope_adapter.html#a62e987526e9cd32172f55b9a7a2a6e2d", null ],
    [ "clear_buffer", "classgx__engine_1_1_oscilloscope_adapter.html#a5f301ce82d6faed25b218370f4f79095", null ],
    [ "fill_buffer", "classgx__engine_1_1_oscilloscope_adapter.html#a7e24707fec7fdd8e2967e01288ea1fee", null ],
    [ "get_buffer", "classgx__engine_1_1_oscilloscope_adapter.html#a3b04d716f9041e8ad4078f6a33f18f8a", null ],
    [ "get_mul_buffer", "classgx__engine_1_1_oscilloscope_adapter.html#a873f41ff2d1c1bd6c1f6a5cd8cce5ed4", null ],
    [ "get_size", "classgx__engine_1_1_oscilloscope_adapter.html#ac796972fdc7fdb86d40dc52fd8edb052", null ],
    [ "osc_load_ui", "classgx__engine_1_1_oscilloscope_adapter.html#a54ea90b9f37a03c54913287796baf85e", null ],
    [ "osc_register", "classgx__engine_1_1_oscilloscope_adapter.html#a27edf62634914990cb0b2b924c1ecd3e", null ],
    [ "set_jack", "classgx__engine_1_1_oscilloscope_adapter.html#a1a14696baad71e940aaa986899c639ed", null ],
    [ "set_mul_buffer", "classgx__engine_1_1_oscilloscope_adapter.html#a41fd05f0deaeaefcb475b7ea020804f7", null ],
    [ "info", "classgx__engine_1_1_oscilloscope_adapter.html#aeb14be32d895be7d9c91d22a80725b5d", null ],
    [ "mul_buffer", "classgx__engine_1_1_oscilloscope_adapter.html#abe902cd0e25527c0b80df89961a52b3c", null ],
    [ "plugin", "classgx__engine_1_1_oscilloscope_adapter.html#a9ab424a9c8a8e248d3df0630c9cb0521", null ],
    [ "pmap", "classgx__engine_1_1_oscilloscope_adapter.html#a249bca63dfd5a9f4523e7cba6e8dde81", null ]
];