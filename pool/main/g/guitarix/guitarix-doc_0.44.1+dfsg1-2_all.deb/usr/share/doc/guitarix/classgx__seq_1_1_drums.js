var classgx__seq_1_1_drums =
[
    [ "Drums", "classgx__seq_1_1_drums.html#a93060024f2cc907f43d38db2543e07cc", null ],
    [ "~Drums", "classgx__seq_1_1_drums.html#a7e2d0e8dfdf447c2e4ec6a2976af964d", null ],
    [ "box", "classgx__seq_1_1_drums.html#aff2f6b460b35c3766043b208fcf326a8", null ],
    [ "p", "classgx__seq_1_1_drums.html#abbcb1c95b78c02727b132c57cf6dcc1b", null ]
];