var class_select_midi_channel =
[
    [ "SelectMidiChannel", "class_select_midi_channel.html#a78db33b086cce40eab444320c777d5f2", null ],
    [ "~SelectMidiChannel", "class_select_midi_channel.html#a9e3a5b8baa92a03ad17a71ac097a082f", null ],
    [ "create", "class_select_midi_channel.html#a152bb7290b83107dafc9f1aafb189910", null ],
    [ "create_from_builder", "class_select_midi_channel.html#ae57f3c085cea2a39e13cba8a08ac84d1", null ],
    [ "on_cancel_button", "class_select_midi_channel.html#aa9d17e5010ddb9549abbe58995b53d54", null ],
    [ "on_delete_event", "class_select_midi_channel.html#a54ed0893aff18528be5083b9fd587ab7", null ],
    [ "on_key_press_event", "class_select_midi_channel.html#a6204d87fae94289eb87a6d679f79a8b3", null ],
    [ "on_ok_button", "class_select_midi_channel.html#a6faa008e07bbeb28caaa60b98ee530bb", null ],
    [ "signal_close", "class_select_midi_channel.html#a7d300495db825b7782baeb3d9cfb5af1", null ],
    [ "channelcombo", "class_select_midi_channel.html#aaa93b99c898a18c26a58fe7ea7920d08", null ],
    [ "close", "class_select_midi_channel.html#afc9f14d3003dfc8117731b6e359adac0", null ],
    [ "description", "class_select_midi_channel.html#a2360d310e841509739f937983d325aaf", null ],
    [ "machine", "class_select_midi_channel.html#a7cae06d4ac453f2f1bad77751b629344", null ]
];