var class_gx_fatal_error =
[
    [ "GxFatalError", "class_gx_fatal_error.html#a8b3d71c907ae46d78c4419280366d9d7", null ],
    [ "GxFatalError", "class_gx_fatal_error.html#aaca092ce90160f373ebdf90aa61de6f9", null ],
    [ "~GxFatalError", "class_gx_fatal_error.html#abb467a0f961fa7bbb2cf026c5314faee", null ],
    [ "what", "class_gx_fatal_error.html#a9ba8bdec16d568e003344ae6f5325b5a", null ],
    [ "msg", "class_gx_fatal_error.html#ab1a28e095a3b8941ff86c24693bf7a4d", null ]
];