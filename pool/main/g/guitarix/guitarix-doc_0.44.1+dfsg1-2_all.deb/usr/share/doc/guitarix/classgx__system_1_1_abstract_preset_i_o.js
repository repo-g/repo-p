var classgx__system_1_1_abstract_preset_i_o =
[
    [ "~AbstractPresetIO", "classgx__system_1_1_abstract_preset_i_o.html#a20d1c4adc51ee5edce66ff24ee3d22d4", null ],
    [ "commit_preset", "classgx__system_1_1_abstract_preset_i_o.html#a40e931c88c053607e80a197711ee6b16", null ],
    [ "copy_preset", "classgx__system_1_1_abstract_preset_i_o.html#aba3b67f2e4a54569915fdbe421fc0de1", null ],
    [ "read_preset", "classgx__system_1_1_abstract_preset_i_o.html#a8bcc273c51fff7da665a4a0510ca03fa", null ],
    [ "write_preset", "classgx__system_1_1_abstract_preset_i_o.html#a0942d80d1a5a54b79a0fc4a9e87f4ed1", null ]
];