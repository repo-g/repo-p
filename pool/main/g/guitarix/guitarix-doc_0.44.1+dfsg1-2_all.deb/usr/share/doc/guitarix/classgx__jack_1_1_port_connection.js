var classgx__jack_1_1_port_connection =
[
    [ "conn", "classgx__jack_1_1_port_connection.html#aa575dfc6f0f0c9ad0c972b65e279695b", null ],
    [ "port", "classgx__jack_1_1_port_connection.html#a8ed00988f37b50ce42d42dbf4c540758", null ]
];