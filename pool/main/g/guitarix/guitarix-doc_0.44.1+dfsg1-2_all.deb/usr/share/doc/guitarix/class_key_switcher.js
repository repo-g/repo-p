var class_key_switcher =
[
    [ "KeySwitcher", "class_key_switcher.html#a32f7ff67db300494e5d2af1ea60338c7", null ],
    [ "bank_idx_to_char", "class_key_switcher.html#a04715fb7d3af4d12cd6cf9803f87f570", null ],
    [ "deactivate", "class_key_switcher.html#a1949ceb93f9e2de0cfcea698519e2124", null ],
    [ "display_current", "class_key_switcher.html#ad3008d9686cdbb34efb5d99871827dc0", null ],
    [ "display_empty", "class_key_switcher.html#a6648715761b835494defe12eb8426793", null ],
    [ "display_key_error", "class_key_switcher.html#a01b058f7b54ad67eedda5fdd4f06a042", null ],
    [ "display_selected_bank", "class_key_switcher.html#a746c7794b2104fbb37072e09ab11751d", null ],
    [ "idx_to_char", "class_key_switcher.html#aebe76cb833c542a1e548c3c7658375b2", null ],
    [ "key_offset_to_bank_idx", "class_key_switcher.html#ac9d302701d89d5d09c4e3fbc2b83e823", null ],
    [ "key_offset_to_idx", "class_key_switcher.html#afada3634b73ec48bf96220c627d826ed", null ],
    [ "next_idx", "class_key_switcher.html#a0d779e4a1a59b4006a3efd4d9d141ecc", null ],
    [ "process_bank_key", "class_key_switcher.html#a4725acfb9d8c74d024b847e13d4ef55d", null ],
    [ "process_preset_key", "class_key_switcher.html#adea8ae67133a4acefadf38dc1a87de7c", null ],
    [ "display", "class_key_switcher.html#a6be41fcc8fa12f39b3941e2be2a3f23b", null ],
    [ "key_timeout", "class_key_switcher.html#a9b8335183c969850e27574f17e83471e", null ],
    [ "last_bank_key", "class_key_switcher.html#ac283de44acd5b50d49cffa023cf27793", null ],
    [ "machine", "class_key_switcher.html#ae27907840ceb3df60674341c0d054ac2", null ]
];