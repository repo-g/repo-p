var classgx__jack_1_1_jack_ports =
[
    [ "input", "classgx__jack_1_1_jack_ports.html#a9894adeff8cefd7206d7769c7d870c5d", null ],
    [ "insert_in", "classgx__jack_1_1_jack_ports.html#aabc9f4b61cc1afe721a9b1edfe3616a9", null ],
    [ "insert_out", "classgx__jack_1_1_jack_ports.html#a882e5c4a56c09ef4f6d1ef66dd4d9321", null ],
    [ "midi_input", "classgx__jack_1_1_jack_ports.html#a384d0d0e2a187baf692ea4912b418785", null ],
    [ "midi_output", "classgx__jack_1_1_jack_ports.html#a39d9f397238ff0e0181f4f848d0cb762", null ],
    [ "output1", "classgx__jack_1_1_jack_ports.html#acb9d23f64a707fe15c9022d7095b8e9d", null ],
    [ "output2", "classgx__jack_1_1_jack_ports.html#a281fc2aa8f1995659e11b0af84914568", null ]
];