var classgx__gui_1_1_widget_stack =
[
    [ "WidgetStack", "classgx__gui_1_1_widget_stack.html#ad51da4b1c9100a773d23ff7be9ed8c93", null ],
    [ "~WidgetStack", "classgx__gui_1_1_widget_stack.html#afdd0a8bd74d0743c10b20328bca02019", null ],
    [ "add", "classgx__gui_1_1_widget_stack.html#a5c8a70ce0d8e5eaef8715057e01896ef", null ],
    [ "box_pack_start", "classgx__gui_1_1_widget_stack.html#a0e678558d09607c99fdbfc1008473982", null ],
    [ "container_add", "classgx__gui_1_1_widget_stack.html#a42bfc0fed689c1684a65639c821b2610", null ],
    [ "empty", "classgx__gui_1_1_widget_stack.html#ad31f33c07d221272318ffd1912e063ed", null ],
    [ "notebook_append_page", "classgx__gui_1_1_widget_stack.html#a15f7f6872bbbe9e4265eaaccb7de3443", null ],
    [ "pop", "classgx__gui_1_1_widget_stack.html#aa8185087d11738b42af461c65be8d0f3", null ],
    [ "push", "classgx__gui_1_1_widget_stack.html#a0cdef4176c143340d90d533d2be0a50d", null ],
    [ "top", "classgx__gui_1_1_widget_stack.html#a1874d4a54db4f17007ab262a7ff3360a", null ],
    [ "top_is_notebook", "classgx__gui_1_1_widget_stack.html#ac2b3881f7860bd8d5f544a29cc4be852", null ],
    [ "stack", "classgx__gui_1_1_widget_stack.html#a6b49854e95b862c79898ec905b5fec15", null ]
];