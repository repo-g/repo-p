var avahi__discover_8h =
[
    [ "AvahiBrowser", "class_avahi_browser.html", "class_avahi_browser" ],
    [ "AvahiBrowser::Entry", "struct_avahi_browser_1_1_entry.html", "struct_avahi_browser_1_1_entry" ],
    [ "SelectInstance", "class_select_instance.html", "class_select_instance" ],
    [ "SelectInstance::ModelColumns", "class_select_instance_1_1_model_columns.html", "class_select_instance_1_1_model_columns" ],
    [ "SRC_HEADERS_AVAHI_DISCOVER_H_", "avahi__discover_8h.html#aff492450089d94149ae44c2b90b1d0f4", null ]
];