var class_avahi_browser =
[
    [ "Entry", "struct_avahi_browser_1_1_entry.html", "struct_avahi_browser_1_1_entry" ],
    [ "AvahiBrowser", "class_avahi_browser.html#ad77b528678644ffab34f8f9e9c955ea8", null ],
    [ "~AvahiBrowser", "class_avahi_browser.html#a2ca70cbdc9a6c17603da3695407b170f", null ],
    [ "cache_exhausted", "class_avahi_browser.html#a0286ddb23874b7297ebd6d2c31c6cbe3", null ],
    [ "get_address_port", "class_avahi_browser.html#a0dbfec2ed97626f36198b50fc9b3661f", null ],
    [ "get_service_names", "class_avahi_browser.html#af913310436de791acaf7409626dc81c2", null ],
    [ "invoke_resolver", "class_avahi_browser.html#abfb77dd17dceed995837021fccc19320", null ],
    [ "new_service", "class_avahi_browser.html#a156c7dd69d712b8030677fed49e83bdc", null ],
    [ "on_failure", "class_avahi_browser.html#a9b488b3e743ad2cedc01d246bd52a828", null ],
    [ "on_found", "class_avahi_browser.html#af11ee58de87761b511ab3fcfc23283d0", null ],
    [ "removed_service", "class_avahi_browser.html#a35a8dc619b170d9d69999b3cf577d9ab", null ],
    [ "signal_changed", "class_avahi_browser.html#a7ad5bbddf43f40cdf4ad81a5a1a3c903", null ],
    [ "browser", "class_avahi_browser.html#a33e536fa9eb63b92a8e1c2f23f8b0d81", null ],
    [ "cache_done", "class_avahi_browser.html#a061339b2fdc06059473efbd303636d00", null ],
    [ "changed", "class_avahi_browser.html#adabca92791c1bbcd74bab961f0217670", null ],
    [ "client", "class_avahi_browser.html#aa4dfc5f98cd56edf62136480c5fa3c3f", null ],
    [ "found_host", "class_avahi_browser.html#adb13bfbacfafa9b51e24e74f8b3cc4ac", null ],
    [ "found_name", "class_avahi_browser.html#abd5c9d5c67d438c443315b0f8b539168", null ],
    [ "resolver", "class_avahi_browser.html#a04990ce6cc5f135493ab927a8dacc0bc", null ],
    [ "service_names", "class_avahi_browser.html#a6a08f667ec8e6f9e533ce4470aba32ec", null ],
    [ "services", "class_avahi_browser.html#a98adcf8b74cbcf25bea4a77007f99ac7", null ]
];