var classgx__preset_1_1_unit_position =
[
    [ "UnitPosition", "classgx__preset_1_1_unit_position.html#a6a374f106cb116b42af46148e88764e9", null ],
    [ "position", "classgx__preset_1_1_unit_position.html#a98b2465597c1e1d05469b54a3d22516a", null ],
    [ "pp", "classgx__preset_1_1_unit_position.html#a6a2b40b08226b4428f86a291629e8d1f", null ],
    [ "show", "classgx__preset_1_1_unit_position.html#a671bb38f31bb7ab0bad37aa173cfe64b", null ],
    [ "visible", "classgx__preset_1_1_unit_position.html#a3e17b370e17857d2405faff139e31af2", null ]
];