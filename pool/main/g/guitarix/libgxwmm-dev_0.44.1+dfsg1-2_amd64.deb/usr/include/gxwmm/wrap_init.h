#ifndef GXWMM_WRAP_INIT_H_INCLUDED
#define GXWMM_WRAP_INIT_H_INCLUDED

namespace Gxw { 

void wrap_init();

}

#endif /* GXWMM_WRAP_INIT_H_INCLUDED */
