#ifndef GXWMM_INIT_H_INCLUDED
#define GXWMM_INIT_H_INCLUDED

namespace Gxw { 

void init();

}

#endif /* GXWMM_INIT_H_INCLUDED */
