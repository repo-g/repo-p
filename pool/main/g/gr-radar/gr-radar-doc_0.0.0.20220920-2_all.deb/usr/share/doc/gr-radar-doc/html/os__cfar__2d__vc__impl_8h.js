var os__cfar__2d__vc__impl_8h =
[
    [ "gr::radar::os_cfar_2d_vc_impl", "classgr_1_1radar_1_1os__cfar__2d__vc__impl.html", "classgr_1_1radar_1_1os__cfar__2d__vc__impl" ]
];