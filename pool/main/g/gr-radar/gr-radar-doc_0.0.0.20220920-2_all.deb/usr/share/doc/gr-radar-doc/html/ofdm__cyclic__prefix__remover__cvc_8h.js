var ofdm__cyclic__prefix__remover__cvc_8h =
[
    [ "gr::radar::ofdm_cyclic_prefix_remover_cvc", "classgr_1_1radar_1_1ofdm__cyclic__prefix__remover__cvc.html", "classgr_1_1radar_1_1ofdm__cyclic__prefix__remover__cvc" ]
];