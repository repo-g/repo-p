var classgr_1_1radar_1_1find__max__peak__c =
[
    [ "sptr", "classgr_1_1radar_1_1find__max__peak__c.html#a962152948dcf712183a32732dcd25be7", null ],
    [ "make", "classgr_1_1radar_1_1find__max__peak__c.html#af99e98a6c25874d01375d4325f2e0275", null ],
    [ "set_max_freq", "classgr_1_1radar_1_1find__max__peak__c.html#a85faea414a4ed5966fb7240bc82f2826", null ],
    [ "set_samp_protect", "classgr_1_1radar_1_1find__max__peak__c.html#abaf4240cdb5dcd4af0a88821221861e7", null ],
    [ "set_threshold", "classgr_1_1radar_1_1find__max__peak__c.html#adc7673c9ed04bf49b1ef7e9cb60db989", null ]
];