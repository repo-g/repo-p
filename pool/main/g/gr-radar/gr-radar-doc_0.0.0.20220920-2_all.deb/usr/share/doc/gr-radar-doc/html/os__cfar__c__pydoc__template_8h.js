var os__cfar__c__pydoc__template_8h =
[
    [ "D", "os__cfar__c__pydoc__template_8h.html#a74021f021dcdfbb22891787b79c5529d", null ],
    [ "__doc_gr_radar_os_cfar_c", "os__cfar__c__pydoc__template_8h.html#a4e2c04db1feac6a6989e37eed4f9cded", null ],
    [ "__doc_gr_radar_os_cfar_c_make", "os__cfar__c__pydoc__template_8h.html#af5781452b7ebcb1e49926870d4dc7a2c", null ],
    [ "__doc_gr_radar_os_cfar_c_os_cfar_c_0", "os__cfar__c__pydoc__template_8h.html#ae58b43e8f350e39d3435d5513a3ad5d9", null ],
    [ "__doc_gr_radar_os_cfar_c_os_cfar_c_1", "os__cfar__c__pydoc__template_8h.html#afbb707605bb03153bc3b9d3c79e53652", null ],
    [ "__doc_gr_radar_os_cfar_c_set_mult_threshold", "os__cfar__c__pydoc__template_8h.html#aaac34267ea55918b8f6ca8be0d30454b", null ],
    [ "__doc_gr_radar_os_cfar_c_set_rel_threshold", "os__cfar__c__pydoc__template_8h.html#a23e0e3548fe9a795b240b4b18370e83f", null ],
    [ "__doc_gr_radar_os_cfar_c_set_samp_compare", "os__cfar__c__pydoc__template_8h.html#a183359649b544c3ed14f0cf25b92db77", null ],
    [ "__doc_gr_radar_os_cfar_c_set_samp_protect", "os__cfar__c__pydoc__template_8h.html#a0dc77997d073bc95874e57b3516bbaf6", null ]
];