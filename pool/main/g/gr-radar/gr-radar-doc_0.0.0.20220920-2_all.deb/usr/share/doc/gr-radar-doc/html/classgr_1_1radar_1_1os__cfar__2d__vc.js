var classgr_1_1radar_1_1os__cfar__2d__vc =
[
    [ "sptr", "classgr_1_1radar_1_1os__cfar__2d__vc.html#a95a534d21c85cb76a8fa29e3632a5f34", null ],
    [ "make", "classgr_1_1radar_1_1os__cfar__2d__vc.html#a171081074623d07f5ffb69f0e6a549c6", null ],
    [ "set_mult_threshold", "classgr_1_1radar_1_1os__cfar__2d__vc.html#a3cb44d8c4d817e788b13ddd216a1a5a4", null ],
    [ "set_rel_threshold", "classgr_1_1radar_1_1os__cfar__2d__vc.html#a6b5f01cebda7b41e32d438b574572a5c", null ],
    [ "set_samp_compare", "classgr_1_1radar_1_1os__cfar__2d__vc.html#a0ade86b62ae5f7067231d612938f4dd3", null ],
    [ "set_samp_protect", "classgr_1_1radar_1_1os__cfar__2d__vc.html#ad33d6067a6e010744ccbf43748203e99", null ]
];