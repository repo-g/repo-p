var classgr_1_1radar_1_1crop__matrix__vcvc =
[
    [ "sptr", "classgr_1_1radar_1_1crop__matrix__vcvc.html#a16824473256f251ed7eaa707d5508a1a", null ],
    [ "make", "classgr_1_1radar_1_1crop__matrix__vcvc.html#aefd957c45a63639566fb5efd1fe82efb", null ]
];