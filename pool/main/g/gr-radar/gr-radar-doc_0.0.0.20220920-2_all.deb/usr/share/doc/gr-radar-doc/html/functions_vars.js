var functions_vars =
[
    [ "c", "functions_vars.html", null ],
    [ "d", "functions_vars_d.html", null ],
    [ "k", "functions_vars_k.html", null ],
    [ "p", "functions_vars_p.html", null ],
    [ "q", "functions_vars_q.html", null ],
    [ "r", "functions_vars_r.html", null ]
];