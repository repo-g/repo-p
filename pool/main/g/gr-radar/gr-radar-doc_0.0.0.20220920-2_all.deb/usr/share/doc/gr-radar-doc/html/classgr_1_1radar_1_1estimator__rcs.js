var classgr_1_1radar_1_1estimator__rcs =
[
    [ "sptr", "classgr_1_1radar_1_1estimator__rcs.html#aaca499347f3fab592d9a1559d0d7048d", null ],
    [ "make", "classgr_1_1radar_1_1estimator__rcs.html#a6c81d6b6b8632178260090776f12dba6", null ],
    [ "set_antenna_gain_rx", "classgr_1_1radar_1_1estimator__rcs.html#ad9ebb848f3469f215f67da4b15987f5b", null ],
    [ "set_antenna_gain_tx", "classgr_1_1radar_1_1estimator__rcs.html#aecc3880ca248046653fcaf7e777fb218", null ],
    [ "set_center_freq", "classgr_1_1radar_1_1estimator__rcs.html#a5ba2347c3c7da68597cefacc8678a6d7", null ],
    [ "set_corr_factor", "classgr_1_1radar_1_1estimator__rcs.html#a4d8e9ee5668aded45ba8b64ca7517526", null ],
    [ "set_num_mean", "classgr_1_1radar_1_1estimator__rcs.html#a920dd6f0c3aa3b3ce7df578855756842", null ],
    [ "set_power_tx", "classgr_1_1radar_1_1estimator__rcs.html#a7da0b25a1868d83de02ea3ceec51d8f8", null ],
    [ "set_usrp_gain_rx", "classgr_1_1radar_1_1estimator__rcs.html#abdbbb3353c0bd226c3af1c98c1e2f5b2", null ]
];