var os__cfar__2d__vc__pydoc__template_8h =
[
    [ "D", "os__cfar__2d__vc__pydoc__template_8h.html#a74021f021dcdfbb22891787b79c5529d", null ],
    [ "__doc_gr_radar_os_cfar_2d_vc", "os__cfar__2d__vc__pydoc__template_8h.html#aec69bcf16d502c958e78ee6ad6635649", null ],
    [ "__doc_gr_radar_os_cfar_2d_vc_make", "os__cfar__2d__vc__pydoc__template_8h.html#ad5859e47e6ce7861479e46a337b52f01", null ],
    [ "__doc_gr_radar_os_cfar_2d_vc_os_cfar_2d_vc_0", "os__cfar__2d__vc__pydoc__template_8h.html#ab95c6cd45aaf86c26e9251a2bf1c1b1e", null ],
    [ "__doc_gr_radar_os_cfar_2d_vc_os_cfar_2d_vc_1", "os__cfar__2d__vc__pydoc__template_8h.html#a3021de23e92dc10a59d9cb06ea310a24", null ],
    [ "__doc_gr_radar_os_cfar_2d_vc_set_mult_threshold", "os__cfar__2d__vc__pydoc__template_8h.html#a103804d221935b0d184a0a2c5447ce02", null ],
    [ "__doc_gr_radar_os_cfar_2d_vc_set_rel_threshold", "os__cfar__2d__vc__pydoc__template_8h.html#a63941887d6fb7632c2fc5d523ef18548", null ],
    [ "__doc_gr_radar_os_cfar_2d_vc_set_samp_compare", "os__cfar__2d__vc__pydoc__template_8h.html#ac610bbd455609769d61b7794c7193bc7", null ],
    [ "__doc_gr_radar_os_cfar_2d_vc_set_samp_protect", "os__cfar__2d__vc__pydoc__template_8h.html#a30a8e74ae7969719a2f42b50a60b9458", null ]
];