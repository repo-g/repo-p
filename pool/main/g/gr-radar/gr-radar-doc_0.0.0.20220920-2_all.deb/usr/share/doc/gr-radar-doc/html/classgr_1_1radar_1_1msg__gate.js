var classgr_1_1radar_1_1msg__gate =
[
    [ "sptr", "classgr_1_1radar_1_1msg__gate.html#ac2f2fbb5c698a15987c80b1580e240d3", null ],
    [ "make", "classgr_1_1radar_1_1msg__gate.html#afb29d780f15330d02dddb2d8bf3d6f85", null ]
];