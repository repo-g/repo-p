var classgr_1_1radar_1_1transpose__matrix__vcvc =
[
    [ "sptr", "classgr_1_1radar_1_1transpose__matrix__vcvc.html#a031948e5c6df48193e818138798f2516", null ],
    [ "make", "classgr_1_1radar_1_1transpose__matrix__vcvc.html#a6569f1d7968cb2e422900c51dc3cb102", null ]
];