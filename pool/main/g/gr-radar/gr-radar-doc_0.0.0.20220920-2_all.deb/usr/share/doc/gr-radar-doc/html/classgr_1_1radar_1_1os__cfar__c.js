var classgr_1_1radar_1_1os__cfar__c =
[
    [ "sptr", "classgr_1_1radar_1_1os__cfar__c.html#ad517967a03c62532691b0adf08b01a21", null ],
    [ "make", "classgr_1_1radar_1_1os__cfar__c.html#a8a625bb9b96efa87a72ab79edc1204b4", null ],
    [ "set_mult_threshold", "classgr_1_1radar_1_1os__cfar__c.html#ab54a405c844312f8fb9eeb62b3c4409e", null ],
    [ "set_rel_threshold", "classgr_1_1radar_1_1os__cfar__c.html#a228c699ffb518d6c1e3c15a37e4ad225", null ],
    [ "set_samp_compare", "classgr_1_1radar_1_1os__cfar__c.html#ae9762c0ae9e9e58b89ff86b58e539da1", null ],
    [ "set_samp_protect", "classgr_1_1radar_1_1os__cfar__c.html#af426bc0ddc593c41138f8622ce1e76a0", null ]
];