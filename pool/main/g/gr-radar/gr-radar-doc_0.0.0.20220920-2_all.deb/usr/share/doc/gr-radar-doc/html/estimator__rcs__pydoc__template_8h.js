var estimator__rcs__pydoc__template_8h =
[
    [ "D", "estimator__rcs__pydoc__template_8h.html#a74021f021dcdfbb22891787b79c5529d", null ],
    [ "__doc_gr_radar_estimator_rcs", "estimator__rcs__pydoc__template_8h.html#a024815d91943bd60a77ffd84bef1690a", null ],
    [ "__doc_gr_radar_estimator_rcs_estimator_rcs_0", "estimator__rcs__pydoc__template_8h.html#a57253e1c7bea80a8253ad72347997d85", null ],
    [ "__doc_gr_radar_estimator_rcs_estimator_rcs_1", "estimator__rcs__pydoc__template_8h.html#a5de909d0b6330d788cc7113bcab3ab35", null ],
    [ "__doc_gr_radar_estimator_rcs_make", "estimator__rcs__pydoc__template_8h.html#a62ab5a3b7ebf7ed13e01d3eab01ed6dc", null ],
    [ "__doc_gr_radar_estimator_rcs_set_antenna_gain_rx", "estimator__rcs__pydoc__template_8h.html#af353426afcebe26dacbeba3964a97353", null ],
    [ "__doc_gr_radar_estimator_rcs_set_antenna_gain_tx", "estimator__rcs__pydoc__template_8h.html#afcca8baa9c5ed8088ebdbd859c633363", null ],
    [ "__doc_gr_radar_estimator_rcs_set_center_freq", "estimator__rcs__pydoc__template_8h.html#a255ac689287ebdbd8516b3f4fb4f22a1", null ],
    [ "__doc_gr_radar_estimator_rcs_set_corr_factor", "estimator__rcs__pydoc__template_8h.html#a2591ac2196ce72d5ee6db97f2ce23ee5", null ],
    [ "__doc_gr_radar_estimator_rcs_set_num_mean", "estimator__rcs__pydoc__template_8h.html#aee99902e7232f151029d2bcd81b2e4d9", null ],
    [ "__doc_gr_radar_estimator_rcs_set_power_tx", "estimator__rcs__pydoc__template_8h.html#a6b3521aab1a6e5e84ae54535aff24453", null ],
    [ "__doc_gr_radar_estimator_rcs_set_usrp_gain_rx", "estimator__rcs__pydoc__template_8h.html#aa4f56c4176e20ec83a540254eb99499f", null ]
];