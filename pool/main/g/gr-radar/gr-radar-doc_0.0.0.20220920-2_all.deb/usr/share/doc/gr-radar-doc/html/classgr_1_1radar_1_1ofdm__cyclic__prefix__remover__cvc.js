var classgr_1_1radar_1_1ofdm__cyclic__prefix__remover__cvc =
[
    [ "sptr", "classgr_1_1radar_1_1ofdm__cyclic__prefix__remover__cvc.html#a5997e4c0182e6aa31a6ba0d7104911e0", null ],
    [ "make", "classgr_1_1radar_1_1ofdm__cyclic__prefix__remover__cvc.html#a5f948ca841e412d79a2c0e1f90bab74f", null ]
];