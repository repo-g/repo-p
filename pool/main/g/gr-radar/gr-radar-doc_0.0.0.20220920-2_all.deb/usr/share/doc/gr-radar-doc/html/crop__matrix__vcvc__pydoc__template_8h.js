var crop__matrix__vcvc__pydoc__template_8h =
[
    [ "D", "crop__matrix__vcvc__pydoc__template_8h.html#a74021f021dcdfbb22891787b79c5529d", null ],
    [ "__doc_gr_radar_crop_matrix_vcvc", "crop__matrix__vcvc__pydoc__template_8h.html#a6f5374becbf589b29244db66e6ec7af8", null ],
    [ "__doc_gr_radar_crop_matrix_vcvc_crop_matrix_vcvc", "crop__matrix__vcvc__pydoc__template_8h.html#a31d5123ec4367fd6545dbd2e72139211", null ],
    [ "__doc_gr_radar_crop_matrix_vcvc_make", "crop__matrix__vcvc__pydoc__template_8h.html#a42f2daf37cd68e097c18218d81b75d0b", null ]
];