// SPDX-FileCopyrightText: 2018 - 2022 UnionTech Software Technology Co., Ltd.
//
// SPDX-License-Identifier: GPL-3.0-or-later

package gudev

import "C"
import "unsafe"

//export _GUdev_go_callback_cleanup
func _GUdev_go_callback_cleanup(unsafe.Pointer) {
}
