"""Module for calculating induced electromagnetic fields

"""
