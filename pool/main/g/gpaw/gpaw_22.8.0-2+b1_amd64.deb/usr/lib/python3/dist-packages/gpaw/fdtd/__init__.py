"""Module for electrodynamic simulations."""
