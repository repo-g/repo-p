if __name__ == '__main__':
    from gpaw.cli.main import main
    main()
