#!/bin/sh
graphlan_annotate --annot annot_0.txt guide.txt guide_1.xml
graphlan guide_1.xml step_1.png --dpi 300 --size 3.5
graphlan guide_1.xml step_1.svg --dpi 300 --size 3.5
