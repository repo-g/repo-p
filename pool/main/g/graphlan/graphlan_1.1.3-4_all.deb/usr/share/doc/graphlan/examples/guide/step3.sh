#!/bin/sh
graphlan_annotate --annot annot_2.txt guide_2.xml	guide_3.xml
graphlan guide_3.xml step_3.png --dpi 300 --size 3.5
graphlan guide_3.xml step_3.svg --dpi 300 --size 3.5
