#!/bin/sh                                                                                                                                                                                                                                                                      
graphlan_annotate IBDgeo.txt IBDgeo.annot.xml --annot annotation.txt 
graphlan IBDgeo.annot.xml IBDgeo.png --dpi 150 
