#!/bin/sh
graphlan_annotate hmptree.xml hmptree.annot.xml --annot annot.txt
graphlan hmptree.annot.xml hmptree.png --dpi 150 --size 14 
