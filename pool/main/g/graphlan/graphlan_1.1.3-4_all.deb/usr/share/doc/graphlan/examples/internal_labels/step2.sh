#!/bin/sh
#look at step1.sh
graphlan_annotate --annot annot_1.txt guide_1.xml guide_2.xml
graphlan guide_2.xml step2.png --dpi 400 --size 11.0
graphlan guide_2.xml step2.svg --dpi 400 --size 11.0
