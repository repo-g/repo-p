#!/bin/sh
#look at step1.sh
graphlan_annotate --annot annot_3.txt guide_3.xml guide_4.xml
graphlan guide_4.xml step4.png --dpi 200 --size 10.5
graphlan guide_4.xml step4.svg --dpi 200 --size 10.5
