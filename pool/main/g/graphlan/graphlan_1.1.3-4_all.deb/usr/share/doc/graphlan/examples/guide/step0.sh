#!/bin/sh
graphlan guide.txt step_0.png --dpi 300 --size 3.5
graphlan guide.txt step_0.svg --dpi 300 --size 3.5
