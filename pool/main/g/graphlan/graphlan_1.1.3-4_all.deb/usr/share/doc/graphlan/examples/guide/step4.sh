#!/bin/sh
graphlan_annotate --annot annot_3.txt guide_3.xml	guide_4.xml
graphlan guide_4.xml step_4.png --dpi 300 --size 3.5 --pad 0.0
graphlan guide_4.xml step_4.svg --dpi 300 --size 3.5 --pad 0.0
