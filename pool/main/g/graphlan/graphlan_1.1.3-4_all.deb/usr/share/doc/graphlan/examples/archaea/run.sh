#!/bin/sh
graphlan_annotate archaea.txt archaea.annot.xml --annot annot.txt
graphlan archaea.annot.xml archaea.png --dpi 150 --pad 0 
