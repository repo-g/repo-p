#!/bin/sh
graphlan_annotate ppa_tol.xml ppa_tol.annot.xml --annot annot.txt
graphlan ppa_tol.annot.xml ppa_tol.png --dpi 200 --size 15 --pad 0.6 
