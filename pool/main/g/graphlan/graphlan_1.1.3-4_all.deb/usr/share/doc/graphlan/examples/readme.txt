GraPhlAn examples are provided in subfolders. Each subfoder has a run.sh script
that annotate the input tree with the annotation file and then generate the
output image.

The scripts assume that the GraPhlAn main folder is in the system path.

