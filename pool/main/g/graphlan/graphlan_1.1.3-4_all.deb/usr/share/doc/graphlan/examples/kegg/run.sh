#!/bin/sh
#!/bin/bash
graphlan_annotate --annot annot.txt ppa_kegg_raxml.names.nn.nwk kegg.xml
graphlan --dpi 300 kegg.xml kegg.png
