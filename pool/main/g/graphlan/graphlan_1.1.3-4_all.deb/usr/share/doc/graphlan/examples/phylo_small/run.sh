#!/bin/sh
graphlan_annotate phylo_small.xml phylo_small.annot.xml --annot annot.txt
graphlan phylo_small.annot.xml phylo_small.png --dpi 150  
