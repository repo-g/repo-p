#!/bin/sh
#"graphlan is a script used to execute the plot of the tree and create the images. We can change dpi(resolution) and the size
graphlan archaea.txt step_0.png --dpi 200 --size 10.5
graphlan archaea.txt step_0.svg --dpi 200 --size 10.5
