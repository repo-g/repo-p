var classgr_1_1satellites_1_1decode__ra__code =
[
    [ "sptr", "classgr_1_1satellites_1_1decode__ra__code.html#a4b4a3311dab95a110d492b5b18b1c2ba", null ],
    [ "make", "classgr_1_1satellites_1_1decode__ra__code.html#a4db1852bfdb098d00e631a6e3517a6c7", null ]
];