var classgr_1_1satellites_1_1distributed__syncframe__soft =
[
    [ "sptr", "classgr_1_1satellites_1_1distributed__syncframe__soft.html#a0d98e9b7233392541506629a71132686", null ],
    [ "make", "classgr_1_1satellites_1_1distributed__syncframe__soft.html#a81b20591bb79b62b090ad21cd5e2921e", null ]
];