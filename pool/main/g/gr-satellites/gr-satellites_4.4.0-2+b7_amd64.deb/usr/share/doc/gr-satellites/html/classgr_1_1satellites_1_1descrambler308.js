var classgr_1_1satellites_1_1descrambler308 =
[
    [ "sptr", "classgr_1_1satellites_1_1descrambler308.html#a2a5f72aa83267589063783f30e2619e8", null ],
    [ "make", "classgr_1_1satellites_1_1descrambler308.html#a9c2b08989636f599cb2bc21320eaa8fe", null ]
];