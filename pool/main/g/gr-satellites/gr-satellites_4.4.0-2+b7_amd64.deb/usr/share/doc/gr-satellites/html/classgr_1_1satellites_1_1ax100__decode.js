var classgr_1_1satellites_1_1ax100__decode =
[
    [ "sptr", "classgr_1_1satellites_1_1ax100__decode.html#a9ef1beeb69f9b1254beb21f53d510424", null ],
    [ "make", "classgr_1_1satellites_1_1ax100__decode.html#abed83370c1d6df0aeafb437357582c90", null ]
];