#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Copyright 2019 Daniel Estevez <daniel@destevez.net>
#
# This file is part of gr-satellites
#
# SPDX-License-Identifier: GPL-3.0-or-later
#

'''
gr-satellites core module

This module contains the core functionality of gr-satellites
'''

from .gr_satellites_flowgraph import gr_satellites_flowgraph
