var dir_67d028be6b074ac01b39a18b19f069e1 =
[
    [ "osmocom", "dir_4c01be1208516a0996e3cc9899bb38d3.html", "dir_4c01be1208516a0996e3cc9899bb38d3" ]
];