var structcfile =
[
    [ "_blen", "structcfile.html#ad3d6965e1039aa1f648361b2f83b034a", null ],
    [ "data", "structcfile.html#aeeb1105659968baae5df24026bf1d281", null ],
    [ "len", "structcfile.html#a2c856227c89a929b863da15951fcaef4", null ]
];