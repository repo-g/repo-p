var group__cxvec =
[
    [ "Complex vectors math and signal processing", "group__cxvec__math.html", "group__cxvec__math" ],
    [ "cxvec.h", "cxvec_8h.html", null ],
    [ "osmo_cxvec", "structosmo__cxvec.html", [
      [ "_data", "structosmo__cxvec.html#aa8a9de0ef88d44caa1c07bc91b99bffd", null ],
      [ "data", "structosmo__cxvec.html#aec620e4391a60de801eb23dec73e4d12", null ],
      [ "flags", "structosmo__cxvec.html#ab3bd5fac3c3a84df65bc82d1cae223ab", null ],
      [ "len", "structosmo__cxvec.html#a03722af5764b41c9151a7542546e3739", null ],
      [ "max_len", "structosmo__cxvec.html#a42469c5c904c26c45af3ff557ccd203f", null ]
    ] ],
    [ "CXVEC_FLG_REAL_ONLY", "group__cxvec.html#gabfa666beffbfc297c776d123b1121f57", null ],
    [ "osmo_cxvec_alloc", "group__cxvec.html#ga9461ac13f1d77ca832b140461e599caa", null ],
    [ "osmo_cxvec_alloc_from_data", "group__cxvec.html#ga4edecda809e91f11cf88b53a1db8d62a", null ],
    [ "osmo_cxvec_dbg_dump", "group__cxvec.html#ga69e6d1ea3d468954cedf7d6f8d44f825", null ],
    [ "osmo_cxvec_free", "group__cxvec.html#gaa57240ff2299122f9375e901b9700e7d", null ],
    [ "osmo_cxvec_init_from_data", "group__cxvec.html#gaa03ae6bbc24d094b8955d905832f0c36", null ]
];