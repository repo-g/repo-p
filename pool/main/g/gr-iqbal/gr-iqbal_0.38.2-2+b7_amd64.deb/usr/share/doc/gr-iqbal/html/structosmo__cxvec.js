var structosmo__cxvec =
[
    [ "_data", "structosmo__cxvec.html#aa8a9de0ef88d44caa1c07bc91b99bffd", null ],
    [ "data", "structosmo__cxvec.html#aec620e4391a60de801eb23dec73e4d12", null ],
    [ "flags", "structosmo__cxvec.html#ab3bd5fac3c3a84df65bc82d1cae223ab", null ],
    [ "len", "structosmo__cxvec.html#a03722af5764b41c9151a7542546e3739", null ],
    [ "max_len", "structosmo__cxvec.html#a42469c5c904c26c45af3ff557ccd203f", null ]
];