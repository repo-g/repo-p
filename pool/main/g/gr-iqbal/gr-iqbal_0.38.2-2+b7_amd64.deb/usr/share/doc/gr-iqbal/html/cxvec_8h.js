var cxvec_8h =
[
    [ "CXVEC_FLG_REAL_ONLY", "group__cxvec.html#gabfa666beffbfc297c776d123b1121f57", null ],
    [ "osmo_cxvec_alloc", "group__cxvec.html#ga9461ac13f1d77ca832b140461e599caa", null ],
    [ "osmo_cxvec_alloc_from_data", "group__cxvec.html#ga4edecda809e91f11cf88b53a1db8d62a", null ],
    [ "osmo_cxvec_dbg_dump", "group__cxvec.html#ga69e6d1ea3d468954cedf7d6f8d44f825", null ],
    [ "osmo_cxvec_free", "group__cxvec.html#gaa57240ff2299122f9375e901b9700e7d", null ],
    [ "osmo_cxvec_init_from_data", "group__cxvec.html#gaa03ae6bbc24d094b8955d905832f0c36", null ]
];