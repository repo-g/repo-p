var group__cfile =
[
    [ "cfile.h", "cfile_8h.html", null ],
    [ "cfile", "structcfile.html", [
      [ "_blen", "structcfile.html#ad3d6965e1039aa1f648361b2f83b034a", null ],
      [ "data", "structcfile.html#aeeb1105659968baae5df24026bf1d281", null ],
      [ "len", "structcfile.html#a2c856227c89a929b863da15951fcaef4", null ]
    ] ],
    [ "cfile_load", "group__cfile.html#gacb0304d89096222df64f3f9a10f22167", null ],
    [ "cfile_release", "group__cfile.html#ga7728a89f370281e5da16ff27d8657b3d", null ]
];