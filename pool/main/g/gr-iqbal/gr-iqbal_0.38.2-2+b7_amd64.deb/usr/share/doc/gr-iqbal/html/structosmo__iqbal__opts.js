var structosmo__iqbal__opts =
[
    [ "fft_count", "structosmo__iqbal__opts.html#abb7854c9f674bf12022ce0b5485fd2a7", null ],
    [ "fft_size", "structosmo__iqbal__opts.html#a76e529e63af98a524caa8cf61c4de828", null ],
    [ "max_iter", "structosmo__iqbal__opts.html#ac6dc907d8a810172970426cac913f2b0", null ],
    [ "start_at_prev", "structosmo__iqbal__opts.html#ad36e80298fe63cb9f985401e30f768fc", null ]
];