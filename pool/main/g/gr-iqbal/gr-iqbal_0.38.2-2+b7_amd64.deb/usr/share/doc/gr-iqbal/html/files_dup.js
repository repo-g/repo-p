var files_dup =
[
    [ "docs", "dir_49e56c817e5e54854c35e136979f97ca.html", "dir_49e56c817e5e54854c35e136979f97ca" ],
    [ "include", "dir_d44c64559bbebec7f509842c48db8b23.html", "dir_d44c64559bbebec7f509842c48db8b23" ],
    [ "libosmo-dsp", "dir_1f8721dacf9d935ccbc8813b75f29780.html", "dir_1f8721dacf9d935ccbc8813b75f29780" ],
    [ "python", "dir_ca01010b7b3fd2da2e4fa594c9bd2e99.html", "dir_ca01010b7b3fd2da2e4fa594c9bd2e99" ]
];