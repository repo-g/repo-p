var cxvec__math_8h =
[
    [ "M_PIf", "group__cxvec__math.html#gacbb42dc053fedc161079f0a4d20a64e8", null ],
    [ "osmo_cxvec_conv_type", "group__cxvec__math.html#ga2e183a0f24afa2e16199d1514629bf08", [
      [ "CONV_FULL_SPAN", "group__cxvec__math.html#gga2e183a0f24afa2e16199d1514629bf08ae758172bda42f9b44aa9015c0e142717", null ],
      [ "CONV_OVERLAP_ONLY", "group__cxvec__math.html#gga2e183a0f24afa2e16199d1514629bf08a47fb2e6e9d274d4512601828023ac1d2", null ],
      [ "CONV_NO_DELAY", "group__cxvec__math.html#gga2e183a0f24afa2e16199d1514629bf08a03ece74c3bcd50aeb9fb42329b9a59a5", null ]
    ] ],
    [ "osmo_cxvec_peak_alg", "group__cxvec__math.html#ga7942b58b341e440c0e8796d395460b78", [
      [ "PEAK_WEIGH_WIN", "group__cxvec__math.html#gga7942b58b341e440c0e8796d395460b78abb4b91d1bfa5bd51ff0e48633d9b9891", null ],
      [ "PEAK_WEIGH_WIN_CENTER", "group__cxvec__math.html#gga7942b58b341e440c0e8796d395460b78ab0fb6b29112253cc5d51fb119b5d812a", null ],
      [ "PEAK_EARLY_LATE", "group__cxvec__math.html#gga7942b58b341e440c0e8796d395460b78aa8df843abc147bca5860fee1ddff1378", null ]
    ] ],
    [ "osmo_cxvec_convolve", "group__cxvec__math.html#ga2ebadb16e25768896013420a98ec666f", null ],
    [ "osmo_cxvec_correlate", "group__cxvec__math.html#ga99ff6e3baec3253f4e431b156f042a0f", null ],
    [ "osmo_cxvec_delay", "group__cxvec__math.html#ga32a8d3d23ae166e12b7005eb13172d1d", null ],
    [ "osmo_cxvec_interpolate_point", "group__cxvec__math.html#gacb1c646e03a09b51b617467501639763", null ],
    [ "osmo_cxvec_peak_energy_find", "group__cxvec__math.html#ga495219ee953336e15cd68c9b22d3850c", null ],
    [ "osmo_cxvec_peaks_scan", "group__cxvec__math.html#gad25b04feb1cd30b24fe7de8f76e56c23", null ],
    [ "osmo_cxvec_rotate", "group__cxvec__math.html#ga0756d454df79784475d5f77d22db2939", null ],
    [ "osmo_cxvec_scale", "group__cxvec__math.html#ga5ac0adb49726087258381582582ef654", null ],
    [ "osmo_cxvec_sig_normalize", "group__cxvec__math.html#ga4579583a658fc33afd24a1d8508b212f", null ],
    [ "osmo_normsqf", "group__cxvec__math.html#ga1b169ec31cb01111c0def0c12d65f3a2", null ],
    [ "osmo_sinc", "group__cxvec__math.html#ga4e7a7183dc4e5ce77d72d2986495f348", null ]
];