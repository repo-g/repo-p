var group__iqbal =
[
    [ "iqbal.h", "iqbal_8h.html", null ],
    [ "osmo_iqbal_opts", "structosmo__iqbal__opts.html", [
      [ "fft_count", "structosmo__iqbal__opts.html#abb7854c9f674bf12022ce0b5485fd2a7", null ],
      [ "fft_size", "structosmo__iqbal__opts.html#a76e529e63af98a524caa8cf61c4de828", null ],
      [ "max_iter", "structosmo__iqbal__opts.html#ac6dc907d8a810172970426cac913f2b0", null ],
      [ "start_at_prev", "structosmo__iqbal__opts.html#ad36e80298fe63cb9f985401e30f768fc", null ]
    ] ],
    [ "osmo_iqbal_cxvec_estimate", "group__iqbal.html#ga19298f48b07828c19bc54038d5abe5ad", null ],
    [ "osmo_iqbal_cxvec_fix", "group__iqbal.html#ga978fbf1c9f01694852c561c95d5ceb9d", null ],
    [ "osmo_iqbal_cxvec_optimize", "group__iqbal.html#gac74f9d37e2153fdf954e592b36f7c7c0", null ],
    [ "osmo_iqbal_estimate", "group__iqbal.html#ga23c6972ae206b4a60dbe49d954fc9caa", null ],
    [ "osmo_iqbal_fix", "group__iqbal.html#gaaca46bab25fe24148c3cb3c4d2158c79", null ],
    [ "osmo_iqbal_default_opts", "group__iqbal.html#ga2f0587c233b021d72a98a11312ff5e9f", null ]
];