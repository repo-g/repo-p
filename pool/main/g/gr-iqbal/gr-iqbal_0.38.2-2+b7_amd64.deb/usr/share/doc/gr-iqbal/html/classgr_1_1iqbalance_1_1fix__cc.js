var classgr_1_1iqbalance_1_1fix__cc =
[
    [ "sptr", "classgr_1_1iqbalance_1_1fix__cc.html#a725b81fddd31e792b69844413be58873", null ],
    [ "~fix_cc", "classgr_1_1iqbalance_1_1fix__cc.html#a48194e6726e5195f4a65729667b3f50a", null ],
    [ "apply_new_corrections", "classgr_1_1iqbalance_1_1fix__cc.html#a42763e35b1bc588aab125d4015c9da34", null ],
    [ "mag", "classgr_1_1iqbalance_1_1fix__cc.html#a60c9a3b5e2d1d9ac3ebd8d93864960c6", null ],
    [ "make", "classgr_1_1iqbalance_1_1fix__cc.html#ab8249f6465b565365e1f172d70b8fb12", null ],
    [ "phase", "classgr_1_1iqbalance_1_1fix__cc.html#a26ff240cbbf2e7c8022fbada9eb0c667", null ],
    [ "set_mag", "classgr_1_1iqbalance_1_1fix__cc.html#adf975fa61fe32735d4a1d64edb4c25ca", null ],
    [ "set_phase", "classgr_1_1iqbalance_1_1fix__cc.html#adaa4890f8ca3e392cfa011084aef9dfe", null ],
    [ "work", "classgr_1_1iqbalance_1_1fix__cc.html#a25a564238010f5d53312c610a6f39701", null ]
];