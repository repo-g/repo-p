var modules =
[
    [ "GNU Radio TEST C++ Signal Processing Blocks", "group__block.html", null ],
    [ ".cfile helpers", "group__cfile.html", "group__cfile" ],
    [ "Complex vectors", "group__cxvec.html", "group__cxvec" ],
    [ "IQ balance utilities", "group__iqbal.html", "group__iqbal" ]
];