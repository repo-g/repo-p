#ifdef __GNUC__
# warning GemPixConvert.h is deprecated - please include "Gem/PixConvert.h" instead
#endif
#include "Gem/PixConvert.h"
