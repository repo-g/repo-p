#ifdef __GNUC__
# warning GemState.h is deprecated - please include "Gem/State.h" instead
#endif
#include "Gem/State.h"
