#ifdef __GNUC__
# warning Gem/ThreadMutex.h is deprecated - please include "Utils/ThreadMutex.h" instead
#endif
#include "Utils/ThreadMutex.h"
