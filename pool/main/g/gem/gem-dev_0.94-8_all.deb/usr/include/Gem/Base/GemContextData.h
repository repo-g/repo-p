#ifdef __GNUC__
# warning Base/GemContextData.h is deprecated - please include "Gem/ContextData.h" instead
#endif
#include "Gem/ContextData.h"
