#ifdef __GNUC__
# warning GemPixUtil.h is deprecated - please include "Gem/Image.h" instead
#endif
#include "Gem/Image.h"
