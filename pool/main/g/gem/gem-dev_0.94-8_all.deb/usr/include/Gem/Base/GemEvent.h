#ifdef __GNUC__
# warning GemEvent.h is deprecated - please include "Gem/Event.h" instead
#endif
#include "Gem/Event.h"
