#ifdef __GNUC__
# warning Base/GemExportDef.h is deprecated - please include "Gem/ExportDef.h" instead
#endif
#include "Gem/ExportDef.h"
